"""Tests for Linear tool."""
