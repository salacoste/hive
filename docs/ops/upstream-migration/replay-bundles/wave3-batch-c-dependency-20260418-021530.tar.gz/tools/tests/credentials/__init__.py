"""Credential-specific tests."""
