"""Fallback LLM provider wrapper.

Retries with backup providers when the primary provider raises an exception.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from typing import Any

from framework.llm.provider import LLMProvider, LLMResponse, Tool
from framework.llm.stream_events import (
    FinishEvent,
    ReasoningDeltaEvent,
    StreamErrorEvent,
    TextDeltaEvent,
    TextEndEvent,
    ToolCallEvent,
)

logger = logging.getLogger(__name__)


class FallbackLLMProvider(LLMProvider):
    """Wrap a primary LLM with one or more fallback providers."""

    def __init__(self, providers: list[LLMProvider]) -> None:
        if not providers:
            raise ValueError("FallbackLLMProvider requires at least one provider")
        self._providers = providers
        self.model = getattr(providers[0], "model", "unknown")

    def _iter_with_fallback(self):
        yield from enumerate(self._providers)

    def complete(
        self,
        messages: list[dict[str, Any]],
        system: str = "",
        tools: list[Tool] | None = None,
        max_tokens: int = 1024,
        response_format: dict[str, Any] | None = None,
        json_mode: bool = False,
        max_retries: int | None = None,
    ) -> LLMResponse:
        last_exc: Exception | None = None
        for idx, provider in self._iter_with_fallback():
            try:
                return provider.complete(
                    messages=messages,
                    system=system,
                    tools=tools,
                    max_tokens=max_tokens,
                    response_format=response_format,
                    json_mode=json_mode,
                    max_retries=max_retries,
                )
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if idx + 1 < len(self._providers):
                    logger.warning(
                        "Primary model '%s' failed (%s). Falling back to '%s'.",
                        getattr(provider, "model", "unknown"),
                        exc.__class__.__name__,
                        getattr(self._providers[idx + 1], "model", "unknown"),
                    )
                else:
                    logger.error(
                        "All fallback models failed. Last model '%s' error: %s",
                        getattr(provider, "model", "unknown"),
                        exc,
                    )
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("No providers available")

    async def acomplete(
        self,
        messages: list[dict[str, Any]],
        system: str = "",
        tools: list[Tool] | None = None,
        max_tokens: int = 1024,
        response_format: dict[str, Any] | None = None,
        json_mode: bool = False,
        max_retries: int | None = None,
    ) -> LLMResponse:
        last_exc: Exception | None = None
        for idx, provider in self._iter_with_fallback():
            try:
                return await provider.acomplete(
                    messages=messages,
                    system=system,
                    tools=tools,
                    max_tokens=max_tokens,
                    response_format=response_format,
                    json_mode=json_mode,
                    max_retries=max_retries,
                )
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if idx + 1 < len(self._providers):
                    logger.warning(
                        "Primary model '%s' failed (%s). Falling back to '%s'.",
                        getattr(provider, "model", "unknown"),
                        exc.__class__.__name__,
                        getattr(self._providers[idx + 1], "model", "unknown"),
                    )
                else:
                    logger.error(
                        "All fallback models failed. Last model '%s' error: %s",
                        getattr(provider, "model", "unknown"),
                        exc,
                    )
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("No providers available")

    async def stream(
        self,
        messages: list[dict[str, Any]],
        system: str = "",
        tools: list[Tool] | None = None,
        max_tokens: int = 4096,
    ) -> AsyncIterator[Any]:
        last_exc: Exception | None = None
        for idx, provider in self._iter_with_fallback():
            fallback_requested = False
            emitted_substantive_event = False
            try:
                async for event in provider.stream(
                    messages=messages,
                    system=system,
                    tools=tools,
                    max_tokens=max_tokens,
                ):
                    if isinstance(event, StreamErrorEvent):
                        # Some providers encode hard failures as StreamErrorEvent
                        # instead of raising. If nothing useful was streamed,
                        # fail over to the next model in chain.
                        if idx + 1 < len(self._providers) and not emitted_substantive_event:
                            logger.warning(
                                "Stream model '%s' emitted error event; falling back to '%s'. "
                                "error=%s",
                                getattr(provider, "model", "unknown"),
                                getattr(self._providers[idx + 1], "model", "unknown"),
                                event.error,
                            )
                            fallback_requested = True
                            break
                        yield event
                        return
                    if isinstance(
                        event,
                        (
                            TextDeltaEvent,
                            TextEndEvent,
                            ToolCallEvent,
                            ReasoningDeltaEvent,
                            FinishEvent,
                        ),
                    ):
                        emitted_substantive_event = True
                    yield event
                if fallback_requested:
                    continue
                return
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                if idx + 1 < len(self._providers):
                    logger.warning(
                        "Stream model '%s' failed (%s). Falling back to '%s'.",
                        getattr(provider, "model", "unknown"),
                        exc.__class__.__name__,
                        getattr(self._providers[idx + 1], "model", "unknown"),
                    )
                else:
                    logger.error(
                        "All fallback stream models failed. Last model '%s' error: %s",
                        getattr(provider, "model", "unknown"),
                        exc,
                    )
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("No providers available")
