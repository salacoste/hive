"""Tests for runtime components."""
