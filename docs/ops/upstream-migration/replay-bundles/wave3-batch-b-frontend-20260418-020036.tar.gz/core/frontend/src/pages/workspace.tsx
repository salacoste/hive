import { useState, useCallback, useRef, useEffect, useMemo } from "react";
import ReactDOM from "react-dom";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Plus, KeyRound, Sparkles, Layers, ChevronLeft, Bot, Loader2, WifiOff, X, FolderOpen, Download, RefreshCw } from "lucide-react";
import type { GraphNode, NodeStatus } from "@/components/graph-types";
import DraftGraph from "@/components/DraftGraph";
import ChatPanel, { type ChatMessage } from "@/components/ChatPanel";
import TopBar from "@/components/TopBar";
import HistorySidebar from "@/components/HistorySidebar";
import { TAB_STORAGE_KEY, loadPersistedTabs, savePersistedTabs, type PersistedTabState } from "@/lib/tab-persistence";
import NodeDetailPanel from "@/components/NodeDetailPanel";
import CredentialsModal, { type Credential, createFreshCredentials, cloneCredentials, allRequiredCredentialsMet, clearCredentialCache } from "@/components/CredentialsModal";
import { agentsApi } from "@/api/agents";
import {
  credentialsApi,
  type CredentialReadinessResponse,
} from "@/api/credentials";
import { executionApi } from "@/api/execution";
import { graphsApi } from "@/api/graphs";
import { sessionsApi } from "@/api/sessions";
import { projectsApi } from "@/api/projects";
import {
  autonomousApi,
  type AutonomousOpsStatusResponse,
  type AutonomousRemediateStaleResponse,
  type BacklogTask as AutonomousBacklogTask,
  type PipelineRun as AutonomousPipelineRun,
} from "@/api/autonomous";
import { useMultiSSE } from "@/hooks/use-sse";
import type { LiveSession, AgentEvent, DiscoverEntry, NodeSpec, DraftGraph as DraftGraphData, ProjectInfo } from "@/api/types";
import { sseEventToChatMessage, formatAgentDisplayName } from "@/lib/chat-helpers";
import { topologyToGraphNodes } from "@/lib/graph-converter";
import { cronToLabel } from "@/lib/graphUtils";
import { ApiError } from "@/api/client";

const makeId = () => Math.random().toString(36).slice(2, 9);
const ACTIVE_PROJECT_STORAGE_KEY = "hive:active-project-id";

/**
 * Strip the instance suffix added when multiple tabs share the same agentType.
 * e.g. "exports/deep_research::abc123" → "exports/deep_research"
 * First-instance keys (no "::") are returned unchanged.
 */
const baseAgentType = (key: string): string => key.split("::")[0];

function formatPct(value: number | null | undefined): string {
  if (value === null || value === undefined) return "--";
  return `${Math.round(value * 100)}%`;
}

function formatSeconds(value: number | null | undefined): string {
  if (value === null || value === undefined) return "--";
  if (value < 1) return "<1s";
  if (value < 60) return `${Math.round(value)}s`;
  const mins = Math.floor(value / 60);
  const secs = Math.round(value % 60);
  return `${mins}m ${String(secs).padStart(2, "0")}s`;
}

/** Format seconds into a compact countdown string. */
function formatCountdown(totalSecs: number): string {
  const h = Math.floor(totalSecs / 3600);
  const m = Math.floor((totalSecs % 3600) / 60);
  const s = Math.floor(totalSecs % 60);
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
  return `${m}m ${String(s).padStart(2, "0")}s`;
}

/** Live countdown from an initial seconds value, ticking every second. */
function TimerCountdown({ initialSeconds }: { initialSeconds: number }) {
  const [remaining, setRemaining] = useState(Math.max(0, Math.round(initialSeconds)));
  const startRef = useRef({ wallTime: Date.now(), initial: Math.max(0, Math.round(initialSeconds)) });

  useEffect(() => {
    startRef.current = { wallTime: Date.now(), initial: Math.max(0, Math.round(initialSeconds)) };
    setRemaining(Math.max(0, Math.round(initialSeconds)));
  }, [initialSeconds]);

  useEffect(() => {
    const id = setInterval(() => {
      const elapsed = (Date.now() - startRef.current.wallTime) / 1000;
      setRemaining(Math.max(0, Math.round(startRef.current.initial - elapsed)));
    }, 1000);
    return () => clearInterval(id);
  }, []);

  if (remaining <= 0) return <span className="text-amber-400/80">firing...</span>;
  return <span>{formatCountdown(remaining)}</span>;
}

// --- Session types ---
interface Session {
  id: string;
  agentType: string;
  /** The key used in sessionsByAgent / agentStates for this specific tab instance.
   * Equals agentType for the first tab; equals "agentType::frontendSessionId" for
   * additional tabs opened for the same agent so each gets its own isolated slot. */
  tabKey?: string;
  label: string;
  messages: ChatMessage[];
  graphNodes: GraphNode[];
  credentials: Credential[];
  backendSessionId?: string;
  /** The cold history session ID this tab was originally opened from (if any).
   * Used to detect "already open" even after backendSessionId is updated to a
   * new live session ID when the cold session is revived. */
  historySourceId?: string;
}

type ProjectMetrics = {
  project_id: string;
  summary: {
    active_sessions: number;
    historical_sessions: number;
    executions_total: number;
    messages_total: number;
    user_messages_total: number;
  };
  kpis: {
    success_rate: number | null;
    cycle_time_seconds_p50: number | null;
    cycle_time_seconds_avg: number | null;
    intervention_ratio: number;
  };
};

type ProjectComparisonRow = {
  project: { id: string; name: string; repository: string };
  summary: {
    active_sessions: number;
    historical_sessions: number;
    executions_total: number;
    messages_total: number;
    user_messages_total: number;
  };
  kpis: {
    success_rate: number | null;
    cycle_time_seconds_p50: number | null;
    cycle_time_seconds_avg: number | null;
    intervention_ratio: number;
  };
};

type ProjectTemplateProfile = {
  id: string;
  name: string;
  description: string;
  stack: "node" | "python" | "go" | "jvm" | "rust" | "fullstack";
  repo_type: "single" | "monorepo";
  required_checks: string[];
  commands: Partial<Record<"install" | "lint" | "typecheck" | "test" | "build" | "smoke", string>>;
  dry_run_command?: string;
};

type ProjectRetentionView = {
  project_id: string;
  defaults: Record<string, unknown>;
  overrides: Record<string, unknown>;
  effective: {
    history_days: number;
    min_sessions_to_keep: number;
    archive_enabled: boolean;
    archive_root: string;
  };
  plan: {
    historical_sessions: number;
    eligible_count: number;
    cutoff_timestamp: number;
    candidates: Array<{ session_id: string; created_at: number; age_days: number }>;
  };
};

type ProjectExecutionTemplateView = {
  project_id: string;
  defaults: {
    execution_template: {
      default_flow: Array<{ stage: string; mode: string; model_profile: string }>;
      retry_policy: { max_retries_per_stage: number; escalate_on: string[] };
      github?: {
        default_ref?: string;
        default_branch?: string;
        ref?: string;
        branch?: string;
        no_checks_policy?: "error" | "success" | "manual_pending";
      };
      default_ref?: string;
      default_branch?: string;
      ref?: string;
      branch?: string;
      no_checks_policy?: "error" | "success" | "manual_pending";
    };
    policy_binding: Record<string, unknown>;
  };
  execution_template: {
    default_flow?: Array<{ stage: string; mode: string; model_profile: string }>;
    retry_policy?: { max_retries_per_stage?: number; escalate_on?: string[] };
    github?: {
      default_ref?: string;
      default_branch?: string;
      ref?: string;
      branch?: string;
      no_checks_policy?: "error" | "success" | "manual_pending" | "manual" | "defer" | "pass" | "ok";
    };
    default_ref?: string;
    default_branch?: string;
    ref?: string;
    branch?: string;
    no_checks_policy?: "error" | "success" | "manual_pending" | "manual" | "defer" | "pass" | "ok";
  };
  policy_binding: {
    risk_tier?: "low" | "medium" | "high" | "critical";
    retry_limit_per_stage?: number;
    budget_limit_usd_monthly?: number;
  };
  effective: {
    execution_template: {
      default_flow: Array<{ stage: string; mode: string; model_profile: string }>;
      retry_policy: { max_retries_per_stage: number; escalate_on: string[] };
      github?: {
        default_ref?: string;
        default_branch?: string;
        ref?: string;
        branch?: string;
        no_checks_policy?: "error" | "success" | "manual_pending";
      };
      default_ref?: string;
      default_branch?: string;
      ref?: string;
      branch?: string;
      no_checks_policy?: "error" | "success" | "manual_pending";
    };
    policy: {
      risk_tier?: "low" | "medium" | "high" | "critical";
      retry_limit_per_stage?: number;
      budget_limit_usd_monthly?: number;
    };
  };
};

type ProjectNoChecksPolicy = "error" | "success" | "manual_pending";

type ProjectToolchainProfileView = {
  project_id: string;
  toolchain_profile: {
    pending_plan?: {
      source?: {
        workspace_path?: string | null;
        repository?: string | null;
      };
      plan?: {
        toolchains?: string[];
        recommended_stack?: string;
        docker_build_args?: Record<string, number>;
        plan_fingerprint?: string;
        confirm_token?: string;
        generated_at?: number;
      };
    } | null;
    approved_plan?: Record<string, unknown> | null;
    last_plan?: Record<string, unknown> | null;
    updated_at?: number;
  };
};

const DEFAULT_PROJECT_TEMPLATE_ID = "backend-python-api";

function createSession(agentType: string, label: string, existingCredentials?: Credential[]): Session {
  return {
    id: makeId(),
    agentType,
    label,
    messages: [],
    graphNodes: [],
    credentials: existingCredentials ? cloneCredentials(existingCredentials) : createFreshCredentials(agentType),
  };
}

// --- NewTabPopover ---
type PopoverStep = "root" | "new-agent-choice" | "clone-pick";

interface NewTabPopoverProps {
  open: boolean;
  onClose: () => void;
  anchorRef: React.RefObject<HTMLButtonElement | null>;
  discoverAgents: DiscoverEntry[];
  onFromScratch: () => void;
  onCloneAgent: (agentPath: string, agentName: string) => void;
}

function NewTabPopover({ open, onClose, anchorRef, discoverAgents, onFromScratch, onCloneAgent }: NewTabPopoverProps) {
  const [step, setStep] = useState<PopoverStep>("root");
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => { if (open) setStep("root"); }, [open]);

  // Compute position from anchor button and keep it within viewport bounds.
  useEffect(() => {
    if (!open) return;

    const updatePosition = () => {
      if (!anchorRef.current) return;
      const rect = anchorRef.current.getBoundingClientRect();
      const POPUP_WIDTH = 240; // w-60 = 15rem = 240px
      const EDGE_MARGIN = 8;
      const preferredLeft =
        rect.left + POPUP_WIDTH > window.innerWidth - EDGE_MARGIN
          ? rect.right - POPUP_WIDTH
          : rect.left;
      const clampedLeft = Math.max(
        EDGE_MARGIN,
        Math.min(preferredLeft, window.innerWidth - POPUP_WIDTH - EDGE_MARGIN),
      );
      setPos({
        top: rect.bottom + 4,
        left: clampedLeft,
      });
    };

    updatePosition();
    window.addEventListener("resize", updatePosition);
    window.addEventListener("scroll", updatePosition, true);
    return () => {
      window.removeEventListener("resize", updatePosition);
      window.removeEventListener("scroll", updatePosition, true);
    };
  }, [open, anchorRef]);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (
        ref.current && !ref.current.contains(e.target as Node) &&
        anchorRef.current && !anchorRef.current.contains(e.target as Node)
      ) onClose();
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open, onClose, anchorRef]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open || !pos) return null;

  const optionClass =
    "flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm text-left transition-colors hover:bg-muted/60 text-foreground";
  const iconWrap =
    "w-7 h-7 rounded-md flex items-center justify-center bg-muted/80 flex-shrink-0";

  return ReactDOM.createPortal(
    <div
      ref={ref}
      style={{ position: "fixed", top: pos.top, left: pos.left, zIndex: 9999 }}
      className="w-60 rounded-xl border border-border/60 bg-card shadow-xl shadow-black/30 overflow-hidden"
    >
      <div className="flex items-center gap-2 px-3 py-2.5 border-b border-border/40">
        {step !== "root" && (
          <button
            onClick={() => setStep(step === "clone-pick" ? "new-agent-choice" : "root")}
            className="p-0.5 rounded hover:bg-muted/60 transition-colors text-muted-foreground hover:text-foreground"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        )}
        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          {step === "root" ? "Add Tab" : step === "new-agent-choice" ? "New Agent" : "Open Agent"}
        </span>
      </div>

      <div className="p-1.5">
        {step === "root" && (
          <>
            <button className={optionClass} onClick={() => setStep("clone-pick")}>
              <span className={iconWrap}><Layers className="w-3.5 h-3.5 text-muted-foreground" /></span>
              <div>
                <div className="font-medium leading-tight">Existing agent</div>
                <div className="text-xs text-muted-foreground mt-0.5">Open another agent's workspace</div>
              </div>
            </button>
            <button className={optionClass} onClick={() => setStep("new-agent-choice")}>
              <span className={iconWrap}><Sparkles className="w-3.5 h-3.5 text-primary" /></span>
              <div>
                <div className="font-medium leading-tight">New agent</div>
                <div className="text-xs text-muted-foreground mt-0.5">Build or clone a fresh agent</div>
              </div>
            </button>
          </>
        )}

        {step === "new-agent-choice" && (
          <>
            <button className={optionClass} onClick={() => { onFromScratch(); onClose(); }}>
              <span className={iconWrap}><Sparkles className="w-3.5 h-3.5 text-primary" /></span>
              <div>
                <div className="font-medium leading-tight">From scratch</div>
                <div className="text-xs text-muted-foreground mt-0.5">Empty pipeline + Queen Bee setup</div>
              </div>
            </button>
            <button className={optionClass} onClick={() => setStep("clone-pick")}>
              <span className={iconWrap}><Layers className="w-3.5 h-3.5 text-muted-foreground" /></span>
              <div>
                <div className="font-medium leading-tight">Clone existing</div>
                <div className="text-xs text-muted-foreground mt-0.5">Start from an existing agent</div>
              </div>
            </button>
          </>
        )}

        {step === "clone-pick" && (
          <div className="flex flex-col max-h-64 overflow-y-auto">
            {discoverAgents.map(agent => (
              <button
                key={agent.path}
                onClick={() => { onCloneAgent(agent.path, agent.name); onClose(); }}
                className="flex items-center gap-2.5 w-full px-3 py-2 rounded-lg text-left transition-colors hover:bg-muted/60 text-foreground"
              >
                <div className="w-6 h-6 rounded-md bg-muted/80 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-3.5 h-3.5 text-muted-foreground" />
                </div>
                <span className="text-sm font-medium">{agent.name}</span>
              </button>
            ))}
            {discoverAgents.length === 0 && (
              <p className="text-xs text-muted-foreground px-3 py-2">No agents found</p>
            )}
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}

function fmtLogTs(ts: string): string {
  try {
    const d = new Date(ts);
    return `[${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}]`;
  } catch {
    return "[--:--:--]";
  }
}

function truncate(s: string, max: number): string {
  return s.length > max ? s.slice(0, max) + "..." : s;
}

type SessionRestoreResult = {
  messages: ChatMessage[];
  restoredPhase: "planning" | "building" | "staging" | "running" | null;
  /** Last flowchart map from events — used to restore flowchart overlay on cold resume. */
  flowchartMap: Record<string, string[]> | null;
  /** Last original draft from events — used to restore flowchart overlay on cold resume. */
  originalDraft: DraftGraphData | null;
};

/**
 * Restore session messages from the persisted event log.
 * Returns an empty result if no event log exists.
 */
async function restoreSessionMessages(
  sessionId: string,
  thread: string,
  agentDisplayName: string,
): Promise<SessionRestoreResult> {
  try {
    const { events } = await sessionsApi.eventsHistory(sessionId);
    if (events.length > 0) {
      const messages: ChatMessage[] = [];
      let runningPhase: ChatMessage["phase"] = undefined;
      let flowchartMap: Record<string, string[]> | null = null;
      let originalDraft: DraftGraphData | null = null;
      for (const evt of events) {
        // Track phase transitions so each message gets the phase it was created in
        const p = evt.type === "queen_phase_changed" ? evt.data?.phase as string
          : evt.type === "node_loop_iteration" ? evt.data?.phase as string | undefined
          : undefined;
        if (p && ["planning", "building", "staging", "running"].includes(p)) {
          runningPhase = p as ChatMessage["phase"];
        }
        // Track last flowchart state for cold restore
        if (evt.type === "flowchart_map_updated" && evt.data) {
          const mapData = evt.data as { map?: Record<string, string[]>; original_draft?: DraftGraphData };
          flowchartMap = mapData.map ?? null;
          originalDraft = mapData.original_draft ?? null;
        }
        const msg = sseEventToChatMessage(evt, thread, agentDisplayName);
        if (!msg) continue;
        if (evt.stream_id === "queen") {
          msg.role = "queen";
          msg.phase = runningPhase;
        }
        messages.push(msg);
      }
      return { messages, restoredPhase: runningPhase ?? null, flowchartMap, originalDraft };
    }
  } catch {
    // Event log not available — session will start fresh.
  }
  return { messages: [], restoredPhase: null, flowchartMap: null, originalDraft: null };
}

// --- Per-agent backend state (consolidated) ---
interface AgentBackendState {
  sessionId: string | null;
  loading: boolean;
  ready: boolean;
  queenReady: boolean;
  error: string | null;
  displayName: string | null;
  graphId: string | null;
  nodeSpecs: NodeSpec[];
  awaitingInput: boolean;
  /** The message ID of the current worker input request (for inline reply box) */
  workerInputMessageId: string | null;
  queenBuilding: boolean;
  /** Queen operating phase — "planning" (design), "building" (coding), "staging" (loaded), or "running" (executing) */
  queenPhase: "planning" | "building" | "staging" | "running";
  /** Draft graph from planning phase (before code generation) */
  draftGraph: DraftGraphData | null;
  /** Original draft (pre-dissolution) for flowchart display during runtime */
  originalDraft: DraftGraphData | null;
  /** Runtime node ID → list of original draft node IDs it absorbed */
  flowchartMap: Record<string, string[]> | null;
  workerRunState: "idle" | "deploying" | "running";
  currentExecutionId: string | null;
  currentRunId: string | null;
  nodeLogs: Record<string, string[]>;
  nodeActionPlans: Record<string, string>;
  subagentReports: { subagent_id: string; message: string; data?: Record<string, unknown>; timestamp: string }[];
  isTyping: boolean;
  isStreaming: boolean;
  /** True only when the queen's LLM is actively processing (not worker) */
  queenIsTyping: boolean;
  /** True only when a worker's LLM is actively processing (not queen) */
  workerIsTyping: boolean;
  llmSnapshots: Record<string, string>;
  activeToolCalls: Record<string, { name: string; done: boolean; streamId: string }>;
  /** True while save_agent_draft tool is running (between tool_call_started and draft_graph_updated) */
  designingDraft: boolean;
  /** Agent folder path — set after scaffolding, used for credential queries */
  agentPath: string | null;
  /** Structured question text from ask_user with options */
  pendingQuestion: string | null;
  /** Predefined choices from ask_user (1-3 items); UI appends "Other" */
  pendingOptions: string[] | null;
  /** Multiple questions from ask_user_multiple */
  pendingQuestions: { id: string; prompt: string; options?: string[] }[] | null;
  /** Whether the pending question came from the queen interaction flow */
  pendingQuestionSource: "queen" | null;
  /** Per-node context window usage (from context_usage_updated events) */
  contextUsage: Record<string, { usagePct: number; messageCount: number; estimatedTokens: number; maxTokens: number }>;
  /** Whether the queen's LLM supports image content — false disables the attach button */
  queenSupportsImages: boolean;
}

function defaultAgentState(): AgentBackendState {
  return {
    sessionId: null,
    loading: true,
    ready: false,
    queenReady: false,
    error: null,
    displayName: null,
    graphId: null,
    nodeSpecs: [],
    awaitingInput: false,
    workerInputMessageId: null,
    queenBuilding: false,
    queenPhase: "planning",
    designingDraft: false,
    draftGraph: null,
    originalDraft: null,
    flowchartMap: null,
    agentPath: null,
    workerRunState: "idle",
    currentExecutionId: null,
    currentRunId: null,
    nodeLogs: {},
    nodeActionPlans: {},
    subagentReports: [],
    isTyping: false,
    isStreaming: false,
    queenIsTyping: false,
    workerIsTyping: false,
    llmSnapshots: {},
    activeToolCalls: {},
    pendingQuestion: null,
    pendingOptions: null,
    pendingQuestions: null,
    pendingQuestionSource: null,
    contextUsage: {},
    queenSupportsImages: true,
  };
}

export default function Workspace() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [projects, setProjects] = useState<ProjectInfo[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string>(
    () => localStorage.getItem(ACTIVE_PROJECT_STORAGE_KEY) || "default",
  );
  const [projectBusy, setProjectBusy] = useState(false);
  const [projectModalOpen, setProjectModalOpen] = useState(false);
  const [projectNameDraft, setProjectNameDraft] = useState("");
  const [projectDescriptionDraft, setProjectDescriptionDraft] = useState("");
  const [projectRepositoryDraft, setProjectRepositoryDraft] = useState("");
  const [projectOnboardEnabled, setProjectOnboardEnabled] = useState(true);
  const [projectWorkspacePathDraft, setProjectWorkspacePathDraft] = useState("");
  const [projectStackDraft, setProjectStackDraft] = useState<"node" | "python" | "go" | "jvm" | "rust" | "fullstack">("node");
  const [projectTemplates, setProjectTemplates] = useState<ProjectTemplateProfile[]>([]);
  const [projectTemplateIdDraft, setProjectTemplateIdDraft] = useState(DEFAULT_PROJECT_TEMPLATE_ID);
  const [projectCreateError, setProjectCreateError] = useState<string | null>(null);
  const [projectMetrics, setProjectMetrics] = useState<ProjectMetrics | null>(null);
  const [projectMetricsLoading, setProjectMetricsLoading] = useState(false);
  const [projectMetricsError, setProjectMetricsError] = useState<string | null>(null);
  const [projectMetricsBoardOpen, setProjectMetricsBoardOpen] = useState(false);
  const [projectMetricsRows, setProjectMetricsRows] = useState<ProjectComparisonRow[]>([]);
  const [projectMetricsBoardLoading, setProjectMetricsBoardLoading] = useState(false);
  const [projectMetricsBoardError, setProjectMetricsBoardError] = useState<string | null>(null);
  const [projectMetricsSortBy, setProjectMetricsSortBy] = useState<"success_rate" | "executions_total" | "cycle_time_p50" | "intervention_ratio">("success_rate");
  const [projectRetentionOpen, setProjectRetentionOpen] = useState(false);
  const [projectRetentionLoading, setProjectRetentionLoading] = useState(false);
  const [projectRetentionSaving, setProjectRetentionSaving] = useState(false);
  const [projectRetentionApplying, setProjectRetentionApplying] = useState(false);
  const [projectRetentionError, setProjectRetentionError] = useState<string | null>(null);
  const [projectRetentionData, setProjectRetentionData] = useState<ProjectRetentionView | null>(null);
  const [projectRetentionHistoryDaysDraft, setProjectRetentionHistoryDaysDraft] = useState("30");
  const [projectRetentionMinKeepDraft, setProjectRetentionMinKeepDraft] = useState("20");
  const [projectRetentionArchiveEnabledDraft, setProjectRetentionArchiveEnabledDraft] = useState(true);
  const [projectRetentionArchiveRootDraft, setProjectRetentionArchiveRootDraft] = useState("~/.hive/queen/archive");
  const [projectRetentionRunResult, setProjectRetentionRunResult] = useState<Record<string, unknown> | null>(null);
  const [projectExecutionOpen, setProjectExecutionOpen] = useState(false);
  const [projectExecutionLoading, setProjectExecutionLoading] = useState(false);
  const [projectExecutionSaving, setProjectExecutionSaving] = useState(false);
  const [projectExecutionError, setProjectExecutionError] = useState<string | null>(null);
  const [projectExecutionData, setProjectExecutionData] = useState<ProjectExecutionTemplateView | null>(null);
  const [projectExecutionDesignProfileDraft, setProjectExecutionDesignProfileDraft] = useState("strategy_heavy");
  const [projectExecutionImplementProfileDraft, setProjectExecutionImplementProfileDraft] = useState("implementation");
  const [projectExecutionReviewProfileDraft, setProjectExecutionReviewProfileDraft] = useState("review_validation");
  const [projectExecutionValidateProfileDraft, setProjectExecutionValidateProfileDraft] = useState("review_validation");
  const [projectExecutionRetryDraft, setProjectExecutionRetryDraft] = useState("1");
  const [projectExecutionEscalateOnDraft, setProjectExecutionEscalateOnDraft] = useState("review,validate");
  const [projectExecutionGithubDefaultRefDraft, setProjectExecutionGithubDefaultRefDraft] = useState("");
  const [projectExecutionNoChecksPolicyDraft, setProjectExecutionNoChecksPolicyDraft] = useState<ProjectNoChecksPolicy>("error");
  const [projectExecutionRiskTierDraft, setProjectExecutionRiskTierDraft] = useState<"low" | "medium" | "high" | "critical">("low");
  const [projectExecutionPolicyRetryDraft, setProjectExecutionPolicyRetryDraft] = useState("2");
  const [projectExecutionBudgetDraft, setProjectExecutionBudgetDraft] = useState("");
  const [projectToolchainOpen, setProjectToolchainOpen] = useState(false);
  const [projectToolchainLoading, setProjectToolchainLoading] = useState(false);
  const [projectToolchainPlanning, setProjectToolchainPlanning] = useState(false);
  const [projectToolchainApproving, setProjectToolchainApproving] = useState(false);
  const [projectToolchainError, setProjectToolchainError] = useState<string | null>(null);
  const [projectToolchainData, setProjectToolchainData] = useState<ProjectToolchainProfileView | null>(null);
  const [projectToolchainWorkspaceDraft, setProjectToolchainWorkspaceDraft] = useState("");
  const [projectToolchainRepositoryDraft, setProjectToolchainRepositoryDraft] = useState("");
  const [projectToolchainConfirmDraft, setProjectToolchainConfirmDraft] = useState("");
  const [projectToolchainInstructions, setProjectToolchainInstructions] = useState<{
    preview_command?: string;
    apply_command?: string;
    env_exports?: string[];
  } | null>(null);
  const [projectAutonomousOpen, setProjectAutonomousOpen] = useState(false);
  const [projectAutonomousLoading, setProjectAutonomousLoading] = useState(false);
  const [projectAutonomousError, setProjectAutonomousError] = useState<string | null>(null);
  const [projectAutonomousBacklog, setProjectAutonomousBacklog] = useState<AutonomousBacklogTask[]>([]);
  const [projectAutonomousRuns, setProjectAutonomousRuns] = useState<AutonomousPipelineRun[]>([]);
  const [projectAutonomousCreating, setProjectAutonomousCreating] = useState(false);
  const [projectAutonomousActionBusy, setProjectAutonomousActionBusy] = useState(false);
  const [projectAutonomousTaskTitleDraft, setProjectAutonomousTaskTitleDraft] = useState("");
  const [projectAutonomousTaskGoalDraft, setProjectAutonomousTaskGoalDraft] = useState("");
  const [projectAutonomousTaskCriteriaDraft, setProjectAutonomousTaskCriteriaDraft] = useState("");
  const [projectAutonomousTaskPriorityDraft, setProjectAutonomousTaskPriorityDraft] = useState<"low" | "medium" | "high" | "critical">("medium");
  const [projectAutonomousTaskRepositoryDraft, setProjectAutonomousTaskRepositoryDraft] = useState("");
  const [projectAutonomousTaskBranchDraft, setProjectAutonomousTaskBranchDraft] = useState("");
  const [projectAutonomousLiveSessions, setProjectAutonomousLiveSessions] = useState<LiveSession[]>([]);
  const [projectAutonomousRunSessionIdDraft, setProjectAutonomousRunSessionIdDraft] = useState("");
  const [projectAutonomousGitHubRepoDraft, setProjectAutonomousGitHubRepoDraft] = useState("");
  const [projectAutonomousGitHubRefDraft, setProjectAutonomousGitHubRefDraft] = useState("");
  const [projectAutonomousGitHubPrUrlDraft, setProjectAutonomousGitHubPrUrlDraft] = useState("");
  const [projectAutonomousGitHubRequiredChecksDraft, setProjectAutonomousGitHubRequiredChecksDraft] = useState("");
  const [projectAutonomousSelectedRunId, setProjectAutonomousSelectedRunId] = useState<string | null>(null);
  const [projectAutonomousAdvanceResultDraft, setProjectAutonomousAdvanceResultDraft] = useState<"success" | "failed">("success");
  const [projectAutonomousAdvanceNotesDraft, setProjectAutonomousAdvanceNotesDraft] = useState("");
  const [projectAutonomousChecksDraft, setProjectAutonomousChecksDraft] = useState("review:pass");
  const [projectAutonomousReportData, setProjectAutonomousReportData] = useState<Record<string, unknown> | null>(null);
  const [projectAutonomousCycleSummary, setProjectAutonomousCycleSummary] = useState<Record<string, unknown> | null>(null);
  const [projectAutonomousCycleResult, setProjectAutonomousCycleResult] = useState<Record<string, unknown> | null>(null);
  const [projectAutonomousOpsStatus, setProjectAutonomousOpsStatus] = useState<AutonomousOpsStatusResponse | null>(null);
  const [projectAutonomousOpsLoading, setProjectAutonomousOpsLoading] = useState(false);
  const [projectAutonomousRemediateActionDraft, setProjectAutonomousRemediateActionDraft] = useState<"failed" | "escalated">("escalated");
  const [projectAutonomousRemediateOlderThanDraft, setProjectAutonomousRemediateOlderThanDraft] = useState("1800");
  const [projectAutonomousRemediateMaxRunsDraft, setProjectAutonomousRemediateMaxRunsDraft] = useState("25");
  const [projectAutonomousRemediateBusy, setProjectAutonomousRemediateBusy] = useState(false);
  const [projectAutonomousRemediateResult, setProjectAutonomousRemediateResult] = useState<AutonomousRemediateStaleResponse | null>(null);
  const [projectAutonomousLastExecutionSnapshot, setProjectAutonomousLastExecutionSnapshot] = useState<Record<string, unknown> | null>(null);
  const rawAgent = searchParams.get("agent") || "new-agent";
  const hasExplicitAgent = searchParams.has("agent");
  const initialPrompt = searchParams.get("prompt") || "";
  // ?session= param: when navigating from the home history sidebar, this
  // carries the backendSessionId to open as a tab on mount.
  const initialSessionId = searchParams.get("session") || "";

  // When submitting a new prompt from home for "new-agent", use a unique key
  // so each prompt gets its own tab instead of overwriting the previous one.
  const [initialAgent] = useState(() =>
    initialPrompt && hasExplicitAgent && rawAgent === "new-agent"
      ? `new-agent-${makeId()}`
      : rawAgent
  );

  // Sessions grouped by agent type — restore from localStorage if available
  const [sessionsByAgent, setSessionsByAgent] = useState<Record<string, Session[]>>(() => {
    const persisted = loadPersistedTabs();
    const initial: Record<string, Session[]> = {};

    if (persisted) {
      for (const tab of persisted.tabs) {
        // tabKey is the actual key used in sessionsByAgent (may contain "::" suffix).
        // Fall back to agentType for tabs persisted before this field was added.
        const tabKey = tab.tabKey || tab.agentType;
        // New-agent tabs each have a unique key (e.g. "new-agent-abc123"),
        // so they never collide with the incoming tab — always restore them.
        if (!initial[tabKey]) initial[tabKey] = [];
        const session = createSession(tab.agentType, tab.label);
        session.id = tab.id;
        session.backendSessionId = tab.backendSessionId;
        session.tabKey = tab.tabKey; // restore so future persistence uses correct key
        session.historySourceId = tab.historySourceId;
        // Restore messages and graph from localStorage (up to 50 messages).
        // If the backend session is still alive, loadAgentForType may
        // append additional messages fetched from the server.
        const cached = persisted.sessions?.[tab.id];
        if (cached) {
          session.messages = cached.messages || [];
          session.graphNodes = cached.graphNodes || [];
        }
        initial[tabKey].push(session);
      }
    }

    // If persisted tabs were restored and user didn't explicitly request
    // a different agent via URL, return restored tabs as-is.
    if (persisted && Object.keys(initial).length > 0 && !hasExplicitAgent) {
      return initial;
    }

    // If there are already persisted tabs for this agent type, don't create
    // a new one — the post-mount effect will call handleHistoryOpen if needed
    // (for ?session= params coming from the home page sidebar).
    if (initial[initialAgent]?.length) {
      return initial;
    }
    // Also check for existing tabs with instance suffixes (e.g. "agentType::instanceId")
    const existingKey = Object.keys(initial).find(
      k => baseAgentType(k) === initialAgent && initial[k]?.length > 0
    );
    if (existingKey && !initialPrompt) {
      return initial;
    }

    // If the user submitted a new prompt from the home page, always create
    // a fresh session so the prompt isn't lost into an existing session.
    // initialAgent is already a unique key (e.g. "new-agent-abc123") when
    // coming from home, so the new tab won't overwrite existing ones.
    if (initialPrompt && hasExplicitAgent) {
      const rawLabel = initialAgent.startsWith("new-agent")
        ? "New Agent"
        : formatAgentDisplayName(initialAgent);
      const existingNewAgentCount = Object.keys(initial).filter(
        k => (k === "new-agent" || k.startsWith("new-agent-")) && (initial[k] || []).length > 0
      ).length;
      const label = existingNewAgentCount === 0 ? rawLabel : `${rawLabel} #${existingNewAgentCount + 1}`;
      const newSession = createSession(initialAgent, label);
      initial[initialAgent] = [newSession];
      return initial;
    }

    // Only create a fresh default tab when there are no persisted tabs at all.
    // If ?session= was passed we intentionally do NOT create a tab here —
    // handleHistoryOpen is called post-mount and does proper dedup.
    if (initialAgent === "new-agent") {
      const s = createSession("new-agent", "New Agent");
      initial["new-agent"] = [...(initial["new-agent"] || []), s];
    } else if (!initialSessionId) {
      // Only auto-create an agent tab if there's no session to restore
      const s = createSession(initialAgent, formatAgentDisplayName(initialAgent));
      initial[initialAgent] = [...(initial[initialAgent] || []), s];
    }

    return initial;
  });

  const [activeSessionByAgent, setActiveSessionByAgent] = useState<Record<string, string>>(() => {
    const persisted = loadPersistedTabs();
    // If initialSessionId maps to an already-restored tab, activate that tab
    if (initialSessionId) {
      for (const [tabKey, sessions] of Object.entries(sessionsByAgent)) {
        const match = sessions.find(
          s => s.backendSessionId === initialSessionId || s.historySourceId === initialSessionId,
        );
        if (match) {
          return { ...(persisted?.activeSessionByAgent ?? {}), [tabKey]: match.id };
        }
      }
    }
    if (persisted) {
      let restored = { ...persisted.activeSessionByAgent };
      // Remove stale new-agent-* entries when starting fresh from home
      if (initialPrompt && hasExplicitAgent) {
        restored = Object.fromEntries(
          Object.entries(restored).filter(([key]) =>
            key !== "new-agent" && !key.startsWith("new-agent-")
          )
        );
      }
      const urlSessions = sessionsByAgent[initialAgent];
      if (urlSessions?.length) {
        // When a prompt was submitted from home, activate the newly created
        // session (last in array) instead of the previously active one.
        if (initialPrompt && hasExplicitAgent) {
          restored[initialAgent] = urlSessions[urlSessions.length - 1].id;
        } else if (!restored[initialAgent]) {
          restored[initialAgent] = urlSessions[0].id;
        }
      }
      return restored;
    }
    const sessions = sessionsByAgent[initialAgent];
    return sessions ? { [initialAgent]: sessions[0].id } : {};
  });

  const [activeWorker, setActiveWorker] = useState(() => {
    // If initialSessionId maps to an already-restored tab, activate that key
    if (initialSessionId) {
      for (const [tabKey, sessions] of Object.entries(sessionsByAgent)) {
        if (sessions.some(
          s => s.backendSessionId === initialSessionId || s.historySourceId === initialSessionId,
        )) return tabKey;
      }
    }
    if (!hasExplicitAgent) {
      const persisted = loadPersistedTabs();
      if (persisted?.activeWorker) return persisted.activeWorker;
    }
    return initialAgent;
  });

  // Clear URL params after mount — they're consumed during initialization
  // and leaving them causes confusion (stale ?agent= after tab switches, etc.)
  useEffect(() => {
    navigate("/workspace", { replace: true });
  }, []);

  // Post-mount: if the URL carried a ?session= param (from the home page history
  // sidebar), open it via handleHistoryOpen instead of creating a tab in init state.
  // This is the single canonical path — it has robust dedup (checks backendSessionId
  // AND historySourceId across all in-memory tabs) and is safe to call after persisted
  // state has been hydrated.
  // We capture initialSessionId and related URL params in stable refs so the effect
  // only fires once on mount, regardless of re-renders.
  const initialSessionIdRef = useRef(initialSessionId);
  const initialAgentRef = useRef(initialAgent);
  const mountedRef = useRef(false);
  const [credentialsOpen, setCredentialsOpen] = useState(false);
  const [credentialReadiness, setCredentialReadiness] =
    useState<CredentialReadinessResponse | null>(null);
  const [credentialReadinessLoading, setCredentialReadinessLoading] = useState(false);
  const [credentialReadinessError, setCredentialReadinessError] = useState<string | null>(null);
  const [credentialReadinessOpen, setCredentialReadinessOpen] = useState(false);
  const [credentialReadinessShowAllProviders, setCredentialReadinessShowAllProviders] = useState(false);
  // Explicit agent path for the credentials modal — set from 424 responses
  // when activeWorker doesn't match the actual agent (e.g. "new-agent" tab).
  const [credentialAgentPath, setCredentialAgentPath] = useState<string | null>(null);
  const [dismissedBanner, setDismissedBanner] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [triggerTaskDraft, setTriggerTaskDraft] = useState("");
  const [triggerCronDraft, setTriggerCronDraft] = useState("");
  const [triggerTaskSaving, setTriggerTaskSaving] = useState(false);
  const [triggerScheduleSaving, setTriggerScheduleSaving] = useState(false);
  const [triggerCronSaved, setTriggerCronSaved] = useState(false);
  const [triggerTaskSaved, setTriggerTaskSaved] = useState(false);
  const [newTabOpen, setNewTabOpen] = useState(false);
  const newTabBtnRef = useRef<HTMLButtonElement>(null);
  const [graphPanelPct, setGraphPanelPct] = useState(30);
  const savedGraphPanelPct = useRef(30);
  const resizing = useRef(false);

  // Drag-to-resize the graph panel
  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (!resizing.current) return;
      const pct = (e.clientX / window.innerWidth) * 100;
      setGraphPanelPct(Math.max(15, Math.min(50, pct)));
    };
    const onMouseUp = () => {
      resizing.current = false;
      document.body.style.cursor = "";
    };
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  }, []);

  // Shrink graph panel when node detail opens, restore when it closes
  const nodeIsSelected = selectedNode !== null;
  useEffect(() => {
    if (nodeIsSelected) {
      savedGraphPanelPct.current = graphPanelPct;
      setGraphPanelPct(prev => Math.min(prev, 30));
    } else {
      setGraphPanelPct(savedGraphPanelPct.current);
    }
  }, [nodeIsSelected]); // eslint-disable-line react-hooks/exhaustive-deps

  // Ref mirror of sessionsByAgent so SSE callback can read current graph
  // state without adding sessionsByAgent to its dependency array.
  const sessionsRef = useRef(sessionsByAgent);
  sessionsRef.current = sessionsByAgent;

  // Ref mirror of activeSessionByAgent so setSessionsByAgent updater
  // functions always read the *current* active session id, avoiding stale
  // closures that can silently drop messages / graph updates.
  const activeSessionRef = useRef(activeSessionByAgent);
  activeSessionRef.current = activeSessionByAgent;

  // Synchronous per-agent turn counter for SSE message IDs.
  // Using a ref avoids stale-closure bugs when multiple SSE events
  // arrive in the same React batch.
  const turnCounterRef = useRef<Record<string, number>>({});
  // Per-agent queen phase ref — used to stamp each message with the phase
  // it was created in (avoids stale-closure when phase change and message
  // events arrive in the same React batch).
  const queenPhaseRef = useRef<Record<string, string>>({});
  // Accumulated queen text across inner_turns within the same iteration.
  // Key: `${agentType}:${execution_id}:${iteration}`, value: { [inner_turn]: snapshot }.
  // This lets us merge all inner_turn text into one chat bubble per iteration.
  const queenIterTextRef = useRef<Record<string, Record<number, string>>>({});
  // Timestamp when designingDraft was set — used to enforce minimum spinner duration.
  const designingDraftSinceRef = useRef<Record<string, number>>({});
  const designingDraftTimerRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  // Synchronous ref to suppress the queen's auto-intro SSE messages
  // after a cold-restore (where we already restored the conversation from disk).
  // Using a ref avoids the race condition where sessionId is set in agentState
  // (opening SSE) before the suppressQueenIntro flag can be committed.
  const suppressIntroRef = useRef(new Set<string>());

  // --- Consolidated per-agent backend state ---
  const [agentStates, setAgentStates] = useState<Record<string, AgentBackendState>>({});

  const refreshProjects = useCallback(async () => {
    const data = await projectsApi.list();
    setProjects(data.projects || []);
    const nextActive = (activeProjectId && data.projects.some(p => p.id === activeProjectId))
      ? activeProjectId
      : data.default_project_id;
    setActiveProjectId(nextActive);
    localStorage.setItem(ACTIVE_PROJECT_STORAGE_KEY, nextActive);
  }, [activeProjectId]);

  useEffect(() => {
    refreshProjects().catch(() => {});
  }, [refreshProjects]);

  const refreshProjectTemplates = useCallback(async () => {
    try {
      const data = await projectsApi.templates();
      const templates = Array.isArray(data.templates) ? (data.templates as ProjectTemplateProfile[]) : [];
      setProjectTemplates(templates);
      if (templates.length > 0 && !templates.some((t) => t.id === projectTemplateIdDraft)) {
        setProjectTemplateIdDraft(templates[0].id);
        setProjectStackDraft(templates[0].stack);
      }
    } catch {
      // Keep create modal usable even if template catalog is temporarily unavailable.
      setProjectTemplates([]);
    }
  }, [projectTemplateIdDraft]);

  useEffect(() => {
    refreshProjectTemplates().catch(() => {});
  }, [refreshProjectTemplates]);

  const selectedProjectTemplate = useMemo(
    () => projectTemplates.find((t) => t.id === projectTemplateIdDraft) ?? null,
    [projectTemplateIdDraft, projectTemplates],
  );

  const refreshCredentialReadiness = useCallback(async () => {
    setCredentialReadinessLoading(true);
    setCredentialReadinessError(null);
    try {
      const data = await credentialsApi.readiness("local_pro_stack");
      setCredentialReadiness(data);
    } catch (e) {
      setCredentialReadinessError(e instanceof Error ? e.message : String(e));
    } finally {
      setCredentialReadinessLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshCredentialReadiness().catch(() => {});
  }, [refreshCredentialReadiness]);

  const refreshProjectMetrics = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectMetricsLoading(true);
    setProjectMetricsError(null);
    try {
      const data = await projectsApi.metrics(activeProjectId);
      setProjectMetrics(data as ProjectMetrics);
    } catch (e) {
      setProjectMetricsError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectMetricsLoading(false);
    }
  }, [activeProjectId]);

  useEffect(() => {
    refreshProjectMetrics().catch(() => {});
  }, [refreshProjectMetrics]);

  const refreshProjectMetricsBoard = useCallback(async () => {
    setProjectMetricsBoardLoading(true);
    setProjectMetricsBoardError(null);
    try {
      const data = await projectsApi.compareMetrics();
      setProjectMetricsRows(Array.isArray(data.projects) ? (data.projects as ProjectComparisonRow[]) : []);
    } catch (e) {
      setProjectMetricsBoardError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectMetricsBoardLoading(false);
    }
  }, []);

  const sortedProjectMetricsRows = useMemo(() => {
    const rows = [...projectMetricsRows];
    const numeric = (v: number | null | undefined, fallback = -1) => (v === null || v === undefined ? fallback : v);
    rows.sort((a, b) => {
      if (projectMetricsSortBy === "executions_total") {
        return numeric(b.summary.executions_total, 0) - numeric(a.summary.executions_total, 0);
      }
      if (projectMetricsSortBy === "cycle_time_p50") {
        return numeric(a.kpis.cycle_time_seconds_p50, Number.POSITIVE_INFINITY) - numeric(b.kpis.cycle_time_seconds_p50, Number.POSITIVE_INFINITY);
      }
      if (projectMetricsSortBy === "intervention_ratio") {
        return numeric(b.kpis.intervention_ratio, 0) - numeric(a.kpis.intervention_ratio, 0);
      }
      return numeric(b.kpis.success_rate) - numeric(a.kpis.success_rate);
    });
    return rows;
  }, [projectMetricsRows, projectMetricsSortBy]);

  const refreshProjectRetention = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectRetentionLoading(true);
    setProjectRetentionError(null);
    try {
      const data = await projectsApi.retention(activeProjectId);
      const view = data as ProjectRetentionView;
      setProjectRetentionData(view);
      setProjectRetentionHistoryDaysDraft(String(view.effective.history_days ?? 30));
      setProjectRetentionMinKeepDraft(String(view.effective.min_sessions_to_keep ?? 20));
      setProjectRetentionArchiveEnabledDraft(Boolean(view.effective.archive_enabled));
      setProjectRetentionArchiveRootDraft(String(view.effective.archive_root || "~/.hive/queen/archive"));
    } catch (e) {
      setProjectRetentionError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectRetentionLoading(false);
    }
  }, [activeProjectId]);

  const saveProjectRetentionPolicy = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectRetentionSaving(true);
    setProjectRetentionError(null);
    try {
      const historyDays = Number.parseInt(projectRetentionHistoryDaysDraft, 10);
      const minKeep = Number.parseInt(projectRetentionMinKeepDraft, 10);
      await projectsApi.updateRetention(activeProjectId, {
        history_days: Number.isFinite(historyDays) ? historyDays : null,
        min_sessions_to_keep: Number.isFinite(minKeep) ? minKeep : null,
        archive_enabled: projectRetentionArchiveEnabledDraft,
        archive_root: projectRetentionArchiveRootDraft.trim() || null,
      });
      await refreshProjectRetention();
    } catch (e) {
      setProjectRetentionError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectRetentionSaving(false);
    }
  }, [
    activeProjectId,
    projectRetentionArchiveEnabledDraft,
    projectRetentionArchiveRootDraft,
    projectRetentionHistoryDaysDraft,
    projectRetentionMinKeepDraft,
    refreshProjectRetention,
  ]);

  const runProjectRetention = useCallback(async (dryRun: boolean) => {
    if (!activeProjectId) return;
    setProjectRetentionApplying(true);
    setProjectRetentionError(null);
    setProjectRetentionRunResult(null);
    try {
      const historyDays = Number.parseInt(projectRetentionHistoryDaysDraft, 10);
      const minKeep = Number.parseInt(projectRetentionMinKeepDraft, 10);
      const data = await projectsApi.applyRetention(activeProjectId, {
        dry_run: dryRun,
        history_days: Number.isFinite(historyDays) ? historyDays : undefined,
        min_sessions_to_keep: Number.isFinite(minKeep) ? minKeep : undefined,
        archive_enabled: projectRetentionArchiveEnabledDraft,
        archive_root: projectRetentionArchiveRootDraft.trim() || undefined,
      });
      setProjectRetentionRunResult(data as unknown as Record<string, unknown>);
      await refreshProjectRetention();
    } catch (e) {
      setProjectRetentionError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectRetentionApplying(false);
    }
  }, [
    activeProjectId,
    projectRetentionArchiveEnabledDraft,
    projectRetentionArchiveRootDraft,
    projectRetentionHistoryDaysDraft,
    projectRetentionMinKeepDraft,
    refreshProjectRetention,
  ]);

  useEffect(() => {
    refreshProjectRetention().catch(() => {});
  }, [refreshProjectRetention]);

  const refreshProjectExecutionTemplate = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectExecutionLoading(true);
    setProjectExecutionError(null);
    try {
      const data = await projectsApi.executionTemplate(activeProjectId);
      const view = data as ProjectExecutionTemplateView;
      const normalizeNoChecksPolicy = (value: unknown): ProjectNoChecksPolicy => {
        const raw = String(value || "").trim().toLowerCase();
        if (raw === "manual" || raw === "defer" || raw === "manual_pending") return "manual_pending";
        if (raw === "pass" || raw === "ok" || raw === "success") return "success";
        return "error";
      };
      setProjectExecutionData(view);
      const flow = view.effective.execution_template.default_flow || [];
      const byStage = new Map(flow.map((row) => [row.stage, row.model_profile]));
      setProjectExecutionDesignProfileDraft(byStage.get("design") || "strategy_heavy");
      setProjectExecutionImplementProfileDraft(byStage.get("implement") || "implementation");
      setProjectExecutionReviewProfileDraft(byStage.get("review") || "review_validation");
      setProjectExecutionValidateProfileDraft(byStage.get("validate") || "review_validation");
      setProjectExecutionRetryDraft(String(view.effective.execution_template.retry_policy.max_retries_per_stage ?? 1));
      setProjectExecutionEscalateOnDraft((view.effective.execution_template.retry_policy.escalate_on || ["review", "validate"]).join(","));
      setProjectExecutionRiskTierDraft(
        (view.effective.policy.risk_tier as "low" | "medium" | "high" | "critical" | undefined) || "low",
      );
      setProjectExecutionPolicyRetryDraft(String(view.effective.policy.retry_limit_per_stage ?? 2));
      setProjectExecutionBudgetDraft(
        view.effective.policy.budget_limit_usd_monthly === undefined || view.effective.policy.budget_limit_usd_monthly === null
          ? ""
          : String(view.effective.policy.budget_limit_usd_monthly),
      );
      const projectGitHub = view.execution_template.github || {};
      const effectiveGitHub = view.effective.execution_template.github || {};
      const githubDefaultRef =
        projectGitHub.default_ref ||
        projectGitHub.default_branch ||
        view.execution_template.default_ref ||
        view.execution_template.default_branch ||
        effectiveGitHub.default_ref ||
        effectiveGitHub.default_branch ||
        view.effective.execution_template.default_ref ||
        view.effective.execution_template.default_branch ||
        "";
      const githubNoChecksPolicyRaw =
        projectGitHub.no_checks_policy ||
        view.execution_template.no_checks_policy ||
        effectiveGitHub.no_checks_policy ||
        view.effective.execution_template.no_checks_policy ||
        "error";
      setProjectExecutionGithubDefaultRefDraft(githubDefaultRef);
      setProjectExecutionNoChecksPolicyDraft(normalizeNoChecksPolicy(githubNoChecksPolicyRaw));
    } catch (e) {
      setProjectExecutionError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectExecutionLoading(false);
    }
  }, [activeProjectId]);

  const saveProjectExecutionTemplate = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectExecutionSaving(true);
    setProjectExecutionError(null);
    try {
      const maxRetries = Number.parseInt(projectExecutionRetryDraft, 10);
      const policyRetry = Number.parseInt(projectExecutionPolicyRetryDraft, 10);
      const budget = Number.parseFloat(projectExecutionBudgetDraft);
      const escalateOn = projectExecutionEscalateOnDraft
        .split(",")
        .map((part) => part.trim().toLowerCase())
        .filter(Boolean);
      await projectsApi.updateExecutionTemplate(activeProjectId, {
        execution_template: {
          default_flow: [
            { stage: "design", mode: "queen_plan", model_profile: projectExecutionDesignProfileDraft.trim() || "strategy_heavy" },
            { stage: "implement", mode: "worker_execute", model_profile: projectExecutionImplementProfileDraft.trim() || "implementation" },
            { stage: "review", mode: "worker_review", model_profile: projectExecutionReviewProfileDraft.trim() || "review_validation" },
            { stage: "validate", mode: "worker_validate", model_profile: projectExecutionValidateProfileDraft.trim() || "review_validation" },
          ],
          retry_policy: {
            max_retries_per_stage: Number.isFinite(maxRetries) ? maxRetries : 1,
            escalate_on: escalateOn,
          },
          github: {
            default_ref: projectExecutionGithubDefaultRefDraft.trim() || null,
            no_checks_policy: projectExecutionNoChecksPolicyDraft,
          },
        },
        policy_binding: {
          risk_tier: projectExecutionRiskTierDraft,
          retry_limit_per_stage: Number.isFinite(policyRetry) ? policyRetry : null,
          budget_limit_usd_monthly: Number.isFinite(budget) ? budget : null,
        },
      });
      await refreshProjectExecutionTemplate();
      await refreshProjects();
    } catch (e) {
      setProjectExecutionError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectExecutionSaving(false);
    }
  }, [
    activeProjectId,
    projectExecutionBudgetDraft,
    projectExecutionDesignProfileDraft,
    projectExecutionEscalateOnDraft,
    projectExecutionGithubDefaultRefDraft,
    projectExecutionImplementProfileDraft,
    projectExecutionNoChecksPolicyDraft,
    projectExecutionPolicyRetryDraft,
    projectExecutionRetryDraft,
    projectExecutionReviewProfileDraft,
    projectExecutionRiskTierDraft,
    projectExecutionValidateProfileDraft,
    refreshProjectExecutionTemplate,
    refreshProjects,
  ]);

  useEffect(() => {
    refreshProjectExecutionTemplate().catch(() => {});
  }, [refreshProjectExecutionTemplate]);

  const refreshProjectToolchainProfile = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectToolchainLoading(true);
    setProjectToolchainError(null);
    try {
      const data = (await projectsApi.toolchainProfile(activeProjectId)) as ProjectToolchainProfileView;
      setProjectToolchainData(data);
      const pending = data.toolchain_profile?.pending_plan;
      const pendingSource = pending?.source || {};
      const pendingPlan = pending?.plan || {};
      if (pendingSource.workspace_path) {
        setProjectToolchainWorkspaceDraft(String(pendingSource.workspace_path));
      }
      if (pendingSource.repository) {
        setProjectToolchainRepositoryDraft(String(pendingSource.repository));
      } else if (!pendingSource.workspace_path) {
        const active = projects.find((p) => p.id === activeProjectId);
        if (active?.repository) setProjectToolchainRepositoryDraft(active.repository);
      }
      const token = String(pendingPlan.confirm_token || "");
      if (token) setProjectToolchainConfirmDraft(token);
    } catch (e) {
      setProjectToolchainError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectToolchainLoading(false);
    }
  }, [activeProjectId, projects]);

  const planProjectToolchainProfile = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectToolchainPlanning(true);
    setProjectToolchainError(null);
    try {
      const workspace = projectToolchainWorkspaceDraft.trim();
      const repository = projectToolchainRepositoryDraft.trim();
      const payload: { workspace_path?: string; repository?: string } = {};
      if (workspace) payload.workspace_path = workspace;
      if (!workspace && repository) payload.repository = repository;
      const data = await projectsApi.planToolchainProfile(activeProjectId, payload);
      setProjectToolchainInstructions(data.instructions || null);
      const pending = (data.pending_plan || {}) as {
        plan?: { confirm_token?: string };
      };
      const token = String(pending.plan?.confirm_token || "");
      if (token) setProjectToolchainConfirmDraft(token);
      await refreshProjectToolchainProfile();
      await refreshProjects();
    } catch (e) {
      setProjectToolchainError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectToolchainPlanning(false);
    }
  }, [
    activeProjectId,
    projectToolchainRepositoryDraft,
    projectToolchainWorkspaceDraft,
    refreshProjectToolchainProfile,
    refreshProjects,
  ]);

  const approveProjectToolchainProfile = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectToolchainApproving(true);
    setProjectToolchainError(null);
    try {
      const token = projectToolchainConfirmDraft.trim();
      if (!token) {
        throw new Error("confirm token is required");
      }
      const data = await projectsApi.approveToolchainProfile(activeProjectId, {
        confirm_token: token,
        revalidate: true,
      });
      setProjectToolchainInstructions(data.instructions || null);
      await refreshProjectToolchainProfile();
      await refreshProjects();
    } catch (e) {
      setProjectToolchainError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectToolchainApproving(false);
    }
  }, [activeProjectId, projectToolchainConfirmDraft, refreshProjectToolchainProfile, refreshProjects]);

  useEffect(() => {
    refreshProjectToolchainProfile().catch(() => {});
  }, [refreshProjectToolchainProfile]);

  const refreshProjectAutonomousOpsStatus = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectAutonomousOpsLoading(true);
    try {
      const ops = await autonomousApi.opsStatus({ project_id: activeProjectId, include_runs: true });
      setProjectAutonomousOpsStatus(ops as AutonomousOpsStatusResponse);
    } finally {
      setProjectAutonomousOpsLoading(false);
    }
  }, [activeProjectId]);

  const refreshProjectAutonomous = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectAutonomousLoading(true);
    setProjectAutonomousError(null);
    try {
      const [backlog, runs, sessionsData, ops] = await Promise.all([
        autonomousApi.listBacklog(activeProjectId),
        autonomousApi.listRuns(activeProjectId),
        sessionsApi.list(activeProjectId),
        autonomousApi.opsStatus({ project_id: activeProjectId, include_runs: true }),
      ]);
      const backlogItems = Array.isArray(backlog.tasks) ? backlog.tasks : [];
      const runItems = Array.isArray(runs.runs) ? runs.runs : [];
      const liveSessions = Array.isArray(sessionsData.sessions) ? sessionsData.sessions : [];
      setProjectAutonomousBacklog(backlogItems);
      setProjectAutonomousRuns(runItems);
      setProjectAutonomousLiveSessions(liveSessions);
      if (!projectAutonomousRunSessionIdDraft && liveSessions.length > 0) {
        setProjectAutonomousRunSessionIdDraft(liveSessions[0].session_id);
      }
      if (projectAutonomousRunSessionIdDraft && !liveSessions.some((s) => s.session_id === projectAutonomousRunSessionIdDraft)) {
        setProjectAutonomousRunSessionIdDraft(liveSessions[0]?.session_id || "");
      }
      if (!projectAutonomousSelectedRunId && runItems.length > 0) {
        setProjectAutonomousSelectedRunId(runItems[0].id);
      }
      if (projectAutonomousSelectedRunId && !runItems.some((r) => r.id === projectAutonomousSelectedRunId)) {
        setProjectAutonomousSelectedRunId(runItems[0]?.id ?? null);
      }
      setProjectAutonomousOpsStatus(ops as AutonomousOpsStatusResponse);
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousLoading(false);
    }
  }, [activeProjectId, projectAutonomousRunSessionIdDraft, projectAutonomousSelectedRunId]);

  const remediateProjectAutonomousStaleRuns = useCallback(async (dryRun: boolean) => {
    if (!activeProjectId) return;
    const olderThan = Number.parseInt(projectAutonomousRemediateOlderThanDraft, 10);
    const maxRuns = Number.parseInt(projectAutonomousRemediateMaxRunsDraft, 10);
    if (!Number.isFinite(olderThan) || olderThan < 60) {
      setProjectAutonomousError("older_than_seconds must be >= 60");
      return;
    }
    if (!Number.isFinite(maxRuns) || maxRuns < 1 || maxRuns > 2000) {
      setProjectAutonomousError("max_runs must be between 1 and 2000");
      return;
    }

    if (!dryRun) {
      const approved = window.confirm(
        `Apply stale remediation for project '${activeProjectId}'? This will move selected active runs to '${projectAutonomousRemediateActionDraft}'.`,
      );
      if (!approved) return;
    }

    setProjectAutonomousRemediateBusy(true);
    setProjectAutonomousError(null);
    try {
      const result = await autonomousApi.remediateStaleRuns({
        project_id: activeProjectId,
        dry_run: dryRun,
        confirm: !dryRun,
        older_than_seconds: olderThan,
        max_runs: maxRuns,
        action: projectAutonomousRemediateActionDraft,
        reason: dryRun ? "ui_preview" : "ui_apply",
      });
      setProjectAutonomousRemediateResult(result as AutonomousRemediateStaleResponse);
      await refreshProjectAutonomous();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousRemediateBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousRemediateActionDraft,
    projectAutonomousRemediateMaxRunsDraft,
    projectAutonomousRemediateOlderThanDraft,
    refreshProjectAutonomous,
  ]);

  const createProjectAutonomousTask = useCallback(async () => {
    if (!activeProjectId) return;
    const title = projectAutonomousTaskTitleDraft.trim();
    const goal = projectAutonomousTaskGoalDraft.trim();
    const criteria = projectAutonomousTaskCriteriaDraft
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    if (!title || !goal || criteria.length === 0) {
      setProjectAutonomousError("Title, goal, and at least one acceptance criterion are required.");
      return;
    }
    setProjectAutonomousCreating(true);
    setProjectAutonomousError(null);
    try {
      await autonomousApi.createBacklogTask(activeProjectId, {
        title,
        goal,
        acceptance_criteria: criteria,
        priority: projectAutonomousTaskPriorityDraft,
        repository: projectAutonomousTaskRepositoryDraft.trim() || undefined,
        branch: projectAutonomousTaskBranchDraft.trim() || undefined,
      });
      setProjectAutonomousTaskTitleDraft("");
      setProjectAutonomousTaskGoalDraft("");
      setProjectAutonomousTaskCriteriaDraft("");
      setProjectAutonomousTaskPriorityDraft("medium");
      setProjectAutonomousTaskRepositoryDraft("");
      setProjectAutonomousTaskBranchDraft("");
      await refreshProjectAutonomous();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousCreating(false);
    }
  }, [
    activeProjectId,
    projectAutonomousTaskBranchDraft,
    projectAutonomousTaskCriteriaDraft,
    projectAutonomousTaskGoalDraft,
    projectAutonomousTaskPriorityDraft,
    projectAutonomousTaskRepositoryDraft,
    projectAutonomousTaskTitleDraft,
    refreshProjectAutonomous,
  ]);

  const startProjectAutonomousRun = useCallback(async (taskId: string) => {
    if (!activeProjectId) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const run = await autonomousApi.createRun(activeProjectId, {
        task_id: taskId,
        auto_start: true,
        session_id: projectAutonomousRunSessionIdDraft.trim() || undefined,
      });
      setProjectAutonomousSelectedRunId(run.id);
      setProjectAutonomousReportData(null);
      await refreshProjectAutonomous();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [activeProjectId, projectAutonomousRunSessionIdDraft, refreshProjectAutonomous]);

  const dispatchNextProjectAutonomousRun = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const response = await autonomousApi.dispatchNextRun(activeProjectId, {
        auto_start: true,
        session_id: projectAutonomousRunSessionIdDraft.trim() || undefined,
      });
      setProjectAutonomousSelectedRunId(response.run.id);
      setProjectAutonomousReportData(null);
      await refreshProjectAutonomous();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [activeProjectId, projectAutonomousRunSessionIdDraft, refreshProjectAutonomous]);

  const tickProjectAutonomousLoop = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const requiredChecks = projectAutonomousGitHubRequiredChecksDraft
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean);
      const response = await autonomousApi.loopTick(activeProjectId, {
        auto_start: true,
        session_id: projectAutonomousRunSessionIdDraft.trim() || undefined,
        repository: projectAutonomousGitHubRepoDraft.trim() || undefined,
        ref: projectAutonomousGitHubRefDraft.trim() || undefined,
        pr_url: projectAutonomousGitHubPrUrlDraft.trim() || undefined,
        required_checks: requiredChecks.length > 0 ? requiredChecks : undefined,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      if (response.action === "manual_evaluate_required") {
        setProjectAutonomousError(`Loop tick deferred: ${response.reason || "manual evaluate required"}`);
      }
      if (response.run?.id) {
        setProjectAutonomousSelectedRunId(response.run.id);
      }
      await refreshProjectAutonomous();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubPrUrlDraft,
    projectAutonomousGitHubRepoDraft,
    projectAutonomousGitHubRequiredChecksDraft,
    projectAutonomousRunSessionIdDraft,
    refreshProjectAutonomous,
  ]);

  const runCycleProjectAutonomous = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const requiredChecks = projectAutonomousGitHubRequiredChecksDraft
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean);
      const response = await autonomousApi.runCycle({
        project_ids: [activeProjectId],
        auto_start: true,
        max_steps_per_project: 3,
        session_id_by_project: projectAutonomousRunSessionIdDraft.trim()
          ? { [activeProjectId]: projectAutonomousRunSessionIdDraft.trim() }
          : undefined,
        repository: projectAutonomousGitHubRepoDraft.trim() || undefined,
        ref: projectAutonomousGitHubRefDraft.trim() || undefined,
        pr_url: projectAutonomousGitHubPrUrlDraft.trim() || undefined,
        required_checks: requiredChecks.length > 0 ? requiredChecks : undefined,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      const row = Array.isArray(response.results) ? response.results.find((r) => r.project_id === activeProjectId) : null;
      setProjectAutonomousCycleSummary((response.summary as unknown as Record<string, unknown>) || null);
      setProjectAutonomousCycleResult((row as unknown as Record<string, unknown>) || null);
      if (row?.run?.id) {
        setProjectAutonomousSelectedRunId(row.run.id);
      }
      if (row?.action === "manual_evaluate_required") {
        setProjectAutonomousError(`Run Cycle deferred: ${row.reason || "manual evaluate required"}`);
      }
      await refreshProjectAutonomous();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubPrUrlDraft,
    projectAutonomousGitHubRepoDraft,
    projectAutonomousGitHubRequiredChecksDraft,
    projectAutonomousRunSessionIdDraft,
    refreshProjectAutonomous,
  ]);

  const selectedAutonomousRun = useMemo(
    () => projectAutonomousRuns.find((r) => r.id === projectAutonomousSelectedRunId) || null,
    [projectAutonomousRuns, projectAutonomousSelectedRunId],
  );
  const selectedAutonomousTask = useMemo(
    () =>
      selectedAutonomousRun
        ? projectAutonomousBacklog.find((t) => t.id === selectedAutonomousRun.task_id) || null
        : null,
    [projectAutonomousBacklog, selectedAutonomousRun],
  );
  const projectAutonomousCycleOutcomes = useMemo(() => {
    if (!projectAutonomousCycleSummary) return [];
    const raw = projectAutonomousCycleSummary.outcomes;
    if (!raw || typeof raw !== "object") return [];
    return Object.entries(raw as Record<string, unknown>)
      .map(([k, v]) => [k, Number(v)] as const)
      .filter(([, v]) => Number.isFinite(v))
      .sort((a, b) => b[1] - a[1]);
  }, [projectAutonomousCycleSummary]);

  const refreshProjectAutonomousReport = useCallback(async () => {
    if (!activeProjectId || !projectAutonomousSelectedRunId) {
      setProjectAutonomousReportData(null);
      return;
    }
    try {
      const report = await autonomousApi.report(activeProjectId, projectAutonomousSelectedRunId);
      setProjectAutonomousReportData(report as unknown as Record<string, unknown>);
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    }
  }, [activeProjectId, projectAutonomousSelectedRunId]);

  useEffect(() => {
    refreshProjectAutonomousReport().catch(() => {});
  }, [refreshProjectAutonomousReport]);

  const executeNextProjectAutonomousRun = useCallback(async () => {
    if (!activeProjectId) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const requiredChecks = projectAutonomousGitHubRequiredChecksDraft
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean);
      const response = await autonomousApi.executeNextRun(activeProjectId, {
        auto_start: true,
        max_steps: 8,
        session_id: projectAutonomousRunSessionIdDraft.trim() || undefined,
        repository: projectAutonomousGitHubRepoDraft.trim() || undefined,
        ref: projectAutonomousGitHubRefDraft.trim() || undefined,
        pr_url: projectAutonomousGitHubPrUrlDraft.trim() || undefined,
        required_checks: requiredChecks.length > 0 ? requiredChecks : undefined,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      if (response.run?.id) {
        setProjectAutonomousSelectedRunId(response.run.id);
      }
      if (!response.terminal && response.action === "manual_evaluate_required") {
        setProjectAutonomousError(`Execute Next deferred: ${response.steps?.[0]?.reason || "manual evaluate required"}`);
      }
      setProjectAutonomousLastExecutionSnapshot({
        source: "execute_next",
        updated_at: Date.now(),
        action: response.action ?? null,
        terminal: response.terminal ?? false,
        terminal_status: response.terminal_status ?? null,
        status: response.status ?? null,
        steps_executed: response.steps_executed ?? 0,
        run_id: response.run?.id ?? response.run_id ?? null,
        last_error: null,
      });
      await refreshProjectAutonomous();
      await refreshProjectAutonomousReport();
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setProjectAutonomousError(msg);
      setProjectAutonomousLastExecutionSnapshot({
        source: "execute_next",
        updated_at: Date.now(),
        action: "error",
        terminal: false,
        terminal_status: null,
        status: null,
        steps_executed: 0,
        run_id: selectedAutonomousRun?.id ?? null,
        last_error: msg,
      });
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubPrUrlDraft,
    projectAutonomousGitHubRepoDraft,
    projectAutonomousGitHubRequiredChecksDraft,
    projectAutonomousRunSessionIdDraft,
    refreshProjectAutonomous,
    refreshProjectAutonomousReport,
    selectedAutonomousRun?.id,
  ]);

  useEffect(() => {
    if (!selectedAutonomousTask) return;
    if (!projectAutonomousGitHubRepoDraft && selectedAutonomousTask.repository) {
      setProjectAutonomousGitHubRepoDraft(selectedAutonomousTask.repository);
    }
    if (!projectAutonomousGitHubRefDraft && selectedAutonomousTask.branch) {
      setProjectAutonomousGitHubRefDraft(selectedAutonomousTask.branch);
    }
  }, [
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubRepoDraft,
    selectedAutonomousTask,
  ]);

  useEffect(() => {
    if (projectAutonomousGitHubPrUrlDraft) return;
    const report = projectAutonomousReportData;
    if (!report || typeof report !== "object") return;
    const reportObj = report as Record<string, unknown>;
    const prObj = reportObj.pr;
    if (!prObj || typeof prObj !== "object") return;
    const url = String((prObj as Record<string, unknown>).url || "").trim();
    if (url) setProjectAutonomousGitHubPrUrlDraft(url);
  }, [projectAutonomousGitHubPrUrlDraft, projectAutonomousReportData]);

  const advanceProjectAutonomousRun = useCallback(async () => {
    if (!activeProjectId || !selectedAutonomousRun) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      await autonomousApi.advanceRun(activeProjectId, selectedAutonomousRun.id, {
        stage: selectedAutonomousRun.current_stage,
        result: projectAutonomousAdvanceResultDraft,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      setProjectAutonomousAdvanceNotesDraft("");
      await refreshProjectAutonomous();
      await refreshProjectAutonomousReport();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousAdvanceResultDraft,
    refreshProjectAutonomous,
    refreshProjectAutonomousReport,
    selectedAutonomousRun,
  ]);

  const runUntilTerminalProjectAutonomousRun = useCallback(async () => {
    if (!activeProjectId || !selectedAutonomousRun) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const requiredChecks = projectAutonomousGitHubRequiredChecksDraft
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean);
      const response = await autonomousApi.runUntilTerminal(activeProjectId, selectedAutonomousRun.id, {
        max_steps: 8,
        auto_start: true,
        session_id: projectAutonomousRunSessionIdDraft.trim() || undefined,
        repository: projectAutonomousGitHubRepoDraft.trim() || undefined,
        ref: projectAutonomousGitHubRefDraft.trim() || undefined,
        pr_url: projectAutonomousGitHubPrUrlDraft.trim() || undefined,
        required_checks: requiredChecks.length > 0 ? requiredChecks : undefined,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      setProjectAutonomousCycleResult({
        action: response.action,
        terminal: response.terminal,
        terminal_status: response.terminal_status || null,
        steps_executed: response.steps_executed,
        run_id: response.run_id,
        status: response.status,
      });
      setProjectAutonomousLastExecutionSnapshot({
        source: "run_until_terminal",
        updated_at: Date.now(),
        action: response.action ?? null,
        terminal: response.terminal ?? false,
        terminal_status: response.terminal_status ?? null,
        status: response.status ?? null,
        steps_executed: response.steps_executed ?? 0,
        run_id: response.run?.id ?? response.run_id ?? null,
        last_error: null,
      });
      setProjectAutonomousSelectedRunId(response.run.id);
      await refreshProjectAutonomous();
      await refreshProjectAutonomousReport();
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setProjectAutonomousError(msg);
      setProjectAutonomousLastExecutionSnapshot({
        source: "run_until_terminal",
        updated_at: Date.now(),
        action: "error",
        terminal: false,
        terminal_status: null,
        status: null,
        steps_executed: 0,
        run_id: selectedAutonomousRun?.id ?? null,
        last_error: msg,
      });
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubPrUrlDraft,
    projectAutonomousGitHubRepoDraft,
    projectAutonomousGitHubRequiredChecksDraft,
    projectAutonomousRunSessionIdDraft,
    refreshProjectAutonomous,
    refreshProjectAutonomousReport,
    selectedAutonomousRun,
    selectedAutonomousRun?.id,
  ]);

  const evaluateProjectAutonomousRun = useCallback(async () => {
    if (!activeProjectId || !selectedAutonomousRun) return;
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const checks = projectAutonomousChecksDraft
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean)
        .map((line) => {
          const [nameRaw, resultRaw] = line.split(":");
          const name = (nameRaw || "").trim();
          const resultText = (resultRaw || "pass").trim().toLowerCase();
          return {
            name,
            passed: resultText === "pass" || resultText === "ok" || resultText === "success",
            severity: "error" as const,
            details: "",
          };
        })
        .filter((c) => c.name);
      if (checks.length === 0) {
        setProjectAutonomousError("Checks cannot be empty. Use one per line: check_name:pass|fail");
        return;
      }
      await autonomousApi.evaluateRun(activeProjectId, selectedAutonomousRun.id, {
        stage: selectedAutonomousRun.current_stage,
        source: "ui_checks",
        checks,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      setProjectAutonomousAdvanceNotesDraft("");
      await refreshProjectAutonomous();
      await refreshProjectAutonomousReport();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousChecksDraft,
    refreshProjectAutonomous,
    refreshProjectAutonomousReport,
    selectedAutonomousRun,
  ]);

  const evaluateProjectAutonomousRunFromGitHub = useCallback(async () => {
    if (!activeProjectId || !selectedAutonomousRun) return;
    const repo = projectAutonomousGitHubRepoDraft.trim();
    const ref = projectAutonomousGitHubRefDraft.trim();
    const prUrl = projectAutonomousGitHubPrUrlDraft.trim();
    if ((!repo || !ref) && !prUrl) {
      setProjectAutonomousError("Provide repository+ref or PR URL for GitHub evaluate.");
      return;
    }
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const requiredChecks = projectAutonomousGitHubRequiredChecksDraft
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean);
      await autonomousApi.evaluateRunFromGitHub(activeProjectId, selectedAutonomousRun.id, {
        stage: selectedAutonomousRun.current_stage,
        repository: repo,
        ref,
        required_checks: requiredChecks.length > 0 ? requiredChecks : undefined,
        pr_url: prUrl || undefined,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      await refreshProjectAutonomous();
      await refreshProjectAutonomousReport();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubPrUrlDraft,
    projectAutonomousGitHubRepoDraft,
    projectAutonomousGitHubRequiredChecksDraft,
    refreshProjectAutonomous,
    refreshProjectAutonomousReport,
    selectedAutonomousRun,
  ]);

  const autoNextProjectAutonomousRun = useCallback(async () => {
    if (!activeProjectId || !selectedAutonomousRun) return;
    const stage = selectedAutonomousRun.current_stage;
    if (stage !== "review" && stage !== "validation") {
      setProjectAutonomousError(`Auto Next supports review/validation stages only (current: ${stage}).`);
      return;
    }
    const repo = projectAutonomousGitHubRepoDraft.trim();
    const ref = projectAutonomousGitHubRefDraft.trim();
    const prUrl = projectAutonomousGitHubPrUrlDraft.trim();
    if ((!repo || !ref) && !prUrl) {
      setProjectAutonomousError("Auto Next requires repo+ref or PR URL for GitHub checks.");
      return;
    }
    setProjectAutonomousActionBusy(true);
    setProjectAutonomousError(null);
    try {
      const requiredChecks = projectAutonomousGitHubRequiredChecksDraft
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean);
      await autonomousApi.autoNextRun(activeProjectId, selectedAutonomousRun.id, {
        repository: repo,
        ref,
        required_checks: requiredChecks.length > 0 ? requiredChecks : undefined,
        pr_url: prUrl || undefined,
        notes: projectAutonomousAdvanceNotesDraft.trim() || undefined,
      });
      await refreshProjectAutonomous();
      await refreshProjectAutonomousReport();
    } catch (e) {
      setProjectAutonomousError(e instanceof Error ? e.message : String(e));
    } finally {
      setProjectAutonomousActionBusy(false);
    }
  }, [
    activeProjectId,
    projectAutonomousAdvanceNotesDraft,
    projectAutonomousGitHubRefDraft,
    projectAutonomousGitHubPrUrlDraft,
    projectAutonomousGitHubRepoDraft,
    projectAutonomousGitHubRequiredChecksDraft,
    refreshProjectAutonomous,
    refreshProjectAutonomousReport,
    selectedAutonomousRun,
  ]);

  const createProjectFromForm = useCallback(async () => {
    const name = projectNameDraft.trim();
    if (!name) {
      setProjectCreateError("Project name is required");
      return;
    }
    if (projectOnboardEnabled && !projectWorkspacePathDraft.trim()) {
      setProjectCreateError("Workspace path is required when onboarding is enabled");
      return;
    }
    setProjectBusy(true);
    setProjectCreateError(null);
    try {
      const repository = projectRepositoryDraft.trim() || undefined;
      const created = await projectsApi.create(
        name,
        projectDescriptionDraft.trim() || undefined,
        repository,
      );
      if (projectOnboardEnabled) {
        await projectsApi.onboarding(created.id, {
          template_id: projectTemplateIdDraft || undefined,
          repository,
          workspace_path: projectWorkspacePathDraft.trim() || undefined,
          stack: projectStackDraft,
          repo_type: selectedProjectTemplate?.repo_type || "single",
          create_manifest: true,
          dry_run: true,
        });
      }
      await refreshProjects();
      setActiveProjectId(created.id);
      localStorage.setItem(ACTIVE_PROJECT_STORAGE_KEY, created.id);
      setProjectModalOpen(false);
      setProjectNameDraft("");
      setProjectDescriptionDraft("");
      setProjectRepositoryDraft("");
      setProjectWorkspacePathDraft("");
      setProjectStackDraft("node");
      setProjectTemplateIdDraft(DEFAULT_PROJECT_TEMPLATE_ID);
      setProjectOnboardEnabled(true);
    } catch (e) {
      const message = e instanceof ApiError
        ? `Create/onboarding failed: ${e.message || `HTTP ${e.status}`}`
        : String(e);
      setProjectCreateError(message);
    } finally {
      setProjectBusy(false);
    }
  }, [
    projectDescriptionDraft,
    projectNameDraft,
    projectOnboardEnabled,
    projectRepositoryDraft,
    projectStackDraft,
    projectTemplateIdDraft,
    projectWorkspacePathDraft,
    refreshProjects,
    selectedProjectTemplate,
  ]);

  const apiCreateSession = useCallback(
    (
      agentPath?: string,
      agentId?: string,
      model?: string,
      initialPrompt?: string,
      queenResumeFrom?: string,
    ) => sessionsApi.create(agentPath, agentId, model, initialPrompt, queenResumeFrom, activeProjectId),
    [activeProjectId],
  );
  const apiListSessions = useCallback(
    () => sessionsApi.list(activeProjectId),
    [activeProjectId],
  );
  const apiHistorySessions = useCallback(
    () => sessionsApi.history(activeProjectId),
    [activeProjectId],
  );

  const updateAgentState = useCallback((agentType: string, patch: Partial<AgentBackendState>) => {
    setAgentStates(prev => ({
      ...prev,
      [agentType]: { ...(prev[agentType] || defaultAgentState()), ...patch },
    }));
  }, []);

  // Derive active agent's backend state
  const activeAgentState = agentStates[activeWorker];

  // Reset dismissed banner when the error clears so it re-appears if the same error returns
  const currentError = activeAgentState?.error;
  useEffect(() => { if (!currentError) setDismissedBanner(null); }, [currentError]);

  // Persist tab metadata + session data to localStorage on every relevant change
  useEffect(() => {
    const tabs: PersistedTabState["tabs"] = [];
    const sessions: Record<string, { messages: ChatMessage[]; graphNodes: GraphNode[] }> = {};
    for (const agentSessions of Object.values(sessionsByAgent)) {
      for (const s of agentSessions) {
        const tKey = s.tabKey || s.agentType;
        tabs.push({
          id: s.id,
          agentType: s.agentType,
          tabKey: s.tabKey,
          label: s.label,
          // agentStates is keyed by tabKey (unique per tab), not by base agentType
          backendSessionId: s.backendSessionId || agentStates[tKey]?.sessionId || undefined,
          ...(s.historySourceId ? { historySourceId: s.historySourceId } : {}),
        });
        sessions[s.id] = { messages: s.messages, graphNodes: s.graphNodes };
      }
    }
    if (tabs.length > 0) {
      savePersistedTabs({ tabs, activeSessionByAgent, activeWorker, sessions });
    } else {
      localStorage.removeItem(TAB_STORAGE_KEY);
    }
  }, [sessionsByAgent, activeSessionByAgent, activeWorker, agentStates]);

  const handleRun = useCallback(async () => {
    const state = agentStates[activeWorker];
    if (!state?.sessionId || !state?.ready) return;
    // Reset dismissed banner so a repeated 424 re-shows it
    setDismissedBanner(null);
    try {
      updateAgentState(activeWorker, { workerRunState: "deploying" });
      const result = await executionApi.trigger(state.sessionId, "default", {});
      updateAgentState(activeWorker, { currentExecutionId: result.execution_id });
    } catch (err) {
      // 424 = credentials required — open the credentials modal
      if (err instanceof ApiError && err.status === 424) {
        const errBody = (err as ApiError).body as Record<string, unknown>;
        const credPath = (errBody?.agent_path as string) || null;
        if (credPath) setCredentialAgentPath(credPath);
        updateAgentState(activeWorker, { workerRunState: "idle", error: "credentials_required" });
        setCredentialsOpen(true);
        return;
      }

      const errMsg = err instanceof Error ? err.message : String(err);
      setSessionsByAgent((prev) => {
        const sessions = prev[activeWorker] || [];
        const activeId = activeSessionRef.current[activeWorker] || sessions[0]?.id;
        return {
          ...prev,
          [activeWorker]: sessions.map((s) => {
            if (s.id !== activeId) return s;
            const errorMsg: ChatMessage = {
              id: makeId(), agent: "System", agentColor: "",
              content: `Failed to trigger run: ${errMsg}`,
              timestamp: "", type: "system", thread: activeWorker, createdAt: Date.now(),
            };
            return { ...s, messages: [...s.messages, errorMsg] };
          }),
        };
      });
      updateAgentState(activeWorker, { workerRunState: "idle" });
    }
  }, [agentStates, activeWorker, updateAgentState]);

  // --- Fetch discovered agents for NewTabPopover ---
  const [discoverAgents, setDiscoverAgents] = useState<DiscoverEntry[]>([]);
  useEffect(() => {
    agentsApi.discover().then(result => {
      const { Framework: _fw, ...userFacing } = result;
      const all = Object.values(userFacing).flat();
      setDiscoverAgents(all);
    }).catch(() => { });
  }, []);

  // --- Agent loading: loadAgentForType ---
  const loadingRef = useRef(new Set<string>());
  const loadAgentForType = useCallback(async (agentType: string) => {
    // agentType may be a unique composite key ("exports/foo::sessionId") for additional
    // tabs — extract the real agent path for selector checks and API calls.
    const agentPath = baseAgentType(agentType);
    // Ref-based guard: prevents double-load from React StrictMode (must be first check)
    if (loadingRef.current.has(agentType)) return;
    loadingRef.current.add(agentType);

    if (agentPath === "new-agent" || agentType.startsWith("new-agent-")) {
      // Create a queen-only session (no worker) for agent building
      updateAgentState(agentType, { loading: true, error: null, ready: false, sessionId: null });
      try {
        const prompt = initialPrompt || undefined;
        let liveSession: LiveSession | undefined;

        // Find the active session for this agent type
        const activeId = activeSessionRef.current[agentType];
        const activeSess = sessionsRef.current[agentType]?.find(s => s.id === activeId)
          || sessionsRef.current[agentType]?.[0];

        // Try to reconnect to stored backend session (e.g., after browser refresh)
        const storedId = activeSess?.backendSessionId;
        // When the server restarts the session is "cold" — conversation files
        // survive on disk but there is no live runtime.  Track the old ID so
        // we can restore message history after creating a new session.
        let coldRestoreId: string | undefined;

        if (storedId) {
          try {
            const sessionData = await sessionsApi.get(storedId);
            if (sessionData.cold) {
              // Server restarted — files on disk, no live runtime
              coldRestoreId = storedId;
            } else {
              liveSession = sessionData;
            }
          } catch {
            // Session gone entirely (no disk files either)
          }
        }

        let restoredMessageCount = 0;

        // Before creating a new session, check if there's already a live backend
        // session for this queen-only agent that no open tab owns.
        // Skip this search when the tab has a prompt — it's a fresh agent from
        // home and must always get its own session.
        if (!liveSession && !coldRestoreId && !prompt) {
          try {
            const { sessions: allLive } = await apiListSessions();
            const existing = allLive.find(s => !s.has_worker && !s.agent_path);
            if (existing) {
              const alreadyOwned = Object.values(sessionsRef.current).flat()
                .some(s => s.backendSessionId === existing.session_id);
              if (!alreadyOwned) {
                liveSession = existing;
              }
            }
          } catch { /* proceed to create */ }

          // If no live session, check history for a cold queen-only session
          if (!liveSession) {
            try {
              const { sessions: allHistory } = await apiHistorySessions();
              const coldMatch = allHistory.find(
                s => !s.agent_path && s.has_messages
              );
              if (coldMatch) {
                coldRestoreId = coldMatch.session_id;
              }
            } catch { /* proceed to create fresh */ }
          }
        }

        let restoredPhase: "planning" | "building" | "staging" | "running" | null = null;
        let restoredFlowchartMap: Record<string, string[]> | null = null;
        let restoredOriginalDraft: DraftGraphData | null = null;
        if (!liveSession) {
          // Fetch conversation history from disk BEFORE creating the new session.
          // SKIP if messages were already pre-populated by handleHistoryOpen.
          const restoreFrom = coldRestoreId ?? storedId;
          const preRestoredMsgs: ChatMessage[] = [];
          const alreadyHasMessages = (activeSess?.messages?.length ?? 0) > 0;
          if (restoreFrom && !alreadyHasMessages) {
            try {
              const restored = await restoreSessionMessages(restoreFrom, agentType, "Queen Bee");
              preRestoredMsgs.push(...restored.messages);
              restoredPhase = restored.restoredPhase;
              restoredFlowchartMap = restored.flowchartMap;
              restoredOriginalDraft = restored.originalDraft;
            } catch {
              // Not available — will start fresh
            }
          } else if (restoreFrom && alreadyHasMessages) {
            // Messages already cached in localStorage — still fetch events for
            // non-message state (phase, flowchart) that isn't cached.
            try {
              const restored = await restoreSessionMessages(restoreFrom, agentType, "Queen Bee");
              restoredPhase = restored.restoredPhase;
              restoredFlowchartMap = restored.flowchartMap;
              restoredOriginalDraft = restored.originalDraft;
            } catch {
              // Not critical — UI will still show cached messages
            }
          }

          // Suppress the queen's intro cycle whenever we are about to restore a
          // previous conversation, or whenever we have a stored session ID.
          const willRestore = !!(restoreFrom);
          if (willRestore || preRestoredMsgs.length > 0) suppressIntroRef.current.add(agentType);

          // Pass coldRestoreId as queenResumeFrom so the backend writes queen
          // messages into the ORIGINAL session's directory.
          liveSession = await apiCreateSession(undefined, undefined, undefined, prompt, coldRestoreId ?? undefined);

          if (preRestoredMsgs.length > 0) {
            preRestoredMsgs.sort((a, b) => (a.createdAt ?? 0) - (b.createdAt ?? 0));
            if (activeId) {
              setSessionsByAgent(prev => ({
                ...prev,
                [agentType]: (prev[agentType] || []).map(s =>
                  s.id === activeId ? { ...s, messages: preRestoredMsgs, graphNodes: [] } : s,
                ),
              }));
            }
            restoredMessageCount = preRestoredMsgs.length;
          } else if (restoreFrom && activeId && !alreadyHasMessages) {
            // We had a stored session but no messages on disk — wipe stale localStorage cache
            setSessionsByAgent(prev => ({
              ...prev,
              [agentType]: (prev[agentType] || []).map(s =>
                s.id === activeId ? { ...s, messages: [], graphNodes: [] } : s,
              ),
            }));
          }

          // Show the initial prompt as a user message only on a truly fresh session
          if (prompt && restoredMessageCount === 0 && activeId) {
            const userMsg: ChatMessage = {
              id: makeId(), agent: "You", agentColor: "",
              content: prompt, timestamp: "", type: "user", thread: agentType, createdAt: Date.now(),
            };
            setSessionsByAgent(prev => ({
              ...prev,
              [agentType]: (prev[agentType] || []).map(s =>
                s.id === activeId ? { ...s, messages: [...s.messages, userMsg] } : s,
              ),
            }));
          }
        }

        // Store backendSessionId on the Session object for persistence.
        // Also set historySourceId so the sidebar "already-open" check works
        // even after cold-revive changes backendSessionId to a new live session ID.
        if (activeId) {
          setSessionsByAgent(prev => ({
            ...prev,
            [agentType]: (prev[agentType] || []).map(s =>
              s.id === activeId ? {
                ...s,
                backendSessionId: liveSession!.session_id,
                historySourceId: s.historySourceId || coldRestoreId || undefined,
              } : s,
            ),
          }));
        }

        // If no messages were actually restored, lift the intro suppression
        if (restoredMessageCount === 0) suppressIntroRef.current.delete(agentType);

        const qPhase = restoredPhase || liveSession.queen_phase || "planning";
        queenPhaseRef.current[agentType] = qPhase;
        updateAgentState(agentType, {
          sessionId: liveSession.session_id,
          displayName: "Queen Bee",
          ready: true,
          loading: false,
          queenReady: true,
          queenPhase: qPhase,
          queenBuilding: qPhase === "building",
          queenSupportsImages: liveSession.queen_supports_images !== false,
          // Restore flowchart overlay from persisted events
          ...(restoredFlowchartMap ? { flowchartMap: restoredFlowchartMap } : {}),
          ...(restoredOriginalDraft ? { originalDraft: restoredOriginalDraft, draftGraph: null } : {}),
        });
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        updateAgentState(agentType, { error: msg, loading: false });
      }
      return;
    }

    updateAgentState(agentType, { loading: true, error: null, ready: false, sessionId: null });

    try {
      let liveSession: LiveSession | undefined;
      let isResumedSession = false;
      // Set when the stored session is cold (server restarted) so we can restore
      // messages from the old session files after creating a new live session.
      let coldRestoreId: string | undefined;

      // Try to reconnect to an existing backend session (e.g., after browser refresh).
      // The backendSessionId is persisted in localStorage per tab.
      // Also check historySourceId — handleHistoryOpen populates this with the
      // original session ID from the sidebar. Use it as a fallback for stored ID.
      const historySourceId = sessionsRef.current[agentType]?.[0]?.historySourceId;
      const storedSessionId = sessionsRef.current[agentType]?.[0]?.backendSessionId
        || historySourceId;
      if (storedSessionId) {
        try {
          const sessionData = await sessionsApi.get(storedSessionId);
          if (sessionData.cold) {
            // Server restarted — conversation files survive on disk, no live runtime.
            coldRestoreId = storedSessionId;
          } else {
            liveSession = sessionData;
            isResumedSession = true;
          }
        } catch {
          // 404: session was explicitly stopped (via closeAgentTab) but conversation
          // files likely still exist on disk. Treat it as cold so we can restore.
          coldRestoreId = historySourceId || storedSessionId;
        }
      }

      // No stored session — check for a live or cold session for this agent
      // that we can reuse (e.g., tab was closed but backend session survived,
      // or server restarted with conversation files on disk).
      if (!liveSession && !coldRestoreId) {
        try {
          const { sessions: allLive } = await apiListSessions();
          const existingLive = allLive.find(s => s.agent_path.endsWith(agentPath));
          if (existingLive) {
            const alreadyOwned = Object.values(sessionsRef.current).flat()
              .some(s => s.backendSessionId === existingLive.session_id);
            if (!alreadyOwned) {
              liveSession = existingLive;
              isResumedSession = true;
            }
          }
        } catch { /* proceed */ }

        // If no live session, check history for a cold session to restore
        if (!liveSession) {
          try {
            const { sessions: allHistory } = await apiHistorySessions();
            const coldMatch = allHistory.find(
              s => s.agent_path?.endsWith(agentPath) && s.has_messages
            );
            if (coldMatch) {
              coldRestoreId = coldMatch.session_id;
            }
          } catch { /* proceed to create fresh */ }
        }
      }

      // Track the last queen phase seen in the event log for cold restore
      let restoredPhase: "planning" | "building" | "staging" | "running" | null = null;
      let restoredFlowchartMap: Record<string, string[]> | null = null;
      let restoredOriginalDraft: DraftGraphData | null = null;

      if (!liveSession) {
        // Reconnect failed — clear stale cached messages from localStorage restore.
        // NEVER wipe when: (a) doing a cold restore (we'll restore from disk) or
        // (b) handleHistoryOpen already pre-populated messages (alreadyHasMessages).
        const alreadyHasMessages = (sessionsRef.current[agentType] || [])[0]?.messages?.length > 0;
        if (storedSessionId && !coldRestoreId && !alreadyHasMessages) {
          setSessionsByAgent(prev => ({
            ...prev,
            [agentType]: (prev[agentType] || []).map((s, i) =>
              i === 0 ? { ...s, messages: [], graphNodes: [] } : s,
            ),
          }));
        }

        // CRITICAL: Pre-fetch queen messages from the old session directory BEFORE
        // creating the new session. When queen_resume_from is set the new session writes
        // to the SAME directory, so if we fetch after creation we risk capturing the
        // new queen's greeting in the restored history.
        // SKIP if messages were already pre-populated by handleHistoryOpen (avoids
        // double-fetch and greeting leakage).
        let preQueenMsgs: ChatMessage[] = [];
        if (coldRestoreId && !alreadyHasMessages) {
          const displayNameTemp = formatAgentDisplayName(agentPath);
          const restored = await restoreSessionMessages(coldRestoreId, agentType, displayNameTemp);
          preQueenMsgs = restored.messages;
          restoredPhase = restored.restoredPhase;
          restoredFlowchartMap = restored.flowchartMap;
          restoredOriginalDraft = restored.originalDraft;
        } else if (coldRestoreId && alreadyHasMessages) {
          // Messages already cached — still fetch events for non-message state (phase, flowchart)
          try {
            const displayNameTemp = formatAgentDisplayName(agentPath);
            const restored = await restoreSessionMessages(coldRestoreId, agentType, displayNameTemp);
            restoredPhase = restored.restoredPhase;
            restoredFlowchartMap = restored.flowchartMap;
            restoredOriginalDraft = restored.originalDraft;
          } catch {
            // Not critical — UI will still show cached messages
          }
        }

        // Suppress intro whenever we are about to restore a previous conversation.
        // The user never expects a greeting when reopening a session.
        if (coldRestoreId) suppressIntroRef.current.add(agentType);

        try {
          // Pass coldRestoreId as queenResumeFrom so the backend writes queen
          // messages into the ORIGINAL session's directory — all conversation
          // history accumulates in one place across server restarts.
          liveSession = await apiCreateSession(agentPath, undefined, undefined, undefined, coldRestoreId ?? undefined);
        } catch (loadErr: unknown) {
          // 424 = credentials required — open the credentials modal
          if (loadErr instanceof ApiError && loadErr.status === 424) {
            const errBody = loadErr.body as Record<string, unknown>;
            const credPath = (errBody.agent_path as string) || null;
            if (credPath) setCredentialAgentPath(credPath);
            updateAgentState(agentType, { loading: false, error: "credentials_required" });
            setCredentialsOpen(true);
            return;
          }

          if (!(loadErr instanceof ApiError) || loadErr.status !== 409) {
            throw loadErr;
          }

          const body = loadErr.body as Record<string, unknown>;
          const existingSessionId = body.session_id as string | undefined;
          if (!existingSessionId) throw loadErr;

          isResumedSession = true;
          if (body.loading) {
            liveSession = await (async () => {
              const maxAttempts = 30;
              const delay = 1000;
              for (let i = 0; i < maxAttempts; i++) {
                await new Promise((r) => setTimeout(r, delay));
                try {
                  const result = await sessionsApi.get(existingSessionId);
                  if (result.loading) continue;
                  return result as LiveSession;
                } catch (pollErr) {
                  // 404 = agent failed to load and was cleaned up — stop immediately
                  if (pollErr instanceof ApiError && pollErr.status === 404) {
                    throw new Error("Agent failed to load");
                  }
                  if (i === maxAttempts - 1) throw loadErr;
                }
              }
              throw loadErr;
            })();
          } else {
            liveSession = body as unknown as LiveSession;
          }
        }

        // If we pre-fetched messages for a cold restore, populate the UI immediately.
        // This happens before the SSE connection opens so no greeting can slip through.
        if (preQueenMsgs.length > 0) {
          preQueenMsgs.sort((a, b) => (a.createdAt ?? 0) - (b.createdAt ?? 0));
          setSessionsByAgent(prev => ({
            ...prev,
            [agentType]: (prev[agentType] || []).map((s, i) =>
              i === 0 ? { ...s, messages: preQueenMsgs, graphNodes: [] } : s,
            ),
          }));
        }
      }

      // At this point liveSession is guaranteed set — if both reconnect and create
      // failed, the throw inside the catch exits the outer try block.
      const session = liveSession!;
      const displayName = formatAgentDisplayName(session.graph_name || agentType);
      const initialPhase = restoredPhase || session.queen_phase || (session.has_worker ? "staging" : "planning");
      queenPhaseRef.current[agentType] = initialPhase;
      updateAgentState(agentType, {
        sessionId: session.session_id,
        displayName,
        queenPhase: initialPhase,
        queenBuilding: initialPhase === "building",
        queenSupportsImages: session.queen_supports_images !== false,
        // Restore flowchart overlay from persisted events
        ...(restoredFlowchartMap ? { flowchartMap: restoredFlowchartMap } : {}),
        ...(restoredOriginalDraft ? { originalDraft: restoredOriginalDraft, draftGraph: null } : {}),
      });

      // Update the session label + backendSessionId.  Also set historySourceId
      // so the sidebar "already-open" check works even after cold-revive changes
      // backendSessionId to a new live session ID.
      setSessionsByAgent((prev) => {
        const sessions = prev[agentType] || [];
        if (!sessions.length) return prev;
        return {
          ...prev,
          [agentType]: sessions.map((s, i) =>
            i === 0 ? {
              ...s,
              // Preserve existing label if it was already set with a #N suffix by
              // addAgentSession/handleHistoryOpen. Only overwrite with the bare
              // displayName when the label doesn't match the resolved display name.
              label: s.label.startsWith(displayName) ? s.label : displayName,
              backendSessionId: session.session_id,
              // Preserve existing historySourceId; set it from coldRestoreId if missing
              historySourceId: s.historySourceId || coldRestoreId || undefined,
            } : s,
          ),
        };
      });

      // Restore messages when rejoining an existing session OR cold-restoring from disk.
      const restoredMsgs: ChatMessage[] = [];
      // For cold-restore, use the old session ID. For live resume, use current session.
      const historyId = coldRestoreId ?? (isResumedSession ? session.session_id : undefined);

      // For LIVE resume (not cold restore), fetch event log + worker status now.
      // For cold restore they were already pre-fetched above (before create) so we skip to avoid
      // double-restoring and to avoid capturing the new greeting.
      if (historyId && !coldRestoreId) {
        const restored = await restoreSessionMessages(historyId, agentType, displayName);
        restoredMsgs.push(...restored.messages);
        // Use flowchart from event log if not already set
        if (restored.flowchartMap && !restoredFlowchartMap) {
          restoredFlowchartMap = restored.flowchartMap;
          restoredOriginalDraft = restored.originalDraft;
        }
      }

      // Merge messages in chronological order (only for live resume; cold restore
      // was already applied above before create).
      if (restoredMsgs.length > 0) {
        restoredMsgs.sort((a, b) => (a.createdAt ?? 0) - (b.createdAt ?? 0));
        setSessionsByAgent((prev) => ({
          ...prev,
          [agentType]: (prev[agentType] || []).map((s, i) =>
            i === 0 ? { ...s, messages: [...restoredMsgs, ...s.messages] } : s,
          ),
        }));
      }

      // If no messages were actually restored, lift the intro suppression gate
      if (restoredMsgs.length === 0 && !coldRestoreId) suppressIntroRef.current.delete(agentType);

      // Mark queenReady immediately only when resuming a session that already
      // has messages (live resume or cold restore).  For a fresh session the
      // queen still needs to process the thinking hook before its first
      // response, so leave queenReady false and let the SSE handler flip it
      // on the first queen event — this keeps the "Connecting to queen..."
      // loading indicator visible until the queen actually responds.
      const hasRestoredContent = restoredMsgs.length > 0 || !!coldRestoreId;
      updateAgentState(agentType, {
        sessionId: session.session_id,
        displayName,
        ready: true,
        loading: false,
        queenReady: !!(isResumedSession || hasRestoredContent),
        // Restore flowchart overlay from persisted events
        ...(restoredFlowchartMap ? { flowchartMap: restoredFlowchartMap } : {}),
        ...(restoredOriginalDraft ? { originalDraft: restoredOriginalDraft, draftGraph: null } : {}),
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      updateAgentState(agentType, { error: msg, loading: false });
    } finally {
      loadingRef.current.delete(agentType);
    }
  }, [updateAgentState, initialPrompt, apiCreateSession, apiListSessions, apiHistorySessions]);

  // Auto-load agents when new tabs appear in sessionsByAgent.
  // Only eagerly load the active tab — background tabs are deferred until the
  // user switches to them to avoid creating duplicate backend sessions on mount.
  useEffect(() => {
    for (const agentType of Object.keys(sessionsByAgent)) {
      if (agentStates[agentType]?.sessionId || agentStates[agentType]?.loading || agentStates[agentType]?.error) continue;
      if (agentType !== activeWorker) continue;
      loadAgentForType(agentType);
    }
  }, [sessionsByAgent, agentStates, loadAgentForType, updateAgentState, activeWorker]);

  // --- Fetch graph topology when a session becomes ready ---
  const fetchGraphForAgent = useCallback(async (agentType: string, sessionId: string, knownGraphId?: string) => {
    try {
      let graphId = knownGraphId;
      if (!graphId) {
        const { graphs } = await sessionsApi.graphs(sessionId);
        if (!graphs.length) return;
        graphId = graphs[0];
      }
      const topology = await graphsApi.nodes(sessionId, graphId);

      updateAgentState(agentType, { graphId, nodeSpecs: topology.nodes });

      const graphNodes = topologyToGraphNodes(topology);
      if (graphNodes.length === 0) return;

      setSessionsByAgent((prev) => {
        const sessions = prev[agentType] || [];
        if (!sessions.length) return prev;
        return {
          ...prev,
          [agentType]: sessions.map((s, i) =>
            i === 0 ? { ...s, graphNodes } : s,
          ),
        };
      });
    } catch {
      // Graph fetch failed — keep using empty data
    }
  }, [updateAgentState]);

  // Track which sessions already have an in-flight or completed graph fetch
  // to prevent the flood of duplicate API calls.  agentStates changes on every
  // SSE event (text delta, tool_call, etc.) which re-triggers this effect
  // before the first response has returned.
  const fetchedGraphSessionsRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    for (const [agentType, state] of Object.entries(agentStates)) {
      if (!state.sessionId || !state.ready || state.nodeSpecs.length > 0 || state.graphId) continue;
      if (fetchedGraphSessionsRef.current.has(state.sessionId)) continue;
      fetchedGraphSessionsRef.current.add(state.sessionId);
      fetchGraphForAgent(agentType, state.sessionId);
    }
  }, [agentStates, fetchGraphForAgent]);

  // --- Fetch draft graph when a session is in planning phase ---
  // Covers initial load, tab switches, reconnects, and cold restores.
  const fetchedDraftSessionsRef = useRef<Set<string>>(new Set());
  const fetchedFlowchartMapSessionsRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    for (const [agentType, state] of Object.entries(agentStates)) {
      if (!state.sessionId || !state.ready) continue;

      if (state.queenPhase === "planning") {
        // Fetch draft graph for planning phase
        if (state.draftGraph) continue;
        if (fetchedDraftSessionsRef.current.has(state.sessionId)) continue;
        fetchedDraftSessionsRef.current.add(state.sessionId);
        graphsApi.draftGraph(state.sessionId).then(({ draft }) => {
          if (draft) updateAgentState(agentType, { draftGraph: draft });
        }).catch(() => {});
      } else if (state.queenPhase !== "building") {
        // Fetch flowchart map for non-building phases (staging, running)
        if (state.originalDraft) continue; // already have it
        if (fetchedFlowchartMapSessionsRef.current.has(state.sessionId)) continue;
        fetchedFlowchartMapSessionsRef.current.add(state.sessionId);
        graphsApi.flowchartMap(state.sessionId).then(({ map, original_draft }) => {
          if (original_draft) {
            updateAgentState(agentType, {
              flowchartMap: map,
              originalDraft: original_draft,
              draftGraph: null,
            });
          }
        }).catch(() => {});
      }
    }
  }, [agentStates, updateAgentState]);

  // Poll entry points every second to keep next_fire_in countdowns fresh
  // and discover dynamically created triggers (via set_trigger).
  useEffect(() => {
    const id = setInterval(async () => {
      for (const [agentType, sessions] of Object.entries(sessionsByAgent)) {
        const session = sessions[0];
        if (!session) continue;
        const state = agentStates[agentType];
        if (!state?.sessionId) continue;
        try {
          const { entry_points } = await sessionsApi.entryPoints(state.sessionId);
          // Skip non-manual triggers only
          const triggerEps = entry_points.filter(ep => ep.trigger_type !== "manual");
          if (triggerEps.length === 0) continue;

          const fireMap = new Map<string, number>();
          const taskMap = new Map<string, string>();
          const labelMap = new Map<string, string>();
          const targetMap = new Map<string, string>();
          for (const ep of triggerEps) {
            const nodeId = `__trigger_${ep.id}`;
            if (ep.next_fire_in != null) {
              fireMap.set(nodeId, ep.next_fire_in);
            }
            if (ep.task != null) {
              taskMap.set(nodeId, ep.task);
            }
            const cron = ep.trigger_config?.cron as string | undefined;
            const interval = ep.trigger_config?.interval_minutes as number | undefined;
            const epLabel = cron
              ? cronToLabel(cron)
              : interval
                ? `Every ${interval >= 60 ? `${interval / 60}h` : `${interval}m`}`
                : ep.name || undefined;
            if (epLabel) {
              labelMap.set(nodeId, epLabel);
            }
            if (ep.entry_node) {
              targetMap.set(nodeId, ep.entry_node);
            }
          }

          setSessionsByAgent((prev) => {
            const ss = prev[agentType];
            if (!ss?.length) return prev;
            const existingIds = new Set(ss[0].graphNodes.map(n => n.id));

            // Update existing trigger nodes (countdown, task, label, target)
            let updated = ss[0].graphNodes.map((n) => {
              if (n.nodeType !== "trigger") return n;
              const nfi = fireMap.get(n.id);
              const task = taskMap.get(n.id);
              const label = labelMap.get(n.id);
              const target = targetMap.get(n.id);
              if (nfi == null && task == null && !label && !target) return n;
              return {
                ...n,
                ...(label && label !== n.label ? { label } : {}),
                ...(target ? { next: [target] } : {}),
                triggerConfig: {
                  ...n.triggerConfig,
                  ...(nfi != null ? { next_fire_in: nfi } : {}),
                  ...(task != null ? { task } : {}),
                },
              };
            });

            // Discover new triggers not yet in the graph
            const fallbackEntry = ss[0].graphNodes.find(n => n.nodeType !== "trigger")?.id;
            const newNodes: GraphNode[] = [];
            for (const ep of triggerEps) {
              const nodeId = `__trigger_${ep.id}`;
              if (existingIds.has(nodeId)) continue;
              const target = ep.entry_node || fallbackEntry;
              newNodes.push({
                id: nodeId,
                label: labelMap.get(nodeId) || ep.name || ep.id,
                status: "pending",
                nodeType: "trigger",
                triggerType: ep.trigger_type,
                triggerConfig: {
                  ...ep.trigger_config,
                  ...(ep.next_fire_in != null ? { next_fire_in: ep.next_fire_in } : {}),
                  ...(ep.task ? { task: ep.task } : {}),
                },
                ...(target ? { next: [target] } : {}),
              });
            }
            if (newNodes.length > 0) {
              updated = [...newNodes, ...updated];
            }

            // Skip update if nothing changed
            if (newNodes.length === 0 && updated.every((n, idx) => n === ss[0].graphNodes[idx])) return prev;
            return {
              ...prev,
              [agentType]: ss.map((s, i) => (i === 0 ? { ...s, graphNodes: updated } : s)),
            };
          });
        } catch {
          // Entry points fetch failed — skip this tick
        }
      }
    }, 1_000);
    return () => clearInterval(id);
  }, [sessionsByAgent, agentStates]);

  // --- Graph node status helpers (now accept agentType) ---
  const updateGraphNodeStatus = useCallback(
    (agentType: string, nodeId: string, status: NodeStatus, extra?: Partial<GraphNode>) => {
      setSessionsByAgent((prev) => {
        const sessions = prev[agentType] || [];
        const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
        return {
          ...prev,
          [agentType]: sessions.map((s) => {
            if (s.id !== activeId) return s;
            return {
              ...s,
              graphNodes: s.graphNodes.map((n) =>
                n.id === nodeId ? { ...n, status, ...extra } : n
              ),
            };
          }),
        };
      });
    },
    [],
  );

  const markAllNodesAs = useCallback(
    (agentType: string, fromStatus: NodeStatus | NodeStatus[], toStatus: NodeStatus) => {
      const fromArr = Array.isArray(fromStatus) ? fromStatus : [fromStatus];
      setSessionsByAgent((prev) => {
        const sessions = prev[agentType] || [];
        const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
        return {
          ...prev,
          [agentType]: sessions.map((s) => {
            if (s.id !== activeId) return s;
            return {
              ...s,
              graphNodes: s.graphNodes.map((n) =>
                fromArr.includes(n.status) ? { ...n, status: toStatus } : n
              ),
            };
          }),
        };
      });
    },
    [],
  );

  const handlePause = useCallback(async () => {
    const state = agentStates[activeWorker];
    if (!state?.sessionId) return;

    // If we don't have an execution ID, the UI is stale — just reset state
    if (!state.currentExecutionId) {
      updateAgentState(activeWorker, { workerRunState: "idle", currentExecutionId: null });
      markAllNodesAs(activeWorker, ["running", "looping"], "pending");
      return;
    }

    try {
      const result = await executionApi.pause(state.sessionId, state.currentExecutionId);
      // If the backend says "not found", the execution already finished —
      // reset UI state instead of showing an error.
      if (result && !result.stopped) {
        updateAgentState(activeWorker, { workerRunState: "idle", currentExecutionId: null });
        markAllNodesAs(activeWorker, ["running", "looping"], "pending");
        return;
      }
      updateAgentState(activeWorker, { workerRunState: "idle", currentExecutionId: null });
      markAllNodesAs(activeWorker, ["running", "looping"], "pending");
    } catch (err) {
      // Network errors or non-2xx responses — still reset the UI since
      // the execution is likely gone, but also surface the error.
      updateAgentState(activeWorker, { workerRunState: "idle", currentExecutionId: null });
      markAllNodesAs(activeWorker, ["running", "looping"], "pending");
      const errMsg = err instanceof Error ? err.message : String(err);
      setSessionsByAgent((prev) => {
        const sessions = prev[activeWorker] || [];
        const activeId = activeSessionRef.current[activeWorker] || sessions[0]?.id;
        return {
          ...prev,
          [activeWorker]: sessions.map((s) => {
            if (s.id !== activeId) return s;
            const errorMsg: ChatMessage = {
              id: makeId(), agent: "System", agentColor: "",
              content: `Failed to pause: ${errMsg}`,
              timestamp: "", type: "system", thread: activeWorker, createdAt: Date.now(),
            };
            return { ...s, messages: [...s.messages, errorMsg] };
          }),
        };
      });
    }
  }, [agentStates, activeWorker, markAllNodesAs, updateAgentState]);

  const handleCancelQueen = useCallback(async () => {
    const state = agentStates[activeWorker];
    if (!state?.sessionId) return;
    try {
      await executionApi.cancelQueen(state.sessionId);
    } catch {
      // Best-effort — queen may have already finished
    }
    updateAgentState(activeWorker, { isTyping: false, isStreaming: false, queenIsTyping: false, workerIsTyping: false });
  }, [agentStates, activeWorker, updateAgentState]);

  // --- Node log helper (writes into agentStates) ---
  const appendNodeLog = useCallback((agentType: string, nodeId: string, line: string) => {
    setAgentStates((prev) => {
      const state = prev[agentType];
      if (!state) return prev;
      const existing = state.nodeLogs[nodeId] || [];
      return {
        ...prev,
        [agentType]: {
          ...state,
          nodeLogs: {
            ...state.nodeLogs,
            [nodeId]: [...existing, line].slice(-200),
          },
        },
      };
    });
  }, []);

  // --- SSE event handler ---
  const upsertChatMessage = useCallback(
    (agentType: string, chatMsg: ChatMessage, options?: { reconcileOptimisticUser?: boolean }) => {
      setSessionsByAgent((prev) => {
        const sessions = prev[agentType] || [];
        const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
        return {
          ...prev,
          [agentType]: sessions.map((s) => {
            if (s.id !== activeId) return s;
            const idx = s.messages.findIndex((m) => m.id === chatMsg.id);
            let newMessages: ChatMessage[];
            if (idx >= 0) {
              // Update existing message in place, preserve position
              newMessages = s.messages.map((m, i) =>
                i === idx ? { ...m, ...chatMsg, createdAt: m.createdAt ?? chatMsg.createdAt } : m,
              );
            } else {
              const shouldReconcileOptimisticUser =
                !!options?.reconcileOptimisticUser && chatMsg.type === "user" && s.messages.length > 0;
              if (shouldReconcileOptimisticUser) {
                const lastIdx = s.messages.length - 1;
                const lastMsg = s.messages[lastIdx];
                const incomingTs = chatMsg.createdAt ?? Date.now();
                const lastTs = lastMsg.createdAt ?? incomingTs;
                const sameMessage =
                  lastMsg.type === "user"
                  && lastMsg.content === chatMsg.content
                  && Math.abs(incomingTs - lastTs) <= 15000;
                if (sameMessage) {
                  newMessages = s.messages.map((m, i) =>
                    i === lastIdx ? { ...m, id: chatMsg.id } : m,
                  );
                  return { ...s, messages: newMessages };
                }
              }

              // Append — SSE events arrive in server-timestamp order via the
              // shared EventBus, so arrival order already interleaves queen
              // and worker correctly.  Local user messages are always created
              // before their server responses, so append is safe there too.
              newMessages = [...s.messages, chatMsg];
            }
            return { ...s, messages: newMessages };
          }),
        };
      });
    },
    [],
  );

  const handleSSEEvent = useCallback(
    (agentType: string, event: AgentEvent) => {
      const streamId = event.stream_id;
      const isQueen = streamId === "queen";
      if (isQueen) console.log('[QUEEN] handleSSEEvent:', event.type, 'agentType:', agentType);
      // Drop queen message content while suppressing the auto-intro after a cold-restore.
      // Uses a synchronous ref to avoid race conditions with React state batching.
      const suppressQueenMessages = isQueen && suppressIntroRef.current.has(agentType);
      const agentDisplayName = agentStates[agentType]?.displayName;
      const displayName = isQueen ? "Queen Bee" : (agentDisplayName || undefined);
      const role = isQueen ? "queen" as const : "worker" as const;
      const ts = fmtLogTs(event.timestamp);
      // Turn counter is per-stream so queen and worker tool pills don't
      // interfere.  A worker node_loop_iteration no longer increments
      // the queen's turn counter (which would cause pill ID mismatches
      // between tool_call_started and tool_call_completed).
      const turnKey = `${agentType}:${streamId}`;
      const currentTurn = turnCounterRef.current[turnKey] ?? 0;
      // Backend event timestamp for correct queen/worker message ordering
      const eventCreatedAt = event.timestamp ? new Date(event.timestamp).getTime() : Date.now();

      // Mark queen as ready on the first queen SSE event.
      // Deferred to individual event handlers below so we can batch it with
      // other state updates (e.g. queenIsTyping) and avoid a flash frame
      // where queenReady=true but queenIsTyping=false.
      const shouldMarkQueenReady = isQueen && !agentStates[agentType]?.queenReady;

      switch (event.type) {
        case "execution_started":
          if (isQueen) {
            turnCounterRef.current[turnKey] = currentTurn + 1;
            updateAgentState(agentType, { isTyping: true, queenIsTyping: true, ...(shouldMarkQueenReady && { queenReady: true }) });
          } else {
            // Warn if prior LLM snapshots are being dropped (edge case: execution_completed never arrived)
            const priorSnapshots = agentStates[agentType]?.llmSnapshots || {};
            if (Object.keys(priorSnapshots).length > 0) {
              console.debug(`[hive] execution_started: dropping ${Object.keys(priorSnapshots).length} unflushed LLM snapshot(s)`);
            }
            // Insert a run divider when a new run_id is detected
            const incomingRunId = event.run_id || null;
            const prevRunId = agentStates[agentType]?.currentRunId;
            if (incomingRunId && incomingRunId !== prevRunId) {
              const dividerMsg: ChatMessage = {
                id: `run-divider-${incomingRunId}`,
                agent: "",
                agentColor: "",
                content: prevRunId ? "New Run" : "Run Started",
                timestamp: ts,
                type: "run_divider",
                role: "worker",
                thread: agentType,
                createdAt: eventCreatedAt,
              };
              upsertChatMessage(agentType, dividerMsg);
            }
            turnCounterRef.current[turnKey] = currentTurn + 1;
            updateAgentState(agentType, {
              isTyping: true,
              isStreaming: false,
              workerIsTyping: true,
              awaitingInput: false,
              workerRunState: "running",
              currentExecutionId: event.execution_id || agentStates[agentType]?.currentExecutionId || null,
              currentRunId: incomingRunId,
              nodeLogs: {},
              subagentReports: [],
              llmSnapshots: {},
              activeToolCalls: {},
              pendingQuestion: null,
              pendingOptions: null,
              pendingQuestions: null,
              pendingQuestionSource: null,
            });
            markAllNodesAs(agentType, ["running", "looping", "complete", "error"], "pending");
          }
          break;

        case "execution_completed":
          if (isQueen) {
            suppressIntroRef.current.delete(agentType);
            updateAgentState(agentType, { isTyping: false, queenIsTyping: false });
          } else {
            // Flush any remaining LLM snapshots before clearing state
            const completedSnapshots = agentStates[agentType]?.llmSnapshots || {};
            for (const [nid, text] of Object.entries(completedSnapshots)) {
              if (text?.trim()) {
                appendNodeLog(agentType, nid, `${ts} INFO  LLM: ${truncate(text.trim(), 300)}`);
              }
            }
            updateAgentState(agentType, {
              isTyping: false,
              isStreaming: false,
              workerIsTyping: false,
              awaitingInput: false,
              workerInputMessageId: null,
              workerRunState: "idle",
              currentExecutionId: null,
              llmSnapshots: {},
              pendingQuestion: null,
              pendingOptions: null,
              pendingQuestions: null,
              pendingQuestionSource: null,
            });
            markAllNodesAs(agentType, ["running", "looping"], "complete");

            // Re-fetch graph topology so timer countdowns refresh
            const sid = agentStates[agentType]?.sessionId;
            const gid = agentStates[agentType]?.graphId;
            if (sid) fetchGraphForAgent(agentType, sid, gid || undefined);
          }
          break;

        case "execution_paused":
        case "execution_failed":
        case "client_output_delta":
        case "client_input_received":
        case "client_input_requested":
        case "llm_text_delta": {
          const chatMsg = sseEventToChatMessage(event, agentType, displayName, currentTurn);
          if (isQueen) console.log('[QUEEN] chatMsg:', chatMsg?.id, chatMsg?.content?.slice(0, 50), 'turn:', currentTurn);
          if (chatMsg && !suppressQueenMessages) {
            // Queen emits multiple client_output_delta / llm_text_delta snapshots
            // across iterations and inner tool-loop turns.  Merge all inner_turns
            // within the same iteration into ONE bubble so the queen's multi-step
            // tool loop (text → tool → text → tool → text) appears as one cohesive
            // message rather than many small fragments.
            if (isQueen && (event.type === "client_output_delta" || event.type === "llm_text_delta") && event.execution_id) {
              const iter = event.data?.iteration ?? 0;
              const inner = (event.data?.inner_turn as number) ?? 0;
              const iterKey = `${agentType}:${event.execution_id}:${iter}`;

              // Store the latest snapshot for this inner_turn
              if (!queenIterTextRef.current[iterKey]) {
                queenIterTextRef.current[iterKey] = {};
              }
              const snapshot = (event.data?.snapshot as string) || (event.data?.content as string) || "";
              queenIterTextRef.current[iterKey][inner] = snapshot;

              // Concatenate all inner_turn snapshots in order
              const parts = queenIterTextRef.current[iterKey];
              const sortedInners = Object.keys(parts).map(Number).sort((a, b) => a - b);
              chatMsg.content = sortedInners.map(k => parts[k]).join("\n");

              // Single ID per iteration — no inner_turn in the ID
              chatMsg.id = `queen-stream-${event.execution_id}-${iter}`;
            }
            if (isQueen) {
              chatMsg.role = role;
              chatMsg.phase = queenPhaseRef.current[agentType] as ChatMessage["phase"];
            }
            upsertChatMessage(agentType, chatMsg, {
              reconcileOptimisticUser: event.type === "client_input_received",
            });
          }

          // Mark streaming when LLM text is actively arriving
          if (event.type === "llm_text_delta" || event.type === "client_output_delta") {
            updateAgentState(agentType, { isStreaming: true, ...(isQueen ? {} : { workerIsTyping: false }) });
          }

          if (event.type === "llm_text_delta" && !isQueen && event.node_id) {
            const snapshot = (event.data?.snapshot as string) || "";
            if (snapshot) {
              setAgentStates(prev => {
                const state = prev[agentType];
                if (!state) return prev;
                return {
                  ...prev,
                  [agentType]: {
                    ...state,
                    llmSnapshots: { ...state.llmSnapshots, [event.node_id!]: snapshot },
                  },
                };
              });
            }
          }

          if (event.type === "client_input_requested") {
            console.log('[CLIENT_INPUT_REQ] stream_id:', streamId, 'isQueen:', isQueen, 'node_id:', event.node_id, 'prompt:', (event.data?.prompt as string)?.slice(0, 80), 'agentType:', agentType);
            const rawOptions = event.data?.options;
            const options = Array.isArray(rawOptions) ? (rawOptions as string[]) : null;
            const rawQuestions = event.data?.questions;
            const questions = Array.isArray(rawQuestions)
              ? (rawQuestions as { id: string; prompt: string; options?: string[] }[])
              : null;
            if (isQueen) {
              const prompt = (event.data?.prompt as string) || "";
              setAgentStates(prev => {
                const cur = prev[agentType] || defaultAgentState();
                return {
                  ...prev, [agentType]: {
                    ...cur,
                    awaitingInput: true,
                    isTyping: false,
                    isStreaming: false,
                    queenIsTyping: false,
                    queenBuilding: false,
                    pendingQuestion: prompt || null,
                    pendingOptions: options,
                    pendingQuestions: questions,
                    pendingQuestionSource: "queen",
                  }
                };
              });
            } else {
              console.warn(
                "[CLIENT_INPUT_REQ] ignoring non-queen client_input_requested event",
                streamId,
                event.node_id,
              );
            }
          }
          if (event.type === "execution_paused") {
            updateAgentState(agentType, { isTyping: false, isStreaming: false, queenIsTyping: false, workerIsTyping: false, awaitingInput: false, workerInputMessageId: null, pendingQuestion: null, pendingOptions: null, pendingQuestions: null, pendingQuestionSource: null });
            if (!isQueen) {
              updateAgentState(agentType, { workerRunState: "idle", currentExecutionId: null });
              markAllNodesAs(agentType, ["running", "looping"], "pending");
            }
          }
          if (event.type === "execution_failed") {
            updateAgentState(agentType, { isTyping: false, isStreaming: false, queenIsTyping: false, workerIsTyping: false, awaitingInput: false, workerInputMessageId: null, pendingQuestion: null, pendingOptions: null, pendingQuestions: null, pendingQuestionSource: null });
            if (!isQueen) {
              updateAgentState(agentType, { workerRunState: "idle", currentExecutionId: null });
              if (event.node_id) {
                updateGraphNodeStatus(agentType, event.node_id, "error");
                const errMsg = (event.data?.error as string) || "unknown error";
                appendNodeLog(agentType, event.node_id, `${ts} ERROR Execution failed: ${errMsg}`);
              }
              markAllNodesAs(agentType, ["running", "looping"], "pending");
            }
          }
          break;
        }

        case "node_loop_started":
          turnCounterRef.current[turnKey] = currentTurn + 1;
          updateAgentState(agentType, { isTyping: true, activeToolCalls: {} });
          if (!isQueen && event.node_id) {
            const sessions = sessionsRef.current[agentType] || [];
            const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
            const session = sessions.find((s) => s.id === activeId);
            const existing = session?.graphNodes.find((n) => n.id === event.node_id);
            const isRevisit = existing?.status === "complete";
            updateGraphNodeStatus(agentType, event.node_id, isRevisit ? "looping" : "running", {
              maxIterations: (event.data?.max_iterations as number) ?? undefined,
            });
            appendNodeLog(agentType, event.node_id, `${ts} INFO  Node started`);
          }
          break;

        case "node_loop_iteration":
          turnCounterRef.current[turnKey] = currentTurn + 1;
          if (isQueen) {
            updateAgentState(agentType, { isStreaming: false, activeToolCalls: {}, awaitingInput: false, pendingQuestion: null, pendingOptions: null, pendingQuestions: null, pendingQuestionSource: null });
          } else {
            updateAgentState(agentType, { isStreaming: false, workerIsTyping: true, activeToolCalls: {}, awaitingInput: false, pendingQuestion: null, pendingOptions: null, pendingQuestions: null, pendingQuestionSource: null });
          }
          if (!isQueen && event.node_id) {
            const pendingText = agentStates[agentType]?.llmSnapshots[event.node_id];
            if (pendingText?.trim()) {
              appendNodeLog(agentType, event.node_id, `${ts} INFO  LLM: ${truncate(pendingText.trim(), 300)}`);
              setAgentStates(prev => {
                const state = prev[agentType];
                if (!state) return prev;
                const { [event.node_id!]: _, ...rest } = state.llmSnapshots;
                return { ...prev, [agentType]: { ...state, llmSnapshots: rest } };
              });
            }
            const iter = (event.data?.iteration as number) ?? undefined;
            updateGraphNodeStatus(agentType, event.node_id, "looping", { iterations: iter });
            appendNodeLog(agentType, event.node_id, `${ts} INFO  Iteration ${iter ?? "?"}`);
          }
          break;

        case "node_loop_completed":
          if (!isQueen && event.node_id) {
            const pendingText = agentStates[agentType]?.llmSnapshots[event.node_id];
            if (pendingText?.trim()) {
              appendNodeLog(agentType, event.node_id, `${ts} INFO  LLM: ${truncate(pendingText.trim(), 300)}`);
              setAgentStates(prev => {
                const state = prev[agentType];
                if (!state) return prev;
                const { [event.node_id!]: _, ...rest } = state.llmSnapshots;
                return { ...prev, [agentType]: { ...state, llmSnapshots: rest } };
              });
            }
            updateGraphNodeStatus(agentType, event.node_id, "complete");
            appendNodeLog(agentType, event.node_id, `${ts} INFO  Node completed`);
          }
          break;

        case "edge_traversed": {
          if (!isQueen) {
            const sourceNode = event.data?.source_node as string | undefined;
            const targetNode = event.data?.target_node as string | undefined;
            if (sourceNode) updateGraphNodeStatus(agentType, sourceNode, "complete");
            if (targetNode) updateGraphNodeStatus(agentType, targetNode, "running");
          }
          break;
        }

        case "tool_call_started": {
          console.log('[TOOL_PILL] tool_call_started received:', { isQueen, nodeId: event.node_id, streamId: event.stream_id, agentType, executionId: event.execution_id, toolName: event.data?.tool_name });

          // queenBuilding is now driven by queen_phase_changed events

          if (event.node_id) {
            if (!isQueen) {
              const pendingText = agentStates[agentType]?.llmSnapshots[event.node_id];
              if (pendingText?.trim()) {
                appendNodeLog(agentType, event.node_id, `${ts} INFO  LLM: ${truncate(pendingText.trim(), 300)}`);
                setAgentStates(prev => {
                  const state = prev[agentType];
                  if (!state) return prev;
                  const { [event.node_id!]: _, ...rest } = state.llmSnapshots;
                  return { ...prev, [agentType]: { ...state, llmSnapshots: rest } };
                });
              }
              appendNodeLog(agentType, event.node_id, `${ts} INFO  Calling ${(event.data?.tool_name as string) || "unknown"}(${event.data?.tool_input ? truncate(JSON.stringify(event.data.tool_input), 200) : ""})`);

              // Track subagent delegation start
              if ((event.data?.tool_name as string) === "delegate_to_sub_agent") {
                const saInput = event.data?.tool_input as Record<string, unknown> | undefined;
                const saId = (saInput?.agent_id as string) || "";
                if (saId) {
                  setAgentStates(prev => {
                    const state = prev[agentType];
                    if (!state) return prev;
                    return {
                      ...prev,
                      [agentType]: {
                        ...state,
                        subagentReports: [
                          ...state.subagentReports,
                          { subagent_id: saId, message: "Delegating...", timestamp: event.timestamp, status: "running" as const },
                        ],
                      },
                    };
                  });
                }
              }
            }

            const toolName = (event.data?.tool_name as string) || "unknown";
            const toolUseId = (event.data?.tool_use_id as string) || "";

            // Flag when the queen starts designing/updating the flowchart
            if (isQueen && toolName === "save_agent_draft") {
              designingDraftSinceRef.current[agentType] = Date.now();
              // Clear any pending delayed-clear timer from a previous call
              const prev = designingDraftTimerRef.current[agentType];
              if (prev) clearTimeout(prev);
              updateAgentState(agentType, { designingDraft: true });
            }

            // Track active (in-flight) tools and upsert activity row into chat
            const sid = event.stream_id;
            setAgentStates(prev => {
              const state = prev[agentType];
              if (!state) return prev;
              const newActive = { ...state.activeToolCalls, [toolUseId]: { name: toolName, done: false, streamId: sid } };
              // Only include tools from this stream in the pill
              const tools = Object.values(newActive).filter(t => t.streamId === sid).map(t => ({ name: t.name, done: t.done }));
              const allDone = tools.length > 0 && tools.every(t => t.done);
              upsertChatMessage(agentType, {
                id: `tool-pill-${sid}-${event.execution_id || "exec"}-${currentTurn}`,
                agent: agentDisplayName || event.node_id || "Agent",
                agentColor: "",
                content: JSON.stringify({ tools, allDone }),
                timestamp: "",
                type: "tool_status",
                role,
                thread: agentType,
                createdAt: eventCreatedAt,
                nodeId: event.node_id || undefined,
                executionId: event.execution_id || undefined,
              });
              return {
                ...prev,
                [agentType]: { ...state, isStreaming: false, activeToolCalls: newActive },
              };
            });
          } else {
            console.log('[TOOL_PILL] SKIPPED: no node_id', event.node_id);
          }
          break;
        }

        case "tool_call_completed": {
          if (event.node_id) {
            const toolName = (event.data?.tool_name as string) || "unknown";
            const toolUseId = (event.data?.tool_use_id as string) || "";
            const isError = event.data?.is_error as boolean | undefined;
            const result = event.data?.result as string | undefined;
            if (isError) {
              appendNodeLog(agentType, event.node_id, `${ts} ERROR ${toolName} failed: ${truncate(result || "unknown error", 200)}`);
            } else {
              const resultStr = result ? ` (${truncate(result, 200)})` : "";
              appendNodeLog(agentType, event.node_id, `${ts} INFO  ${toolName} done${resultStr}`);
            }

            // Track subagent delegation completion
            if (toolName === "delegate_to_sub_agent" && result) {
              try {
                const parsed = JSON.parse(result);
                const saId = (parsed?.metadata?.agent_id as string) || "";
                const success = parsed?.metadata?.success as boolean;
                if (saId) {
                  setAgentStates(prev => {
                    const state = prev[agentType];
                    if (!state) return prev;
                    return {
                      ...prev,
                      [agentType]: {
                        ...state,
                        subagentReports: [
                          ...state.subagentReports,
                          { subagent_id: saId, message: success ? "Completed" : "Failed", timestamp: event.timestamp, status: success ? "complete" as const : "error" as const },
                        ],
                      },
                    };
                  });
                }
              } catch { /* ignore parse errors */ }
            }

            // Mark tool as done and update activity row
            const sid = event.stream_id;
            setAgentStates(prev => {
              const state = prev[agentType];
              if (!state) return prev;
              const updated = { ...state.activeToolCalls };
              if (updated[toolUseId]) {
                updated[toolUseId] = { ...updated[toolUseId], done: true };
              }
              const tools = Object.values(updated).filter(t => t.streamId === sid).map(t => ({ name: t.name, done: t.done }));
              const allDone = tools.length > 0 && tools.every(t => t.done);
              upsertChatMessage(agentType, {
                id: `tool-pill-${sid}-${event.execution_id || "exec"}-${currentTurn}`,
                agent: agentDisplayName || event.node_id || "Agent",
                agentColor: "",
                content: JSON.stringify({ tools, allDone }),
                timestamp: "",
                type: "tool_status",
                role,
                thread: agentType,
                createdAt: eventCreatedAt,
                nodeId: event.node_id || undefined,
                executionId: event.execution_id || undefined,
              });
              return {
                ...prev,
                [agentType]: { ...state, activeToolCalls: updated },
              };
            });
          }
          break;
        }

        case "node_internal_output":
          if (!isQueen && event.node_id) {
            const content = (event.data?.content as string) || "";
            if (content.trim()) {
              appendNodeLog(agentType, event.node_id, `${ts} INFO  ${content}`);
            }
          }
          break;

        case "subagent_report": {
          if (!isQueen && event.node_id) {
            const subagentId = (event.data?.subagent_id as string) || "";
            const message = (event.data?.message as string) || "";
            const data = event.data?.data as Record<string, unknown> | undefined;
            // Extract parent node ID from "parentNodeId:subagent:agentId" format
            const parentNodeId = event.node_id.split(":subagent:")[0] || event.node_id;
            appendNodeLog(agentType, parentNodeId, `${ts} INFO  [Subagent:${subagentId}] ${truncate(message, 200)}`);
            setAgentStates(prev => {
              const state = prev[agentType];
              if (!state) return prev;
              return {
                ...prev,
                [agentType]: {
                  ...state,
                  subagentReports: [
                    ...state.subagentReports,
                    { subagent_id: subagentId, message, data, timestamp: event.timestamp },
                  ],
                },
              };
            });
          }
          break;
        }

        case "node_stalled":
          if (!isQueen && event.node_id) {
            const reason = (event.data?.reason as string) || "unknown";
            appendNodeLog(agentType, event.node_id, `${ts} WARN  Stalled: ${reason}`);
          }
          break;

        case "node_retry":
          if (!isQueen && event.node_id) {
            const retryCount = (event.data?.retry_count as number) ?? "?";
            const maxRetries = (event.data?.max_retries as number) ?? "?";
            const retryError = (event.data?.error as string) || "";
            appendNodeLog(agentType, event.node_id, `${ts} WARN  Retry ${retryCount}/${maxRetries}${retryError ? `: ${retryError}` : ""}`);
          }
          break;

        case "node_tool_doom_loop":
          if (!isQueen && event.node_id) {
            const description = (event.data?.description as string) || "tool cycle detected";
            appendNodeLog(agentType, event.node_id, `${ts} WARN  Doom loop: ${description}`);
          }
          break;

        case "context_compacted":
          if (!isQueen && event.node_id) {
            const usageBefore = (event.data?.usage_before as number) ?? "?";
            const usageAfter = (event.data?.usage_after as number) ?? "?";
            appendNodeLog(agentType, event.node_id, `${ts} INFO  Context compacted: ${usageBefore}% -> ${usageAfter}%`);
          }
          break;

        case "context_usage_updated": {
            const streamKey = isQueen ? "__queen__" : (event.node_id || streamId);
            const usagePct = (event.data?.usage_pct as number) ?? 0;
            const messageCount = (event.data?.message_count as number) ?? 0;
            const estimatedTokens = (event.data?.estimated_tokens as number) ?? 0;
            const maxTokens = (event.data?.max_context_tokens as number) ?? 0;
            setAgentStates(prev => {
              const state = prev[agentType];
              if (!state) return prev;
              return {
                ...prev,
                [agentType]: {
                  ...state,
                  contextUsage: {
                    ...state.contextUsage,
                    [streamKey]: { usagePct, messageCount, estimatedTokens, maxTokens },
                  },
                },
              };
            });
          }
          break;

        case "node_action_plan":
          if (!isQueen && event.node_id) {
            const plan = (event.data?.plan as string) || "";
            if (plan.trim()) {
              setAgentStates(prev => {
                const state = prev[agentType];
                if (!state) return prev;
                return {
                  ...prev,
                  [agentType]: {
                    ...state,
                    nodeActionPlans: { ...state.nodeActionPlans, [event.node_id!]: plan },
                  },
                };
              });
            }
          }
          break;

        case "credentials_required": {
          updateAgentState(agentType, { workerRunState: "idle", error: "credentials_required" });
          const credAgentPath = event.data?.agent_path as string | undefined;
          if (credAgentPath) setCredentialAgentPath(credAgentPath);
          setCredentialsOpen(true);
          break;
        }

        case "queen_phase_changed": {
          const rawPhase = event.data?.phase as string;
          const eventAgentPath = (event.data?.agent_path as string) || null;
          const newPhase: "planning" | "building" | "staging" | "running" =
            rawPhase === "running" ? "running"
            : rawPhase === "staging" ? "staging"
            : rawPhase === "planning" ? "planning"
            : "building";
          queenPhaseRef.current[agentType] = newPhase;
          updateAgentState(agentType, {
            queenPhase: newPhase,
            queenBuilding: newPhase === "building",
            // Sync workerRunState so the RunButton reflects the phase
            workerRunState: newPhase === "running" ? "running" : "idle",
            // Clear originalDraft/flowchartMap when re-entering planning.
            // draftGraph is cleared later when originalDraft arrives, so the
            // entrance animation has data to render during the handoff.
            ...(newPhase === "planning"
              ? { originalDraft: null, flowchartMap: null }
              : {}),
            // Store agent path for credential queries
            ...(eventAgentPath ? { agentPath: eventAgentPath } : {}),
          });
          {
            const sid = agentStates[agentType]?.sessionId;
            if (sid) {
              if (newPhase !== "planning" && newPhase !== "building") {
                fetchedDraftSessionsRef.current.delete(sid);
                fetchedFlowchartMapSessionsRef.current.delete(sid);
                // Fetch the flowchart map (original draft + dissolution mapping)
                graphsApi.flowchartMap(sid).then(({ map, original_draft }) => {
                  updateAgentState(agentType, {
                    flowchartMap: map,
                    originalDraft: original_draft,
                  });
                }).catch(() => {});
              } else if (newPhase === "planning") {
                // Only clear dedup sets when re-entering planning (not building)
                fetchedDraftSessionsRef.current.delete(sid);
                fetchedFlowchartMapSessionsRef.current.delete(sid);
              }
            }
          }
          break;
        }

        case "draft_graph_updated": {
          // The draft dict is published directly as event.data (not nested under a key)
          const draft = event.data as unknown as DraftGraphData | undefined;
          if (draft?.nodes) {
            // Ensure the "Designing flowchart…" spinner stays visible for a
            // minimum duration so users see feedback before the draft appears.
            const MIN_SPINNER_MS = 600;
            const since = designingDraftSinceRef.current[agentType] || 0;
            const elapsed = Date.now() - since;
            const remaining = Math.max(0, MIN_SPINNER_MS - elapsed);

            const applyDraft = () => {
              delete designingDraftTimerRef.current[agentType];
              updateAgentState(agentType, { draftGraph: draft, designingDraft: false });
            };

            if (remaining > 0 && since > 0) {
              // Update draftGraph now (so data is ready) but keep spinner visible
              updateAgentState(agentType, { draftGraph: draft });
              designingDraftTimerRef.current[agentType] = setTimeout(() => {
                updateAgentState(agentType, { designingDraft: false });
                delete designingDraftTimerRef.current[agentType];
              }, remaining);
            } else {
              applyDraft();
            }
          }
          break;
        }

        case "flowchart_map_updated": {
          const mapData = event.data as { map?: Record<string, string[]>; original_draft?: DraftGraphData } | undefined;
          if (mapData) {
            updateAgentState(agentType, {
              flowchartMap: mapData.map ?? null,
              originalDraft: mapData.original_draft ?? null,
              draftGraph: null,
            });
          }
          break;
        }

        case "worker_graph_loaded": {
          const graphName = event.data?.graph_name as string | undefined;
          const agentPathFromEvent = event.data?.agent_path as string | undefined;
          const displayName = formatAgentDisplayName(graphName || baseAgentType(agentType));

          // Invalidate cached credential requirements so the modal fetches
          // fresh data the next time it opens (the new agent may have
          // different credential needs than the previous one).
          clearCredentialCache(agentPathFromEvent);
          clearCredentialCache(baseAgentType(agentType));

          // Update agent state: new display name, reset graph so topology refetch triggers
          updateAgentState(agentType, {
            displayName,
            queenBuilding: false,
            workerRunState: "idle",
            graphId: null,
            nodeSpecs: [],
          });

          // Update ONLY the active session's label + graph nodes — never touch
          // sessions belonging to a different tab sharing the same agentType key.
          // Also clear worker messages so the fresh worker starts with a clean slate.
          const activeId = activeSessionRef.current[agentType];
          setSessionsByAgent(prev => ({
            ...prev,
            [agentType]: (prev[agentType] || []).map(s =>
              s.id === activeId || (!activeId && prev[agentType]?.[0]?.id === s.id)
                ? { ...s, label: displayName, graphNodes: [], messages: s.messages.filter(m => m.role !== "worker") }
                : s
            ),
          }));

          // Explicitly fetch graph topology for the newly loaded worker
          // (don't rely solely on the effect — state may already be null/empty)
          const sessionId = agentStates[agentType]?.sessionId;
          if (sessionId) {
            fetchGraphForAgent(agentType, sessionId);
          }

          break;
        }

        case "trigger_activated": {
          const triggerId = event.data?.trigger_id as string;
          if (triggerId) {
            const nodeId = `__trigger_${triggerId}`;
            // If the trigger node doesn't exist yet (dynamically created via set_trigger),
            // synthesize it before updating status.
            setSessionsByAgent(prev => {
              const sessions = prev[agentType] || [];
              const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
              return {
                ...prev,
                [agentType]: sessions.map(s => {
                  if (s.id !== activeId) return s;
                  const exists = s.graphNodes.some(n => n.id === nodeId);
                  if (exists) {
                    return {
                      ...s,
                      graphNodes: s.graphNodes.map(n =>
                        n.id === nodeId ? { ...n, status: "running" as const } : n,
                      ),
                    };
                  }
                  // Synthesize new trigger node at the front of the graph
                  const triggerType = (event.data?.trigger_type as string) || "timer";
                  const triggerConfig = (event.data?.trigger_config as Record<string, unknown>) || {};
                  const entryNode = (event.data?.entry_node as string) || s.graphNodes.find(n => n.nodeType !== "trigger")?.id;
                  const triggerName = (event.data?.name as string) || triggerId;
                  const _cron = triggerConfig.cron as string | undefined;
                  const _interval = triggerConfig.interval_minutes as number | undefined;
                  const computedLabel = _cron
                    ? cronToLabel(_cron)
                    : _interval
                      ? `Every ${_interval >= 60 ? `${_interval / 60}h` : `${_interval}m`}`
                      : triggerName;
                  const newNode: GraphNode = {
                    id: nodeId,
                    label: computedLabel,
                    status: "running",
                    nodeType: "trigger",
                    triggerType,
                    triggerConfig,
                    ...(entryNode ? { next: [entryNode] } : {}),
                  };
                  return { ...s, graphNodes: [newNode, ...s.graphNodes] };
                }),
              };
            });
          }
          break;
        }

        case "trigger_deactivated": {
          const triggerId = event.data?.trigger_id as string;
          if (triggerId) {
            // Clear next_fire_in so countdown hides when inactive
            setSessionsByAgent(prev => {
              const sessions = prev[agentType] || [];
              const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
              return {
                ...prev,
                [agentType]: sessions.map(s => {
                  if (s.id !== activeId) return s;
                  return {
                    ...s,
                    graphNodes: s.graphNodes.map(n => {
                      if (n.id !== `__trigger_${triggerId}`) return n;
                      const { next_fire_in: _, ...restConfig } = (n.triggerConfig || {}) as Record<string, unknown> & { next_fire_in?: unknown };
                      return { ...n, status: "pending" as const, triggerConfig: restConfig };
                    }),
                  };
                }),
              };
            });
          }
          break;
        }

        case "trigger_fired": {
          const triggerId = event.data?.trigger_id as string;
          if (triggerId) {
            const nodeId = `__trigger_${triggerId}`;
            updateGraphNodeStatus(agentType, nodeId, "complete");
            setTimeout(() => updateGraphNodeStatus(agentType, nodeId, "running"), 1500);
          }
          break;
        }

        case "trigger_available": {
          const triggerId = event.data?.trigger_id as string;
          if (triggerId) {
            const nodeId = `__trigger_${triggerId}`;
            setSessionsByAgent(prev => {
              const sessions = prev[agentType] || [];
              const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
              return {
                ...prev,
                [agentType]: sessions.map(s => {
                  if (s.id !== activeId) return s;
                  if (s.graphNodes.some(n => n.id === nodeId)) return s;
                  const triggerType = (event.data?.trigger_type as string) || "timer";
                  const triggerConfig = (event.data?.trigger_config as Record<string, unknown>) || {};
                  const entryNode = (event.data?.entry_node as string) || s.graphNodes.find(n => n.nodeType !== "trigger")?.id;
                  const triggerName = (event.data?.name as string) || triggerId;
                  const _cron2 = triggerConfig.cron as string | undefined;
                  const _interval2 = triggerConfig.interval_minutes as number | undefined;
                  const computedLabel2 = _cron2
                    ? cronToLabel(_cron2)
                    : _interval2
                      ? `Every ${_interval2 >= 60 ? `${_interval2 / 60}h` : `${_interval2}m`}`
                      : triggerName;
                  const newNode: GraphNode = {
                    id: nodeId,
                    label: computedLabel2,
                    status: "pending",
                    nodeType: "trigger",
                    triggerType,
                    triggerConfig,
                    ...(entryNode ? { next: [entryNode] } : {}),
                  };
                  return { ...s, graphNodes: [newNode, ...s.graphNodes] };
                }),
              };
            });
          }
          break;
        }

        case "trigger_updated": {
          const triggerId = event.data?.trigger_id as string;
          if (triggerId) {
            const nodeId = `__trigger_${triggerId}`;
            const triggerConfig = (event.data?.trigger_config as Record<string, unknown>) || {};
            const cron = triggerConfig.cron as string | undefined;
            const interval = triggerConfig.interval_minutes as number | undefined;
            const newLabel = cron
              ? cronToLabel(cron)
              : interval
                ? `Every ${interval >= 60 ? `${interval / 60}h` : `${interval}m`}`
                : undefined;
            setSessionsByAgent(prev => {
              const sessions = prev[agentType] || [];
              const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
              return {
                ...prev,
                [agentType]: sessions.map(s => {
                  if (s.id !== activeId) return s;
                  return {
                    ...s,
                    graphNodes: s.graphNodes.map(n => {
                      if (n.id !== nodeId) return n;
                      return {
                        ...n,
                        ...(newLabel ? { label: newLabel } : {}),
                        triggerConfig: { ...n.triggerConfig, ...triggerConfig },
                      };
                    }),
                  };
                }),
              };
            });
          }
          break;
        }

        case "trigger_removed": {
          const triggerId = event.data?.trigger_id as string;
          if (triggerId) {
            const nodeId = `__trigger_${triggerId}`;
            setSessionsByAgent(prev => {
              const sessions = prev[agentType] || [];
              const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
              return {
                ...prev,
                [agentType]: sessions.map(s => {
                  if (s.id !== activeId) return s;
                  return { ...s, graphNodes: s.graphNodes.filter(n => n.id !== nodeId) };
                }),
              };
            });
          }
          break;
        }

        default:
          // Fallback: ensure queenReady is set even for unexpected first events
          if (shouldMarkQueenReady) updateAgentState(agentType, { queenReady: true });
          break;
      }
    },
    [agentStates, updateAgentState, updateGraphNodeStatus, markAllNodesAs, upsertChatMessage, appendNodeLog, fetchGraphForAgent],
  );

  // --- Multi-session SSE subscription ---
  const sseSessions = useMemo(() => {
    const map: Record<string, string> = {};
    for (const [agentType, state] of Object.entries(agentStates)) {
      if (state.sessionId && state.ready) {
        map[agentType] = state.sessionId;
      }
    }
    return map;
  }, [agentStates]);

  useMultiSSE({ sessions: sseSessions, onEvent: handleSSEEvent });

  const currentSessions = sessionsByAgent[activeWorker] || [];
  const activeSessionId = activeSessionByAgent[activeWorker] || currentSessions[0]?.id;
  const activeSession = currentSessions.find(s => s.id === activeSessionId) || currentSessions[0];

  const currentGraph = activeSession
    ? { nodes: activeSession.graphNodes, title: activeAgentState?.displayName || formatAgentDisplayName(baseAgentType(activeWorker)) }
    : { nodes: [] as GraphNode[], title: "" };

  // Keep selectedNode in sync with live graphNodes (trigger status updates via SSE)
  const liveSelectedNode = selectedNode && currentGraph.nodes.find(n => n.id === selectedNode.id);
  const resolvedSelectedNode = liveSelectedNode || selectedNode;

  // Sync trigger drafts when selected trigger node changes
  useEffect(() => {
    if (resolvedSelectedNode?.nodeType === "trigger") {
      const tc = resolvedSelectedNode.triggerConfig as Record<string, unknown> | undefined;
      setTriggerTaskDraft((tc?.task as string) || "");
      setTriggerCronDraft((tc?.cron as string) || "");
    }
  }, [resolvedSelectedNode?.id]);

  const patchTriggerNode = useCallback((agentType: string, triggerNodeId: string, patch: { task?: string; trigger_config?: Record<string, unknown>; label?: string }) => {
    setSessionsByAgent(prev => {
      const sessions = prev[agentType] || [];
      const activeId = activeSessionRef.current[agentType] || sessions[0]?.id;
      return {
        ...prev,
        [agentType]: sessions.map(s => {
          if (s.id !== activeId) return s;
          return {
            ...s,
            graphNodes: s.graphNodes.map(n => {
              if (n.id !== triggerNodeId) return n;
              return {
                ...n,
                ...(patch.label !== undefined ? { label: patch.label } : {}),
                triggerConfig: {
                  ...n.triggerConfig,
                  ...(patch.trigger_config || {}),
                  ...(patch.task !== undefined ? { task: patch.task } : {}),
                },
              };
            }),
          };
        }),
      };
    });
  }, []);

  // Build a flat list of all agent-type tabs for the tab bar
  const agentTabs = Object.entries(sessionsByAgent)
    .filter(([, sessions]) => sessions.length > 0)
    .map(([agentType, sessions]) => {
      const activeId = activeSessionByAgent[agentType] || sessions[0]?.id;
      const session = sessions.find(s => s.id === activeId) || sessions[0];
      return {
        agentType,
        sessionId: session.id,
        label: session.label,
        isActive: agentType === activeWorker,
        hasRunning: session.graphNodes.some(n => n.status === "running" || n.status === "looping"),
      };
    });
  const openHistorySessionIds = useMemo(() => {
    const ids = new Set<string>();
    for (const sessions of Object.values(sessionsByAgent)) {
      for (const s of sessions) {
        if (s.backendSessionId) ids.add(s.backendSessionId);
        if (s.historySourceId) ids.add(s.historySourceId);
      }
    }
    return Array.from(ids);
  }, [sessionsByAgent]);

  // --- handleSend ---
  const handleSend = useCallback((text: string, thread: string, images?: import("@/components/ChatPanel").ImageContent[]) => {
    if (!activeSession) return;
    const state = agentStates[activeWorker];

    if (!allRequiredCredentialsMet(activeSession.credentials)) {
      const userMsg: ChatMessage = {
        id: makeId(), agent: "You", agentColor: "",
        content: text, timestamp: "", type: "user", thread, createdAt: Date.now(),
      };
      const promptMsg: ChatMessage = {
        id: makeId(), agent: "Queen Bee", agentColor: "",
        content: "Before we get started, you'll need to configure your credentials. Click the **Credentials** button in the top bar to connect the required integrations for this agent.",
        timestamp: "", role: "queen" as const, thread, createdAt: Date.now(),
      };
      setSessionsByAgent(prev => ({
        ...prev,
        [activeWorker]: prev[activeWorker].map(s =>
          s.id === activeSession.id ? { ...s, messages: [...s.messages, userMsg, promptMsg] } : s
        ),
      }));
      return;
    }

    // If queen has a pending question widget, dismiss it when user types directly
    if (agentStates[activeWorker]?.pendingQuestionSource === "queen") {
      updateAgentState(activeWorker, { pendingQuestion: null, pendingOptions: null, pendingQuestions: null, pendingQuestionSource: null });
    }

    const clientMessageId = makeId();
    const userMsg: ChatMessage = {
      id: clientMessageId, agent: "You", agentColor: "",
      content: text, timestamp: "", type: "user", thread, createdAt: Date.now(),
      images,
    };
    setSessionsByAgent(prev => ({
      ...prev,
      [activeWorker]: prev[activeWorker].map(s =>
        s.id === activeSession.id ? { ...s, messages: [...s.messages, userMsg] } : s
      ),
    }));
    suppressIntroRef.current.delete(activeWorker);
    updateAgentState(activeWorker, { isTyping: true, queenIsTyping: true });

    if (state?.sessionId && state?.ready) {
      executionApi.chat(state.sessionId, text, images, undefined, clientMessageId).catch((err: unknown) => {
        const errMsg = err instanceof Error ? err.message : String(err);
        const errorChatMsg: ChatMessage = {
          id: makeId(), agent: "System", agentColor: "",
          content: `Failed to send message: ${errMsg}`,
          timestamp: "", type: "system", thread, createdAt: Date.now(),
        };
        setSessionsByAgent(prev => ({
          ...prev,
          [activeWorker]: prev[activeWorker].map(s =>
            s.id === activeSession.id ? { ...s, messages: [...s.messages, errorChatMsg] } : s
          ),
        }));
        updateAgentState(activeWorker, { isTyping: false, isStreaming: false, queenIsTyping: false });
      });
    } else {
      const errorMsg: ChatMessage = {
        id: makeId(), agent: "System", agentColor: "",
        content: "Cannot send message: backend is not connected. Please wait for the agent to load.",
        timestamp: "", type: "system", thread, createdAt: Date.now(),
      };
      setSessionsByAgent(prev => ({
        ...prev,
        [activeWorker]: prev[activeWorker].map(s =>
          s.id === activeSession.id ? { ...s, messages: [...s.messages, errorMsg] } : s
        ),
      }));
      updateAgentState(activeWorker, { isTyping: false, isStreaming: false });
    }
  }, [activeWorker, activeSession, agentStates, updateAgentState]);

  // --- handleQueenQuestionAnswer: submit queen's own question answer via /chat ---
  // The queen asked the question herself, so she already has context — just send the raw answer.
  const handleQueenQuestionAnswer = useCallback((answer: string, _isOther: boolean) => {
    updateAgentState(activeWorker, { pendingQuestion: null, pendingOptions: null, pendingQuestions: null, pendingQuestionSource: null });
    handleSend(answer, activeWorker);
  }, [activeWorker, handleSend, updateAgentState]);

  // --- handleMultiQuestionAnswer: submit answers to ask_user_multiple ---
  const handleMultiQuestionAnswer = useCallback((answers: Record<string, string>) => {
    updateAgentState(activeWorker, {
      pendingQuestion: null, pendingOptions: null,
      pendingQuestions: null, pendingQuestionSource: null,
    });
    // Format as structured text the LLM can parse
    const lines = Object.entries(answers).map(
      ([id, answer]) => `[${id}]: ${answer}`,
    );
    handleSend(lines.join("\n"), activeWorker);
  }, [activeWorker, handleSend, updateAgentState]);

  // --- handleQuestionDismiss: user closed the question widget without answering ---
  const handleQuestionDismiss = useCallback(() => {
    const state = agentStates[activeWorker];
    if (!state?.sessionId) return;
    const question = state.pendingQuestion || "";

    // Clear UI state immediately
    updateAgentState(activeWorker, {
      pendingQuestion: null,
      pendingOptions: null,
      pendingQuestions: null,
      pendingQuestionSource: null,
      awaitingInput: false,
    });

    const dismissMsg = `[User dismissed the question: "${question}"]`;
    executionApi.chat(state.sessionId, dismissMsg).catch(() => { });
  }, [agentStates, activeWorker, updateAgentState]);

  const handleLoadAgent = useCallback(async (agentPath: string) => {
    const state = agentStates[activeWorker];
    if (!state?.sessionId) return;

    try {
      await sessionsApi.loadGraph(state.sessionId, agentPath);
      // Success: worker_graph_loaded SSE event will handle UI updates automatically
    } catch (err) {
      // 424 = credentials required — open the credentials modal
      if (err instanceof ApiError && err.status === 424) {
        const body = err.body as Record<string, unknown>;
        setCredentialAgentPath((body.agent_path as string) || null);
        setCredentialsOpen(true);
        return;
      }

      const errMsg = err instanceof Error ? err.message : String(err);
      const activeId = activeSessionRef.current[activeWorker];
      const errorMsg: ChatMessage = {
        id: makeId(), agent: "System", agentColor: "",
        content: `Failed to load agent: ${errMsg}`,
        timestamp: "", type: "system", thread: activeWorker, createdAt: Date.now(),
      };
      setSessionsByAgent(prev => ({
        ...prev,
        [activeWorker]: (prev[activeWorker] || []).map(s =>
          s.id === activeId ? { ...s, messages: [...s.messages, errorMsg] } : s
        ),
      }));
    }
  }, [activeWorker, agentStates]);
  void handleLoadAgent; // Used by load-agent modal (wired dynamically)

  const closeAgentTab = useCallback((agentType: string) => {
    setSelectedNode(null);
    // Pause worker execution if running (saves checkpoint), then kill the
    // entire backend session so the queen doesn't keep running.
    const state = agentStates[agentType];
    if (state?.sessionId) {
      const pausePromise = (state.currentExecutionId && state.workerRunState === "running")
        ? executionApi.pause(state.sessionId, state.currentExecutionId)
        : Promise.resolve();

      pausePromise
        .catch(() => { })                          // pause failure shouldn't block kill
        .then(() => sessionsApi.stop(state.sessionId!))
        .catch(() => { });                         // fire-and-forget
    }

    const allTypes = Object.keys(sessionsByAgent).filter(k => (sessionsByAgent[k] || []).length > 0);
    const remaining = allTypes.filter(k => k !== agentType);

    setSessionsByAgent(prev => {
      const next = { ...prev };
      delete next[agentType];
      return next;
    });
    setActiveSessionByAgent(prev => {
      const next = { ...prev };
      delete next[agentType];
      return next;
    });
    // Remove per-agent backend state (SSE connection closes automatically)
    setAgentStates(prev => {
      const next = { ...prev };
      delete next[agentType];
      return next;
    });

    if (remaining.length === 0) {
      navigate("/");
    } else if (activeWorker === agentType) {
      setActiveWorker(remaining[0]);
    }
  }, [sessionsByAgent, activeWorker, navigate, agentStates]);

  // Open a tab for an agent type. If a tab already exists, switch to it
  // instead of creating a duplicate — each agent gets one session.
  // Exception: "new-agent" tabs always create a new instance since each
  // represents a distinct conversation the user is starting from scratch.
  const addAgentSession = useCallback((agentType: string, agentLabel?: string) => {
    const isNewAgent = agentType === "new-agent" || agentType.startsWith("new-agent-");

    if (!isNewAgent) {
      const existingTabKey = Object.keys(sessionsByAgent).find(
        k => baseAgentType(k) === agentType && (sessionsByAgent[k] || []).length > 0,
      );
      if (existingTabKey) {
        setActiveWorker(existingTabKey);
        const existing = sessionsByAgent[existingTabKey]?.[0];
        if (existing) {
          setActiveSessionByAgent(prev => ({ ...prev, [existingTabKey]: existing.id }));
        }
        return;
      }
    }

    const tabKey = isNewAgent ? `new-agent-${makeId()}` : agentType;
    const existingNewAgentCount = isNewAgent
      ? Object.keys(sessionsByAgent).filter(
          k => (k === "new-agent" || k.startsWith("new-agent-")) && (sessionsByAgent[k] || []).length > 0
        ).length
      : 0;
    const rawLabel = agentLabel || (isNewAgent ? "New Agent" : formatAgentDisplayName(agentType));
    const displayLabel = existingNewAgentCount === 0 ? rawLabel : `${rawLabel} #${existingNewAgentCount + 1}`;
    const newSession = createSession(tabKey, displayLabel);

    setSessionsByAgent(prev => ({
      ...prev,
      [tabKey]: [newSession],
    }));
    setActiveSessionByAgent(prev => ({ ...prev, [tabKey]: newSession.id }));
    setActiveWorker(tabKey);
  }, [sessionsByAgent]);

  // Open a history session: switch to its existing tab, or open a new tab.
  // Async so we can pre-fetch messages before creating the tab — this gives
  // instant visual feedback without waiting for loadAgentForType.
  const handleHistoryOpen = useCallback(async (sessionId: string, agentPath?: string | null, agentName?: string | null) => {
    // Already open as a tab — just switch to it.
    for (const [type, sessions] of Object.entries(sessionsByAgent)) {
      for (const s of sessions) {
        if (s.backendSessionId === sessionId || s.historySourceId === sessionId) {
          setActiveWorker(type);
          setActiveSessionByAgent(prev => ({ ...prev, [type]: s.id }));
          if (s.messages.length > 0) {
            suppressIntroRef.current.add(type);
          }
          return;
        }
      }
    }

    // Pre-fetch messages from disk so the tab opens with conversation already shown.
    // Prefer the persisted event log for full UI reconstruction; fall back to parts.
    let prefetchedMessages: ChatMessage[] = [];
    try {
      const resolvedType = agentPath || "new-agent";
      const displayNameTemp = agentName || formatAgentDisplayName(resolvedType);
      const restored = await restoreSessionMessages(sessionId, resolvedType, displayNameTemp);
      prefetchedMessages = restored.messages;
      if (prefetchedMessages.length > 0) {
        prefetchedMessages.sort((a, b) => (a.createdAt ?? 0) - (b.createdAt ?? 0));
      }
    } catch {
      // Not available — session will open empty and loadAgentForType will try again
    }

    const resolvedAgentType = agentPath || "new-agent";
    const existingTabCount = Object.keys(sessionsByAgent).filter(
      k => baseAgentType(k) === resolvedAgentType && (sessionsByAgent[k] || []).length > 0
    ).length;
    const rawLabel = agentName ||
      (agentPath ? agentPath.replace(/\/$/, "").split("/").pop()?.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()) || agentPath : null) ||
      "New Agent";
    const label = existingTabCount === 0 ? rawLabel : `${rawLabel} #${existingTabCount + 1}`;
    const newSession = createSession(resolvedAgentType, label);
    newSession.backendSessionId = sessionId;
    newSession.historySourceId = sessionId;
    // Pre-populate messages so the chat panel immediately shows the conversation
    if (prefetchedMessages.length > 0) {
      newSession.messages = prefetchedMessages;
    }
    const tabKey = existingTabCount === 0 ? resolvedAgentType : `${resolvedAgentType}::${newSession.id}`;
    if (tabKey !== resolvedAgentType) newSession.tabKey = tabKey;

    // Suppress queen intro BEFORE the tab is created so loadAgentForType
    // never sees an unsuppressed window — the user never expects a greeting on reopen.
    if (prefetchedMessages.length > 0 || sessionId) {
      suppressIntroRef.current.add(tabKey);
    }

    setSessionsByAgent(prev => ({ ...prev, [tabKey]: [newSession] }));
    setActiveSessionByAgent(prev => ({ ...prev, [tabKey]: newSession.id }));
    setActiveWorker(tabKey);
  }, [sessionsByAgent]);

  // Post-mount: open the session from the URL ?session= param via handleHistoryOpen.
  // This runs AFTER persisted tabs are hydrated, so dedup works correctly.
  // Use a ref guard so it fires exactly once even in React StrictMode.
  useEffect(() => {
    if (mountedRef.current) return;
    mountedRef.current = true;
    const sid = initialSessionIdRef.current;
    if (!sid) return;
    // Fetch agent metadata from the backend so handleHistoryOpen gets the right
    // agentPath and agentName (needed to label the tab correctly).
    apiHistorySessions().then(r => {
      const match = r.sessions.find((s: { session_id: string }) => s.session_id === sid);
      if (!match) {
        // Enforce project boundary: do not auto-open a session that is not in
        // the active project's history list.
        return;
      }
      handleHistoryOpen(
        sid,
        match.agent_path ?? (initialAgentRef.current !== "new-agent" ? initialAgentRef.current : null),
        match.agent_name ?? null,
      );
    }).catch(() => {
      // History fetch failed — skip auto-open to avoid crossing project boundaries.
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const activeWorkerLabel = activeAgentState?.displayName || formatAgentDisplayName(baseAgentType(activeWorker));
  const readinessSummary = credentialReadiness?.summary;
  const readinessMissingRequiredList = credentialReadiness?.missing.required ?? [];
  const readinessMissingRequiredCount = readinessSummary?.required_missing ?? 0;
  const readinessBadgeTone = credentialReadinessError
    ? "border-destructive/50 bg-destructive/10 text-destructive"
    : readinessSummary?.ready
      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
      : "border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-300";
  const readinessTitle = credentialReadinessError
    ? `Credentials readiness error: ${credentialReadinessError}`
    : readinessSummary
      ? `Required ${readinessSummary.required_available}/${readinessSummary.required_total}, missing: ${readinessMissingRequiredList.join(", ") || "none"}`
      : "Credentials readiness is not loaded yet";
  const readinessRequiredRows = credentialReadiness?.required ?? [];
  const readinessOptionalRows = credentialReadiness?.optional ?? [];
  const readinessProviders = credentialReadiness?.providers ?? [];
  const readinessBundleEnvVars = useMemo(
    () => new Set([...readinessRequiredRows, ...readinessOptionalRows].map((row) => row.env_var)),
    [readinessOptionalRows, readinessRequiredRows],
  );
  const readinessProvidersMissing = useMemo(
    () => readinessProviders.filter((row) => row.credentials_missing > 0),
    [readinessProviders],
  );
  const readinessProvidersBundleScoped = useMemo(
    () =>
      readinessProvidersMissing.filter((row) =>
        row.env_vars.some((envVar) => readinessBundleEnvVars.has(envVar)) ||
        row.missing_env_vars.some((envVar) => readinessBundleEnvVars.has(envVar)),
      ),
    [readinessBundleEnvVars, readinessProvidersMissing],
  );
  const readinessProvidersVisible = useMemo(() => {
    if (credentialReadinessShowAllProviders || readinessProvidersBundleScoped.length === 0) {
      return readinessProvidersMissing;
    }
    return readinessProvidersBundleScoped;
  }, [
    credentialReadinessShowAllProviders,
    readinessProvidersBundleScoped,
    readinessProvidersMissing,
  ]);
  const readinessHiddenProviderCount = Math.max(
    0,
    readinessProvidersMissing.length - readinessProvidersVisible.length,
  );
  const credentialsButtonTone = credentialReadinessError
    ? "text-destructive border-destructive/40 bg-destructive/10"
    : readinessMissingRequiredCount > 0
      ? "text-amber-300 border-amber-500/40 bg-amber-500/10"
      : "text-muted-foreground";

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden">
      <TopBar
        tabs={agentTabs}
        onTabClick={(agentType) => {
          const tab = agentTabs.find(t => t.agentType === agentType);
          if (tab) {
            setActiveWorker(agentType);
            setActiveSessionByAgent(prev => ({ ...prev, [agentType]: tab.sessionId }));
            setSelectedNode(null);
          }
        }}
        onCloseTab={closeAgentTab}
        afterTabs={
          <>
            <button
              ref={newTabBtnRef}
              onClick={() => setNewTabOpen(o => !o)}
              className="flex-shrink-0 p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
              title="Add tab"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
            <NewTabPopover
              open={newTabOpen}
              onClose={() => setNewTabOpen(false)}
              anchorRef={newTabBtnRef}
              discoverAgents={discoverAgents}
              onFromScratch={() => { addAgentSession("new-agent"); }}
              onCloneAgent={(agentPath, agentName) => { addAgentSession(agentPath, agentName); }}
            />
          </>
        }
      >
        <div className="flex items-center gap-1.5">
          <select
            value={activeProjectId}
            onChange={(e) => {
              const next = e.target.value;
              setActiveProjectId(next);
              localStorage.setItem(ACTIVE_PROJECT_STORAGE_KEY, next);
            }}
            className="h-7 max-w-[180px] rounded-md border border-border/60 bg-background px-2 text-[11px] text-foreground"
            title="Active project"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button
            onClick={() => {
              setProjectCreateError(null);
              setProjectModalOpen(true);
            }}
            disabled={projectBusy}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors disabled:opacity-50"
            title="Create project"
          >
            <Plus className="w-3.5 h-3.5" />
            Project
          </button>
          <div className="hidden lg:flex items-center gap-1 ml-1">
            <span className="px-1.5 py-1 rounded border border-border/60 bg-background text-[10px] text-muted-foreground">
              Exec {projectMetrics?.summary.executions_total ?? 0}
            </span>
            <span className="px-1.5 py-1 rounded border border-border/60 bg-background text-[10px] text-muted-foreground">
              SR {formatPct(projectMetrics?.kpis.success_rate)}
            </span>
            <span className="px-1.5 py-1 rounded border border-border/60 bg-background text-[10px] text-muted-foreground">
              P50 {formatSeconds(projectMetrics?.kpis.cycle_time_seconds_p50)}
            </span>
            <span className="px-1.5 py-1 rounded border border-border/60 bg-background text-[10px] text-muted-foreground">
              HITL {formatPct(projectMetrics?.kpis.intervention_ratio ?? 0)}
            </span>
            <button
              onClick={() => {
                setProjectRetentionOpen(true);
                setProjectRetentionRunResult(null);
                refreshProjectRetention().catch(() => {});
              }}
              className={`px-1.5 py-1 rounded border text-[10px] ${
                (projectRetentionData?.plan.eligible_count ?? 0) > 0
                  ? "border-destructive/50 bg-destructive/10 text-destructive"
                  : "border-border/60 bg-background text-muted-foreground"
              }`}
              title="Open retention plan"
            >
              Eligible {projectRetentionData?.plan.eligible_count ?? "--"}
            </button>
            <button
              onClick={() => refreshProjectMetrics().catch(() => {})}
              disabled={projectMetricsLoading}
              className="h-6 w-6 inline-flex items-center justify-center rounded border border-border/60 bg-background text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
              title={projectMetricsError ? `Metrics error: ${projectMetricsError}` : "Refresh project metrics"}
            >
              <RefreshCw className={`w-3 h-3 ${projectMetricsLoading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={() => {
                setProjectMetricsBoardOpen(true);
                refreshProjectMetricsBoard().catch(() => {});
              }}
              className="h-6 px-2 inline-flex items-center justify-center rounded border border-border/60 bg-background text-[10px] text-muted-foreground hover:text-foreground hover:bg-muted/50"
              title="Open cross-project KPI board"
            >
              Board
            </button>
            <button
              onClick={() => {
                setProjectRetentionOpen(true);
                setProjectRetentionRunResult(null);
                refreshProjectRetention().catch(() => {});
              }}
              className="h-6 px-2 inline-flex items-center justify-center rounded border border-border/60 bg-background text-[10px] text-muted-foreground hover:text-foreground hover:bg-muted/50"
              title="Open project retention and archive controls"
            >
              Retention
            </button>
            <button
              onClick={() => {
                setProjectExecutionOpen(true);
                refreshProjectExecutionTemplate().catch(() => {});
              }}
              className="h-6 px-2 inline-flex items-center justify-center rounded border border-border/60 bg-background text-[10px] text-muted-foreground hover:text-foreground hover:bg-muted/50"
              title="Open project execution template and policy binding"
            >
              Flow
            </button>
            <button
              onClick={() => {
                setProjectToolchainOpen(true);
                setProjectToolchainInstructions(null);
                refreshProjectToolchainProfile().catch(() => {});
              }}
              className="h-6 px-2 inline-flex items-center justify-center rounded border border-border/60 bg-background text-[10px] text-muted-foreground hover:text-foreground hover:bg-muted/50"
              title="Plan and approve project toolchain profile"
            >
              Toolchain
            </button>
            <button
              onClick={() => {
                setProjectAutonomousOpen(true);
                refreshProjectAutonomous().catch(() => {});
              }}
              className="h-6 px-2 inline-flex items-center justify-center rounded border border-border/60 bg-background text-[10px] text-muted-foreground hover:text-foreground hover:bg-muted/50"
              title="Open autonomous backlog and pipeline"
            >
              Auto
            </button>
          </div>
        </div>
        <div className="hidden xl:flex items-center gap-1">
          <button
            onClick={() => {
              setCredentialReadinessShowAllProviders(false);
              setCredentialReadinessOpen(true);
            }}
            className={`px-1.5 py-1 rounded border text-[10px] ${readinessBadgeTone}`}
            title={readinessTitle}
          >
            Cred {readinessSummary?.required_available ?? "--"}/{readinessSummary?.required_total ?? "--"}
          </button>
          <button
            onClick={() => refreshCredentialReadiness().catch(() => {})}
            disabled={credentialReadinessLoading}
            className="h-6 w-6 inline-flex items-center justify-center rounded border border-border/60 bg-background text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
            title={credentialReadinessError ? `Readiness error: ${credentialReadinessError}` : "Refresh credentials readiness"}
          >
            <RefreshCw className={`w-3 h-3 ${credentialReadinessLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
        <button
          onClick={() => setCredentialsOpen(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium border border-transparent hover:text-foreground hover:bg-muted/50 transition-colors flex-shrink-0 ${credentialsButtonTone}`}
          title={readinessTitle}
        >
          <KeyRound className="w-3.5 h-3.5" />
          Credentials
          {readinessMissingRequiredCount > 0 && (
            <span className="inline-flex h-4 min-w-4 items-center justify-center rounded-full border border-amber-500/40 bg-amber-500/20 px-1 text-[10px] leading-none text-amber-200">
              {readinessMissingRequiredCount}
            </span>
          )}
        </button>
        {activeAgentState?.sessionId && (
          <>
            <button
              onClick={async () => {
                const sessionId = activeAgentState.sessionId;
                if (!sessionId) return;
                try {
                  const result = await sessionsApi.revealFolder(sessionId);
                  if (result.opened === false) {
                    let copied = false;
                    if (navigator.clipboard?.writeText) {
                      await navigator.clipboard.writeText(result.path).then(() => {
                        copied = true;
                      }).catch(() => {});
                    }
                    const details = result.error ? `\nReason: ${result.error}` : "";
                    const hint = result.hint ? `\nHint: ${result.hint}` : "";
                    const copyLine = copied ? "\nPath copied to clipboard." : "";
                    window.alert(`Could not open folder automatically.\nPath: ${result.path}${details}${hint}${copyLine}`);
                  }
                } catch (e) {
                  const msg = e instanceof Error ? e.message : String(e);
                  window.alert(`Failed to open session folder: ${msg}`);
                }
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors flex-shrink-0"
              title="Open session data folder"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              Data
            </button>
            <button
              onClick={async () => {
                const sessionId = activeAgentState.sessionId;
                if (!sessionId) return;
                try {
                  const { blob, filename } = await sessionsApi.exportArchive(sessionId);
                  const url = URL.createObjectURL(blob);
                  const anchor = document.createElement("a");
                  anchor.href = url;
                  anchor.download = filename;
                  document.body.appendChild(anchor);
                  anchor.click();
                  anchor.remove();
                  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
                } catch (e) {
                  const msg = e instanceof Error ? e.message : String(e);
                  window.alert(`Failed to export session folder: ${msg}`);
                }
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors flex-shrink-0"
              title="Download session data archive (.zip)"
            >
              <Download className="w-3.5 h-3.5" />
              Export
            </button>
          </>
        )}
      </TopBar>

      {credentialReadinessOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-2xl rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Credential Readiness</h3>
              <button
                onClick={() => setCredentialReadinessOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-4">
              <div className={`rounded-md border px-3 py-2 text-xs ${readinessBadgeTone}`}>
                <div className="font-medium">
                  Required: {readinessSummary?.required_available ?? "--"}/{readinessSummary?.required_total ?? "--"}
                  {readinessMissingRequiredCount > 0 ? ` (missing ${readinessMissingRequiredCount})` : " (ready)"}
                </div>
                <div className="mt-1 opacity-90">
                  Optional: {readinessSummary?.optional_available ?? "--"}/{readinessSummary?.optional_total ?? "--"}
                </div>
              </div>
              {credentialReadinessError ? (
                <div className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive">
                  {credentialReadinessError}
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                  <div className="rounded-md border border-border/60 bg-background/40 p-3">
                    <div className="text-xs font-semibold text-foreground mb-2">Required</div>
                    <div className="space-y-1 max-h-44 overflow-y-auto">
                      {readinessRequiredRows.map((row) => (
                        <div key={`required-${row.env_var}`} className="flex items-center justify-between text-[11px]">
                          <span className="text-muted-foreground">{row.env_var}</span>
                          <span className={row.available ? "text-emerald-400" : "text-amber-300"}>
                            {row.available ? "ok" : "missing"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-md border border-border/60 bg-background/40 p-3">
                    <div className="text-xs font-semibold text-foreground mb-2">Optional</div>
                    <div className="space-y-1 max-h-44 overflow-y-auto">
                      {readinessOptionalRows.map((row) => (
                        <div key={`optional-${row.env_var}`} className="flex items-center justify-between text-[11px]">
                          <span className="text-muted-foreground">{row.env_var}</span>
                          <span className={row.available ? "text-emerald-400" : "text-muted-foreground/70"}>
                            {row.available ? "ok" : "not set"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {!credentialReadinessError && (
                <div className="rounded-md border border-border/60 bg-background/40 p-3">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="text-xs font-semibold text-foreground">
                      Provider Gaps ({readinessProvidersVisible.length})
                    </div>
                    {readinessProvidersMissing.length > readinessProvidersBundleScoped.length && (
                      <button
                        onClick={() =>
                          setCredentialReadinessShowAllProviders((prev) => !prev)
                        }
                        className="text-[10px] px-2 py-1 rounded border border-border/60 bg-background text-muted-foreground hover:text-foreground hover:bg-muted/50"
                        title="Toggle between bundle-scoped and all provider gaps"
                      >
                        {credentialReadinessShowAllProviders
                          ? "Show bundle-only"
                          : `Show all (+${readinessHiddenProviderCount})`}
                      </button>
                    )}
                  </div>
                  {readinessProvidersVisible.length === 0 ? (
                    <div className="text-[11px] text-muted-foreground">
                      No provider gaps for this bundle.
                    </div>
                  ) : (
                    <div className="space-y-1 max-h-40 overflow-y-auto">
                      {readinessProvidersVisible.map((row) => (
                        <div key={row.provider} className="text-[11px] text-muted-foreground">
                          {row.provider}: {row.credentials_available}/{row.credentials_total}
                          {`, missing ${row.missing_env_vars.join(", ")}`}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-border/50">
              <button
                onClick={() => refreshCredentialReadiness().catch(() => {})}
                disabled={credentialReadinessLoading}
                className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
              >
                {credentialReadinessLoading ? "Refreshing..." : "Refresh"}
              </button>
              <button
                onClick={() => {
                  setCredentialReadinessOpen(false);
                  setCredentialsOpen(true);
                }}
                className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90"
              >
                Open Credentials
              </button>
            </div>
          </div>
        </div>
      )}

      {projectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-md rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Create Project</h3>
              <button
                onClick={() => setProjectModalOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-[11px] text-muted-foreground mb-1">Name</label>
                <input
                  autoFocus
                  value={projectNameDraft}
                  onChange={(e) => setProjectNameDraft(e.target.value)}
                  className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                  placeholder="Payments Platform"
                />
              </div>
              <div>
                <label className="block text-[11px] text-muted-foreground mb-1">Repository (optional)</label>
                <input
                  value={projectRepositoryDraft}
                  onChange={(e) => setProjectRepositoryDraft(e.target.value)}
                  className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                  placeholder="github.com/org/repo"
                />
              </div>
              <div>
                <label className="block text-[11px] text-muted-foreground mb-1">Description (optional)</label>
                <textarea
                  value={projectDescriptionDraft}
                  onChange={(e) => setProjectDescriptionDraft(e.target.value)}
                  className="w-full min-h-[72px] rounded-md border border-border/60 bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40 resize-y"
                  placeholder="Core backend services and APIs"
                />
              </div>
              <div className="rounded-md border border-border/60 bg-background/50 p-3 space-y-2">
                <label className="flex items-center gap-2 text-[11px] text-foreground">
                  <input
                    type="checkbox"
                    checked={projectOnboardEnabled}
                    onChange={(e) => setProjectOnboardEnabled(e.target.checked)}
                    className="h-3.5 w-3.5 rounded border-border/70 bg-background"
                  />
                  Run project onboarding after create
                </label>
                {projectOnboardEnabled && (
                  <>
                    <div>
                      <label className="block text-[11px] text-muted-foreground mb-1">Template profile</label>
                      <select
                        value={projectTemplateIdDraft}
                        onChange={(e) => {
                          const nextId = e.target.value;
                          setProjectTemplateIdDraft(nextId);
                          const nextTemplate = projectTemplates.find((t) => t.id === nextId);
                          if (nextTemplate) {
                            setProjectStackDraft(nextTemplate.stack);
                          }
                        }}
                        className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                      >
                        {projectTemplates.length === 0 ? (
                          <option value={projectTemplateIdDraft}>custom</option>
                        ) : (
                          projectTemplates.map((tpl) => (
                            <option key={tpl.id} value={tpl.id}>
                              {tpl.name}
                            </option>
                          ))
                        )}
                      </select>
                      {selectedProjectTemplate && (
                        <div className="mt-1 text-[10px] text-muted-foreground">
                          {selectedProjectTemplate.description}
                        </div>
                      )}
                    </div>
                    <div>
                      <label className="block text-[11px] text-muted-foreground mb-1">Workspace path</label>
                      <input
                        value={projectWorkspacePathDraft}
                        onChange={(e) => setProjectWorkspacePathDraft(e.target.value)}
                        className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                        placeholder="/absolute/path/to/repository"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-muted-foreground mb-1">Stack</label>
                      <select
                        value={projectStackDraft}
                        onChange={(e) => setProjectStackDraft(e.target.value as "node" | "python" | "go" | "jvm" | "rust" | "fullstack")}
                        className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                      >
                        <option value="node">node</option>
                        <option value="python">python</option>
                        <option value="go">go</option>
                        <option value="jvm">jvm</option>
                        <option value="rust">rust</option>
                        <option value="fullstack">fullstack</option>
                      </select>
                    </div>
                  </>
                )}
              </div>
              {projectCreateError && (
                <div className="text-xs text-destructive">{projectCreateError}</div>
              )}
            </div>
            <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-border/50">
              <button
                onClick={() => setProjectModalOpen(false)}
                className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50"
              >
                Cancel
              </button>
              <button
                onClick={() => { createProjectFromForm().catch((e) => setProjectCreateError(String(e))); }}
                disabled={projectBusy}
                className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
              >
                {projectBusy ? "Creating..." : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}

      {projectMetricsBoardOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-5xl rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Project KPI Board</h3>
              <button
                onClick={() => setProjectMetricsBoardOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="px-4 py-3 border-b border-border/50 flex items-center gap-2">
              <label className="text-[11px] text-muted-foreground">Sort by</label>
              <select
                value={projectMetricsSortBy}
                onChange={(e) => setProjectMetricsSortBy(e.target.value as "success_rate" | "executions_total" | "cycle_time_p50" | "intervention_ratio")}
                className="h-7 rounded-md border border-border/60 bg-background px-2 text-[11px] text-foreground"
              >
                <option value="success_rate">Success rate (desc)</option>
                <option value="executions_total">Executions (desc)</option>
                <option value="cycle_time_p50">P50 cycle (asc)</option>
                <option value="intervention_ratio">Intervention ratio (desc)</option>
              </select>
              <button
                onClick={() => refreshProjectMetricsBoard().catch(() => {})}
                disabled={projectMetricsBoardLoading}
                className="h-7 px-2 inline-flex items-center gap-1 rounded border border-border/60 bg-background text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${projectMetricsBoardLoading ? "animate-spin" : ""}`} />
                Refresh
              </button>
              {projectMetricsBoardError && (
                <span className="text-[11px] text-destructive">{projectMetricsBoardError}</span>
              )}
            </div>
            <div className="max-h-[60vh] overflow-auto">
              <table className="w-full text-[11px]">
                <thead className="sticky top-0 bg-card border-b border-border/50">
                  <tr className="text-left text-muted-foreground">
                    <th className="px-3 py-2 font-medium">Project</th>
                    <th className="px-3 py-2 font-medium">Repo</th>
                    <th className="px-3 py-2 font-medium">Exec</th>
                    <th className="px-3 py-2 font-medium">Success</th>
                    <th className="px-3 py-2 font-medium">P50 Cycle</th>
                    <th className="px-3 py-2 font-medium">HITL</th>
                    <th className="px-3 py-2 font-medium">Sessions</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedProjectMetricsRows.map((row) => (
                    <tr key={row.project.id} className="border-b border-border/30 hover:bg-muted/20">
                      <td className="px-3 py-2 text-foreground font-medium">{row.project.name}</td>
                      <td className="px-3 py-2 text-muted-foreground">{row.project.repository || "--"}</td>
                      <td className="px-3 py-2 text-foreground">{row.summary.executions_total}</td>
                      <td className="px-3 py-2 text-foreground">{formatPct(row.kpis.success_rate)}</td>
                      <td className="px-3 py-2 text-foreground">{formatSeconds(row.kpis.cycle_time_seconds_p50)}</td>
                      <td className="px-3 py-2 text-foreground">{formatPct(row.kpis.intervention_ratio)}</td>
                      <td className="px-3 py-2 text-muted-foreground">
                        {row.summary.active_sessions}/{row.summary.historical_sessions}
                      </td>
                    </tr>
                  ))}
                  {sortedProjectMetricsRows.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">
                        No project metrics yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {projectRetentionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-3xl rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Project Retention</h3>
              <button
                onClick={() => setProjectRetentionOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">History Days</label>
                  <input
                    value={projectRetentionHistoryDaysDraft}
                    onChange={(e) => setProjectRetentionHistoryDaysDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="30"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Min Sessions Keep</label>
                  <input
                    value={projectRetentionMinKeepDraft}
                    onChange={(e) => setProjectRetentionMinKeepDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="20"
                  />
                </div>
                <div className="flex items-end">
                  <label className="flex items-center gap-2 text-xs text-foreground h-9">
                    <input
                      type="checkbox"
                      checked={projectRetentionArchiveEnabledDraft}
                      onChange={(e) => setProjectRetentionArchiveEnabledDraft(e.target.checked)}
                      className="h-3.5 w-3.5 rounded border-border/70 bg-background"
                    />
                    Archive enabled
                  </label>
                </div>
              </div>
              <div>
                <label className="block text-[11px] text-muted-foreground mb-1">Archive Root</label>
                <input
                  value={projectRetentionArchiveRootDraft}
                  onChange={(e) => setProjectRetentionArchiveRootDraft(e.target.value)}
                  className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                  placeholder="~/.hive/queen/archive"
                />
              </div>
              <div className="rounded-md border border-border/60 bg-background/40 p-3 text-xs text-muted-foreground">
                <div>Historical sessions: {projectRetentionData?.plan.historical_sessions ?? "--"}</div>
                <div>Eligible now: {projectRetentionData?.plan.eligible_count ?? "--"}</div>
                <div>Candidates shown: {Math.min(projectRetentionData?.plan.candidates.length ?? 0, 10)}</div>
              </div>
              {projectRetentionData?.plan.candidates && projectRetentionData.plan.candidates.length > 0 && (
                <div className="rounded-md border border-border/60 bg-background/20 p-2 max-h-36 overflow-auto">
                  {projectRetentionData.plan.candidates.slice(0, 10).map((c) => (
                    <div key={c.session_id} className="text-[11px] text-muted-foreground py-0.5">
                      {c.session_id} ({Math.round(c.age_days)}d)
                    </div>
                  ))}
                </div>
              )}
              {projectRetentionRunResult && (
                <div className="rounded-md border border-border/60 bg-background/40 p-3 text-[11px] text-muted-foreground">
                  <pre className="whitespace-pre-wrap break-words">
                    {JSON.stringify(projectRetentionRunResult, null, 2)}
                  </pre>
                </div>
              )}
              {projectRetentionError && (
                <div className="text-xs text-destructive">{projectRetentionError}</div>
              )}
            </div>
            <div className="flex items-center justify-between px-4 py-3 border-t border-border/50">
              <button
                onClick={() => refreshProjectRetention().catch(() => {})}
                disabled={projectRetentionLoading}
                className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
              >
                {projectRetentionLoading ? "Refreshing..." : "Refresh"}
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => saveProjectRetentionPolicy().catch(() => {})}
                  disabled={projectRetentionSaving || projectRetentionApplying}
                  className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                >
                  {projectRetentionSaving ? "Saving..." : "Save Policy"}
                </button>
                <button
                  onClick={() => runProjectRetention(true).catch(() => {})}
                  disabled={projectRetentionSaving || projectRetentionApplying}
                  className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                >
                  Dry Run
                </button>
                <button
                  onClick={() => runProjectRetention(false).catch(() => {})}
                  disabled={projectRetentionSaving || projectRetentionApplying}
                  className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
                >
                  {projectRetentionApplying ? "Applying..." : "Apply"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {projectExecutionOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-3xl rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Project Execution Template</h3>
              <button
                onClick={() => setProjectExecutionOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Design Profile</label>
                  <input
                    value={projectExecutionDesignProfileDraft}
                    onChange={(e) => setProjectExecutionDesignProfileDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="strategy_heavy"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Implement Profile</label>
                  <input
                    value={projectExecutionImplementProfileDraft}
                    onChange={(e) => setProjectExecutionImplementProfileDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="implementation"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Review Profile</label>
                  <input
                    value={projectExecutionReviewProfileDraft}
                    onChange={(e) => setProjectExecutionReviewProfileDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="review_validation"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Validate Profile</label>
                  <input
                    value={projectExecutionValidateProfileDraft}
                    onChange={(e) => setProjectExecutionValidateProfileDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="review_validation"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Max Retries Per Stage</label>
                  <input
                    value={projectExecutionRetryDraft}
                    onChange={(e) => setProjectExecutionRetryDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="1"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Escalate On (comma)</label>
                  <input
                    value={projectExecutionEscalateOnDraft}
                    onChange={(e) => setProjectExecutionEscalateOnDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="review,validate"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">GitHub Default Ref</label>
                  <input
                    value={projectExecutionGithubDefaultRefDraft}
                    onChange={(e) => setProjectExecutionGithubDefaultRefDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="main"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">GitHub No-Checks Policy</label>
                  <select
                    value={projectExecutionNoChecksPolicyDraft}
                    onChange={(e) => setProjectExecutionNoChecksPolicyDraft(e.target.value as ProjectNoChecksPolicy)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                  >
                    <option value="error">error (strict)</option>
                    <option value="manual_pending">manual_pending</option>
                    <option value="success">success (allow)</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Policy Risk Tier</label>
                  <select
                    value={projectExecutionRiskTierDraft}
                    onChange={(e) => setProjectExecutionRiskTierDraft(e.target.value as "low" | "medium" | "high" | "critical")}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                  >
                    <option value="low">low</option>
                    <option value="medium">medium</option>
                    <option value="high">high</option>
                    <option value="critical">critical</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Policy Retry Limit</label>
                  <input
                    value={projectExecutionPolicyRetryDraft}
                    onChange={(e) => setProjectExecutionPolicyRetryDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="2"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Policy Monthly Budget (USD)</label>
                  <input
                    value={projectExecutionBudgetDraft}
                    onChange={(e) => setProjectExecutionBudgetDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="optional"
                  />
                </div>
              </div>
              <div className="rounded-md border border-border/60 bg-background/40 p-3 text-xs text-muted-foreground">
                <div>Effective risk tier: {projectExecutionData?.effective.policy.risk_tier ?? "--"}</div>
                <div>Effective retry limit: {projectExecutionData?.effective.policy.retry_limit_per_stage ?? "--"}</div>
                <div>
                  Effective GitHub ref: {projectExecutionData?.effective.execution_template.github?.default_ref
                    || projectExecutionData?.effective.execution_template.github?.default_branch
                    || projectExecutionData?.effective.execution_template.default_ref
                    || projectExecutionData?.effective.execution_template.default_branch
                    || "--"}
                </div>
                <div>
                  Effective no-checks policy: {projectExecutionData?.effective.execution_template.github?.no_checks_policy
                    || projectExecutionData?.effective.execution_template.no_checks_policy
                    || "--"}
                </div>
                <div>
                  Effective stages: {(projectExecutionData?.effective.execution_template.default_flow || []).map((s) => s.stage).join(" -> ") || "--"}
                </div>
              </div>
              {projectExecutionError && (
                <div className="text-xs text-destructive">{projectExecutionError}</div>
              )}
            </div>
            <div className="flex items-center justify-between px-4 py-3 border-t border-border/50">
              <button
                onClick={() => refreshProjectExecutionTemplate().catch(() => {})}
                disabled={projectExecutionLoading}
                className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
              >
                {projectExecutionLoading ? "Refreshing..." : "Refresh"}
              </button>
              <button
                onClick={() => saveProjectExecutionTemplate().catch(() => {})}
                disabled={projectExecutionSaving}
                className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
              >
                {projectExecutionSaving ? "Saving..." : "Save Template"}
              </button>
            </div>
          </div>
        </div>
      )}

      {projectToolchainOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-3xl rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Project Toolchain Profile</h3>
              <button
                onClick={() => setProjectToolchainOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Workspace Path (optional)</label>
                  <input
                    value={projectToolchainWorkspaceDraft}
                    onChange={(e) => setProjectToolchainWorkspaceDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="/workspace/repo"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-muted-foreground mb-1">Repository URL (optional)</label>
                  <input
                    value={projectToolchainRepositoryDraft}
                    onChange={(e) => setProjectToolchainRepositoryDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                    placeholder="https://github.com/owner/repo"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] text-muted-foreground mb-1">Confirm Token</label>
                <input
                  value={projectToolchainConfirmDraft}
                  onChange={(e) => setProjectToolchainConfirmDraft(e.target.value)}
                  className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40"
                  placeholder="APPLY_NODE_XXXXXXXX"
                />
              </div>
              <div className="rounded-md border border-border/60 bg-background/40 p-3 text-xs text-muted-foreground space-y-1">
                <div>
                  Pending fingerprint:{" "}
                  {projectToolchainData?.toolchain_profile?.pending_plan?.plan?.plan_fingerprint || "--"}
                </div>
                <div>
                  Pending stack:{" "}
                  {projectToolchainData?.toolchain_profile?.pending_plan?.plan?.recommended_stack || "--"}
                </div>
                <div>
                  Pending toolchains:{" "}
                  {(projectToolchainData?.toolchain_profile?.pending_plan?.plan?.toolchains || []).join(", ") || "--"}
                </div>
                {projectToolchainInstructions?.env_exports && projectToolchainInstructions.env_exports.length > 0 && (
                  <div>
                    env exports: {projectToolchainInstructions.env_exports.join(" ; ")}
                  </div>
                )}
                {projectToolchainInstructions?.preview_command && (
                  <div>preview: {projectToolchainInstructions.preview_command}</div>
                )}
                {projectToolchainInstructions?.apply_command && (
                  <div>apply: {projectToolchainInstructions.apply_command}</div>
                )}
              </div>
              {projectToolchainError && (
                <div className="text-xs text-destructive">{projectToolchainError}</div>
              )}
            </div>
            <div className="flex items-center justify-between px-4 py-3 border-t border-border/50">
              <button
                onClick={() => refreshProjectToolchainProfile().catch(() => {})}
                disabled={projectToolchainLoading}
                className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
              >
                {projectToolchainLoading ? "Refreshing..." : "Refresh"}
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => planProjectToolchainProfile().catch(() => {})}
                  disabled={projectToolchainPlanning || projectToolchainApproving}
                  className="px-3 py-1.5 rounded-md text-xs font-medium bg-muted text-foreground hover:bg-muted/80 disabled:opacity-50"
                >
                  {projectToolchainPlanning ? "Planning..." : "Plan"}
                </button>
                <button
                  onClick={() => approveProjectToolchainProfile().catch(() => {})}
                  disabled={projectToolchainPlanning || projectToolchainApproving}
                  className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
                >
                  {projectToolchainApproving ? "Approving..." : "Approve"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {projectAutonomousOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4">
          <div className="w-full max-w-6xl rounded-xl border border-border/60 bg-card shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/50">
              <h3 className="text-sm font-semibold text-foreground">Autonomous Pipeline Control</h3>
              <button
                onClick={() => setProjectAutonomousOpen(false)}
                className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 grid grid-cols-1 lg:grid-cols-2 gap-4 max-h-[70vh] overflow-auto">
              <div className="space-y-3">
                <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider">Backlog</h4>
                <div className="rounded-md border border-border/60 bg-background/30 p-3">
                  <label className="block text-[11px] text-muted-foreground mb-1">Execution Session (optional)</label>
                  <select
                    value={projectAutonomousRunSessionIdDraft}
                    onChange={(e) => setProjectAutonomousRunSessionIdDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                  >
                    <option value="">No live session (state-only run)</option>
                    {projectAutonomousLiveSessions.map((s) => (
                      <option key={s.session_id} value={s.session_id}>
                        {s.session_id} ({s.graph_id || "graph-?"})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="rounded-md border border-border/60 bg-background/30 p-3 space-y-2">
                  <input
                    value={projectAutonomousTaskTitleDraft}
                    onChange={(e) => setProjectAutonomousTaskTitleDraft(e.target.value)}
                    className="w-full h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                    placeholder="Task title"
                  />
                  <textarea
                    value={projectAutonomousTaskGoalDraft}
                    onChange={(e) => setProjectAutonomousTaskGoalDraft(e.target.value)}
                    className="w-full min-h-[72px] rounded-md border border-border/60 bg-background px-3 py-2 text-sm text-foreground resize-y"
                    placeholder="Goal / expected outcome"
                  />
                  <textarea
                    value={projectAutonomousTaskCriteriaDraft}
                    onChange={(e) => setProjectAutonomousTaskCriteriaDraft(e.target.value)}
                    className="w-full min-h-[72px] rounded-md border border-border/60 bg-background px-3 py-2 text-sm text-foreground resize-y"
                    placeholder={"Acceptance criteria (one per line)\n- tests pass\n- no regressions"}
                  />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <select
                      value={projectAutonomousTaskPriorityDraft}
                      onChange={(e) => setProjectAutonomousTaskPriorityDraft(e.target.value as "low" | "medium" | "high" | "critical")}
                      className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                    >
                      <option value="low">low</option>
                      <option value="medium">medium</option>
                      <option value="high">high</option>
                      <option value="critical">critical</option>
                    </select>
                    <input
                      value={projectAutonomousTaskRepositoryDraft}
                      onChange={(e) => setProjectAutonomousTaskRepositoryDraft(e.target.value)}
                      className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                      placeholder="repo (optional)"
                    />
                    <input
                      value={projectAutonomousTaskBranchDraft}
                      onChange={(e) => setProjectAutonomousTaskBranchDraft(e.target.value)}
                      className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                      placeholder="branch (optional)"
                    />
                  </div>
                  <button
                    onClick={() => createProjectAutonomousTask().catch(() => {})}
                    disabled={projectAutonomousCreating}
                    className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
                  >
                    {projectAutonomousCreating ? "Creating..." : "Add Task"}
                  </button>
                  <button
                    onClick={() => dispatchNextProjectAutonomousRun().catch(() => {})}
                    disabled={projectAutonomousActionBusy}
                    className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    title="Pick highest-priority todo task and start run"
                  >
                    Dispatch Next Todo
                  </button>
                  <button
                    onClick={() => tickProjectAutonomousLoop().catch(() => {})}
                    disabled={projectAutonomousActionBusy}
                    className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    title="Run one autonomous loop tick: dispatch or advance depending on current state"
                  >
                    Loop Tick
                  </button>
                  <button
                    onClick={() => runCycleProjectAutonomous().catch(() => {})}
                    disabled={projectAutonomousActionBusy}
                    className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    title="Run multi-step autonomous cycle for this project"
                  >
                    Run Cycle
                  </button>
                  <button
                    onClick={() => executeNextProjectAutonomousRun().catch(() => {})}
                    disabled={projectAutonomousActionBusy}
                    className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    title="Pick next backlog task and execute it server-side until terminal/wait"
                  >
                    Execute Next
                  </button>
                </div>
                <div className="rounded-md border border-border/60 bg-background/20 max-h-[36vh] overflow-auto">
                  {projectAutonomousBacklog.length === 0 ? (
                    <div className="p-3 text-xs text-muted-foreground">No backlog tasks yet.</div>
                  ) : (
                    projectAutonomousBacklog.map((task) => (
                      <div key={task.id} className="p-3 border-b border-border/40 last:border-b-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="text-sm text-foreground font-medium">{task.title}</div>
                            <div className="text-[11px] text-muted-foreground mt-0.5">
                              {task.priority} · {task.status} · {task.id}
                            </div>
                          </div>
                          <button
                            onClick={() => startProjectAutonomousRun(task.id).catch(() => {})}
                            disabled={projectAutonomousActionBusy}
                            className="px-2 py-1 rounded border border-border/60 text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                            title="Start autonomous pipeline run for this task"
                          >
                            Run
                          </button>
                        </div>
                        <div className="text-[11px] text-muted-foreground mt-1 line-clamp-3">{task.goal}</div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider">Runs</h4>
                <div className="rounded-md border border-border/60 bg-background/20 max-h-[40vh] overflow-auto">
                  {projectAutonomousRuns.length === 0 ? (
                    <div className="p-3 text-xs text-muted-foreground">No pipeline runs yet.</div>
                  ) : (
                    projectAutonomousRuns.map((run) => (
                      <button
                        key={run.id}
                        onClick={() => setProjectAutonomousSelectedRunId(run.id)}
                        className={`w-full text-left p-3 border-b border-border/40 last:border-b-0 hover:bg-muted/20 ${
                          projectAutonomousSelectedRunId === run.id ? "bg-muted/30" : ""
                        }`}
                      >
                        <div className="text-sm text-foreground font-medium">{run.id}</div>
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          task={run.task_id} · {run.status} · stage={run.current_stage}
                        </div>
                      </button>
                    ))
                  )}
                </div>
                {selectedAutonomousRun && (
                  <div className="rounded-md border border-border/60 bg-background/30 p-3 space-y-2">
                    <div className="text-xs text-muted-foreground">
                      Current stage: <span className="text-foreground">{selectedAutonomousRun.current_stage}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Stage states: {Object.entries(selectedAutonomousRun.stage_states).map(([k, v]) => `${k}:${v}`).join(" | ")}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Attempts: {Object.entries(selectedAutonomousRun.attempts).map(([k, v]) => `${k}:${v}`).join(" | ")}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      <select
                        value={projectAutonomousAdvanceResultDraft}
                        onChange={(e) => setProjectAutonomousAdvanceResultDraft(e.target.value as "success" | "failed")}
                        className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                      >
                        <option value="success">success</option>
                        <option value="failed">failed</option>
                      </select>
                      <input
                        value={projectAutonomousAdvanceNotesDraft}
                        onChange={(e) => setProjectAutonomousAdvanceNotesDraft(e.target.value)}
                        className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground md:col-span-2"
                        placeholder="Stage notes (optional)"
                      />
                    </div>
                    <textarea
                      value={projectAutonomousChecksDraft}
                      onChange={(e) => setProjectAutonomousChecksDraft(e.target.value)}
                      className="w-full min-h-[72px] rounded-md border border-border/60 bg-background px-3 py-2 text-sm text-foreground resize-y"
                      placeholder={"Checks (one per line):\nreview_tests:pass\nlint:fail"}
                    />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <input
                        value={projectAutonomousGitHubRepoDraft}
                        onChange={(e) => setProjectAutonomousGitHubRepoDraft(e.target.value)}
                        className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                        placeholder="GitHub repo: owner/name"
                      />
                      <input
                        value={projectAutonomousGitHubRefDraft}
                        onChange={(e) => setProjectAutonomousGitHubRefDraft(e.target.value)}
                        className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                        placeholder="Ref: branch or SHA"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <input
                        value={projectAutonomousGitHubPrUrlDraft}
                        onChange={(e) => setProjectAutonomousGitHubPrUrlDraft(e.target.value)}
                        className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                        placeholder="PR URL (optional fallback for ref)"
                      />
                      <input
                        value={projectAutonomousGitHubRequiredChecksDraft}
                        onChange={(e) => setProjectAutonomousGitHubRequiredChecksDraft(e.target.value)}
                        className="h-9 rounded-md border border-border/60 bg-background px-3 text-sm text-foreground"
                        placeholder="Required checks (comma)"
                      />
                    </div>
                    <button
                      onClick={() => advanceProjectAutonomousRun().catch(() => {})}
                      disabled={projectAutonomousActionBusy}
                      className="px-3 py-1.5 rounded-md text-xs font-medium bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
                    >
                      Advance Current Stage
                    </button>
                    <button
                      onClick={() => evaluateProjectAutonomousRun().catch(() => {})}
                      disabled={projectAutonomousActionBusy}
                      className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    >
                      Evaluate By Checks
                    </button>
                    <button
                      onClick={() => evaluateProjectAutonomousRunFromGitHub().catch(() => {})}
                      disabled={projectAutonomousActionBusy}
                      className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    >
                      Evaluate via GitHub
                    </button>
                    <button
                      onClick={() => autoNextProjectAutonomousRun().catch(() => {})}
                      disabled={projectAutonomousActionBusy}
                      className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    >
                      Auto Next
                    </button>
                    <button
                      onClick={() => runUntilTerminalProjectAutonomousRun().catch(() => {})}
                      disabled={projectAutonomousActionBusy}
                      className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                    >
                      Run Until Terminal
                    </button>
                    {(projectAutonomousCycleSummary || projectAutonomousCycleResult) && (
                      <div className="rounded-md border border-border/50 bg-background/30 p-2 text-[11px] text-muted-foreground space-y-1">
                        <div className="text-foreground">Run Cycle Summary</div>
                        {projectAutonomousCycleSummary && (
                          <div>
                            projects={String(projectAutonomousCycleSummary.projects_total ?? "--")} · ok={String(projectAutonomousCycleSummary.ok ?? "--")} · failed={String(projectAutonomousCycleSummary.failed ?? "--")} · max_steps={String(projectAutonomousCycleSummary.max_steps_per_project ?? "--")}
                          </div>
                        )}
                        {projectAutonomousCycleOutcomes.length > 0 && (
                          <div>
                            outcomes: {projectAutonomousCycleOutcomes.map(([k, v]) => `${k}:${v}`).join(" | ")}
                          </div>
                        )}
                        {projectAutonomousCycleResult && (
                          <div>
                            last: outcome={String(projectAutonomousCycleResult.outcome ?? "--")} · terminal={String(projectAutonomousCycleResult.terminal ?? false)} · terminal_status={String(projectAutonomousCycleResult.terminal_status ?? "--")} · pr_ready={String(projectAutonomousCycleResult.pr_ready ?? false)} · steps={String(projectAutonomousCycleResult.steps_executed ?? "--")}
                          </div>
                        )}
                      </div>
                    )}
                    {projectAutonomousLastExecutionSnapshot && (
                      <div className="rounded-md border border-border/50 bg-background/30 p-2 text-[11px] text-muted-foreground space-y-1">
                        <div className="text-foreground">Execution Snapshot</div>
                        <div>
                          source={String(projectAutonomousLastExecutionSnapshot.source ?? "--")} · action={String(projectAutonomousLastExecutionSnapshot.action ?? "--")}
                        </div>
                        <div>
                          terminal={String(projectAutonomousLastExecutionSnapshot.terminal ?? false)} · terminal_status={String(projectAutonomousLastExecutionSnapshot.terminal_status ?? "--")} · steps={String(projectAutonomousLastExecutionSnapshot.steps_executed ?? "--")}
                        </div>
                        <div>
                          run_id={String(projectAutonomousLastExecutionSnapshot.run_id ?? "--")} · updated_at={new Date(Number(projectAutonomousLastExecutionSnapshot.updated_at || 0)).toLocaleTimeString()}
                        </div>
                        {projectAutonomousLastExecutionSnapshot.last_error ? (
                          <div className="text-destructive">last_error={String(projectAutonomousLastExecutionSnapshot.last_error)}</div>
                        ) : null}
                      </div>
                    )}
                    {projectAutonomousOpsStatus && (
                      <div className="rounded-md border border-border/50 bg-background/30 p-2 text-[11px] text-muted-foreground space-y-1">
                        <div className="text-foreground">Ops / Loop Health</div>
                        <div>
                          runs={String(projectAutonomousOpsStatus.summary.runs_total ?? 0)} · in_progress={String(projectAutonomousOpsStatus.summary.runs_by_status?.in_progress ?? 0)} · queued={String(projectAutonomousOpsStatus.summary.runs_by_status?.queued ?? 0)}
                        </div>
                        <div>
                          stuck_runs={String(projectAutonomousOpsStatus.alerts.stuck_runs_total ?? 0)} · no_progress_projects={String(projectAutonomousOpsStatus.alerts.no_progress_projects_total ?? 0)}
                        </div>
                        <div>
                          loop_stale=
                          <span className={projectAutonomousOpsStatus.alerts.loop_stale ? "text-amber-400" : "text-emerald-400"}>
                            {String(Boolean(projectAutonomousOpsStatus.alerts.loop_stale))}
                          </span>
                          {" · "}
                          stale_s={String(Math.round(Number(projectAutonomousOpsStatus.alerts.loop_stale_seconds ?? 0)))}
                        </div>
                        <div>
                          active_runs_visible={String(Array.isArray(projectAutonomousOpsStatus.active_runs) ? projectAutonomousOpsStatus.active_runs.length : 0)}
                        </div>
                        <div>
                          docker_lane=
                          <span
                            className={
                              projectAutonomousOpsStatus.runtime?.docker_lane?.ready
                                ? "text-emerald-400"
                                : projectAutonomousOpsStatus.runtime?.docker_lane?.enabled
                                  ? "text-amber-300"
                                  : "text-muted-foreground"
                            }
                          >
                            {String(projectAutonomousOpsStatus.runtime?.docker_lane?.status ?? "disabled")}
                          </span>
                          {" · "}
                          enabled={String(Boolean(projectAutonomousOpsStatus.runtime?.docker_lane?.enabled))}
                          {" · "}
                          ready={String(Boolean(projectAutonomousOpsStatus.runtime?.docker_lane?.ready))}
                        </div>
                        {projectAutonomousOpsStatus.runtime?.docker_lane?.reason && (
                          <div>
                            docker_lane_reason={String(projectAutonomousOpsStatus.runtime?.docker_lane?.reason)}
                          </div>
                        )}
                      </div>
                    )}
                    <div className="rounded-md border border-border/50 bg-background/30 p-2 text-[11px] text-muted-foreground space-y-2">
                      <div className="text-foreground">Stale Remediation</div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                        <select
                          value={projectAutonomousRemediateActionDraft}
                          onChange={(e) => setProjectAutonomousRemediateActionDraft(e.target.value as "failed" | "escalated")}
                          className="h-8 rounded-md border border-border/60 bg-background px-2 text-[11px] text-foreground"
                        >
                          <option value="escalated">escalated</option>
                          <option value="failed">failed</option>
                        </select>
                        <input
                          value={projectAutonomousRemediateOlderThanDraft}
                          onChange={(e) => setProjectAutonomousRemediateOlderThanDraft(e.target.value)}
                          className="h-8 rounded-md border border-border/60 bg-background px-2 text-[11px] text-foreground"
                          placeholder="older_than_s"
                        />
                        <input
                          value={projectAutonomousRemediateMaxRunsDraft}
                          onChange={(e) => setProjectAutonomousRemediateMaxRunsDraft(e.target.value)}
                          className="h-8 rounded-md border border-border/60 bg-background px-2 text-[11px] text-foreground"
                          placeholder="max_runs"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => remediateProjectAutonomousStaleRuns(true).catch(() => {})}
                          disabled={projectAutonomousRemediateBusy}
                          className="px-2 py-1 rounded border border-border/60 text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                        >
                          {projectAutonomousRemediateBusy ? "Working..." : "Preview"}
                        </button>
                        <button
                          onClick={() => remediateProjectAutonomousStaleRuns(false).catch(() => {})}
                          disabled={projectAutonomousRemediateBusy}
                          className="px-2 py-1 rounded border border-amber-500/60 text-[11px] text-amber-300 hover:text-amber-100 hover:bg-amber-900/20 disabled:opacity-50"
                        >
                          Apply
                        </button>
                      </div>
                      {projectAutonomousRemediateResult && (
                        <div>
                          dry_run={String(projectAutonomousRemediateResult.dry_run)} · selected={String(projectAutonomousRemediateResult.selected_total)} · remediated={String(projectAutonomousRemediateResult.remediated_total)}
                        </div>
                      )}
                    </div>
                    <div className="rounded-md border border-border/50 bg-background/30 p-2 text-[11px] text-muted-foreground max-h-28 overflow-auto">
                      <pre className="whitespace-pre-wrap break-words">
                        {JSON.stringify(projectAutonomousReportData || selectedAutonomousRun.artifacts?.report || {}, null, 2)}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between px-4 py-3 border-t border-border/50">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => refreshProjectAutonomous().catch(() => {})}
                  disabled={projectAutonomousLoading}
                  className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                >
                  {projectAutonomousLoading ? "Refreshing..." : "Refresh"}
                </button>
                <button
                  onClick={() => refreshProjectAutonomousOpsStatus().catch(() => {})}
                  disabled={projectAutonomousOpsLoading}
                  className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                >
                  {projectAutonomousOpsLoading ? "Ops..." : "Refresh Ops"}
                </button>
                <button
                  onClick={() => refreshProjectAutonomousReport().catch(() => {})}
                  disabled={!projectAutonomousSelectedRunId}
                  className="px-3 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-muted/50 disabled:opacity-50"
                >
                  Report
                </button>
              </div>
              <div className="text-[11px] text-muted-foreground">
                {projectAutonomousError ? (
                  <span className="text-destructive">{projectAutonomousError}</span>
                ) : (
                  <span>
                    Backlog {projectAutonomousBacklog.length} · Runs {projectAutonomousRuns.length}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main content area */}
      <div className="flex flex-1 min-h-0">
        <HistorySidebar
          onOpen={handleHistoryOpen}
          openSessionIds={openHistorySessionIds}
          activeSessionId={activeSession?.backendSessionId ?? null}
          activeHistorySourceId={activeSession?.historySourceId ?? null}
          projectId={activeProjectId}
        />

        {/* ── Draft flowchart + chat ─────────────────────────────────── */}
        <div
          className="bg-card/30 flex flex-col border-r border-border/30 relative"
          style={{ width: `${graphPanelPct}%`, minWidth: 240, flexShrink: 0 }}
        >
          <div className="flex-1 min-h-0">
            <DraftGraph
              key={activeWorker}
              draft={activeAgentState?.originalDraft ?? activeAgentState?.draftGraph ?? null}
              originalDraft={activeAgentState?.originalDraft ?? null}
              loadingMessage={
                activeAgentState?.designingDraft
                  ? "Designing flowchart…"
                  : !activeAgentState?.originalDraft && !activeAgentState?.draftGraph && activeAgentState?.queenPhase !== "planning"
                    ? "Loading flowchart…"
                    : null
              }
              building={activeAgentState?.queenBuilding}
              onRun={handleRun}
              onPause={handlePause}
              runState={activeAgentState?.workerRunState ?? "idle"}
              flowchartMap={activeAgentState?.flowchartMap ?? undefined}
              runtimeNodes={currentGraph.nodes}
              onRuntimeNodeClick={(runtimeNodeId) => {
                const node = currentGraph.nodes.find(n => n.id === runtimeNodeId);
                if (node) setSelectedNode(prev => prev?.id === node.id ? null : node);
              }}
            />
          </div>
          {/* Resize handle */}
          <div
            className="absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/30 active:bg-primary/40 transition-colors z-10"
            onMouseDown={() => { resizing.current = true; document.body.style.cursor = "col-resize"; }}
          />
        </div>
        <div className="flex-1 min-w-0 flex">
          <div className="flex-1 min-w-0 relative">
            {/* Loading overlay */}
            {activeAgentState?.loading && (
              <div className="absolute inset-0 z-10 flex items-center justify-center bg-background/60 backdrop-blur-sm">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="text-sm">Connecting to agent...</span>
                </div>
              </div>
            )}

            {/* Queen connecting overlay — agent loaded but queen not yet alive */}
            {!activeAgentState?.loading && activeAgentState?.ready && !activeAgentState?.queenReady && (
              <div className="absolute top-0 left-0 right-0 z-10 px-4 py-2 bg-background border-b border-primary/20 flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-primary/60" />
                <span className="text-xs text-primary/80">Connecting to queen...</span>
              </div>
            )}

            {/* Connection error banner */}
            {activeAgentState?.error && !activeAgentState?.loading && dismissedBanner !== activeAgentState.error && (
              activeAgentState.error === "credentials_required" ? (
                <div className="absolute top-0 left-0 right-0 z-10 px-4 py-2 bg-background border-b border-amber-500/30 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-600" />
                  <span className="text-xs text-amber-700">Missing credentials — configure them to continue</span>
                  <button
                    onClick={() => setCredentialsOpen(true)}
                    className="ml-auto text-xs font-medium text-primary hover:underline"
                  >
                    Open Credentials
                  </button>
                  <button
                    onClick={() => setDismissedBanner(activeAgentState.error!)}
                    className="p-0.5 rounded text-amber-600 hover:text-amber-800 hover:bg-amber-500/20 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="absolute top-0 left-0 right-0 z-10 px-4 py-2 bg-background border-b border-destructive/30 flex items-center gap-2">
                  <WifiOff className="w-4 h-4 text-destructive" />
                  <span className="text-xs text-destructive">Backend unavailable: {activeAgentState.error}</span>
                  <button
                    onClick={() => setDismissedBanner(activeAgentState.error!)}
                    className="ml-auto p-0.5 rounded text-destructive hover:text-destructive hover:bg-destructive/20 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )
            )}

            {activeSession && (
              <ChatPanel
                messages={activeSession.messages}
                onSend={handleSend}
                onCancel={handleCancelQueen}
                activeThread={activeWorker}
                isWaiting={(activeAgentState?.queenIsTyping && !activeAgentState?.isStreaming) ?? false}
                isWorkerWaiting={(activeAgentState?.workerIsTyping && !activeAgentState?.isStreaming) ?? false}
                isBusy={activeAgentState?.queenIsTyping ?? false}
                disabled={
                  (activeAgentState?.loading ?? true) ||
                  !(activeAgentState?.queenReady)
                }
                queenPhase={activeAgentState?.queenPhase ?? "building"}
                pendingQuestion={activeAgentState?.awaitingInput ? activeAgentState.pendingQuestion : null}
                pendingOptions={activeAgentState?.awaitingInput ? activeAgentState.pendingOptions : null}
                pendingQuestions={activeAgentState?.awaitingInput ? activeAgentState.pendingQuestions : null}
                onQuestionSubmit={handleQueenQuestionAnswer}
                onMultiQuestionSubmit={handleMultiQuestionAnswer}
                onQuestionDismiss={handleQuestionDismiss}
                contextUsage={activeAgentState?.contextUsage}
                supportsImages={activeAgentState?.queenSupportsImages ?? true}
              />
            )}
          </div>
          {resolvedSelectedNode && (
            <div className="w-[480px] min-w-[400px] flex-shrink-0">
              {resolvedSelectedNode.nodeType === "trigger" ? (
                <div className="flex flex-col h-full border-l border-border/40 bg-card/20 animate-in slide-in-from-right">
                  <div className="px-4 pt-4 pb-3 border-b border-border/30 flex items-start justify-between gap-2">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 bg-[hsl(210,40%,55%)]/15 border border-[hsl(210,40%,55%)]/25">
                        <span className="text-sm" style={{ color: "hsl(210,40%,55%)" }}>
                          {{ "webhook": "\u26A1", "timer": "\u23F1", "api": "\u2192", "event": "\u223F" }[resolvedSelectedNode.triggerType || ""] || "\u26A1"}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-sm font-semibold text-foreground leading-tight">{resolvedSelectedNode.label}</h3>
                        <p className="text-[11px] text-muted-foreground mt-0.5 capitalize flex items-center gap-1.5">
                          {resolvedSelectedNode.triggerType} trigger
                          <span className={`inline-block w-1.5 h-1.5 rounded-full ${
                            resolvedSelectedNode.status === "running" || resolvedSelectedNode.status === "complete"
                              ? "bg-emerald-400" : "bg-muted-foreground/40"
                          }`} />
                          <span className={`text-[10px] ${
                            resolvedSelectedNode.status === "running" || resolvedSelectedNode.status === "complete"
                              ? "text-emerald-400" : "text-muted-foreground/60"
                          }`}>
                            {resolvedSelectedNode.status === "running" || resolvedSelectedNode.status === "complete" ? "active" : "inactive"}
                          </span>
                        </p>
                      </div>
                    </div>
                    <button onClick={() => setSelectedNode(null)} className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors flex-shrink-0">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="px-4 py-4 flex flex-col gap-3">
                    {(() => {
                      const tc = resolvedSelectedNode.triggerConfig as Record<string, unknown> | undefined;
                      const cron = tc?.cron as string | undefined;
                      const interval = tc?.interval_minutes as number | undefined;
                      const eventTypes = tc?.event_types as string[] | undefined;
                      const scheduleLabel = cron
                        ? cronToLabel(cron)
                        : interval
                          ? `Every ${interval >= 60 ? `${interval / 60}h` : `${interval}m`}`
                          : eventTypes?.length
                            ? eventTypes.join(", ")
                            : null;
                      const canEditCron = resolvedSelectedNode.triggerType === "timer";
                      const cronChanged = canEditCron && triggerCronDraft.trim() !== (cron || "");
                      return scheduleLabel || canEditCron ? (
                        <div>
                          <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Schedule</p>
                          {scheduleLabel && (
                            <p className="text-xs text-foreground/80 font-mono bg-muted/30 rounded-lg px-3 py-2 border border-border/20">
                              {scheduleLabel}
                            </p>
                          )}
                          {canEditCron && (
                            <>
                              <input
                                value={triggerCronDraft}
                                onChange={(e) => setTriggerCronDraft(e.target.value)}
                                placeholder="0 5 * * *"
                                className="mt-1.5 w-full text-xs text-foreground/80 bg-muted/30 rounded-lg px-3 py-2 border border-border/20 font-mono focus:outline-none focus:border-primary/40"
                              />
                              <p className="text-[10px] text-muted-foreground/60 mt-1">
                                Edit the cron expression for this timer trigger.
                              </p>
                              {(cronChanged || triggerCronSaved) && (
                                <button
                                  disabled={triggerScheduleSaving || !cronChanged}
                                  onClick={async () => {
                                    const sessionId = activeAgentState?.sessionId;
                                    const triggerId = resolvedSelectedNode.id.replace("__trigger_", "");
                                    const nextCron = triggerCronDraft.trim();
                                    if (!sessionId || !nextCron) return;
                                    const nextTriggerConfig: Record<string, unknown> = { cron: nextCron };
                                    setTriggerScheduleSaving(true);
                                    try {
                                      await sessionsApi.updateTrigger(sessionId, triggerId, {
                                        trigger_config: nextTriggerConfig,
                                      });
                                      patchTriggerNode(activeWorker, resolvedSelectedNode.id, {
                                        trigger_config: nextTriggerConfig,
                                        label: cronToLabel(nextCron),
                                      });
                                      setTriggerCronSaved(true);
                                      setTimeout(() => setTriggerCronSaved(false), 2000);
                                    } finally {
                                      setTriggerScheduleSaving(false);
                                    }
                                  }}
                                  className="mt-1.5 w-full text-[11px] px-3 py-1.5 rounded-lg border border-primary/30 text-primary hover:bg-primary/10 transition-colors disabled:opacity-50"
                                >
                                  {triggerScheduleSaving ? "Saving..." : triggerCronSaved ? "Saved" : "Save Cron"}
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      ) : null;
                    })()}
                    {(() => {
                      const nfi = (resolvedSelectedNode.triggerConfig as Record<string, unknown> | undefined)?.next_fire_in as number | undefined;
                      return nfi != null ? (
                        <div>
                          <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Next run</p>
                          <p className="text-xs text-foreground/80 font-mono bg-muted/30 rounded-lg px-3 py-2 border border-border/20">
                            <TimerCountdown initialSeconds={nfi} />
                          </p>
                        </div>
                      ) : null;
                    })()}
                    <div>
                      <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Task</p>
                      <textarea
                        value={triggerTaskDraft}
                        onChange={(e) => setTriggerTaskDraft(e.target.value)}
                        placeholder="Describe what the worker should do when this trigger fires..."
                        className="w-full text-xs text-foreground/80 bg-muted/30 rounded-lg px-3 py-2 border border-border/20 resize-none min-h-[60px] font-mono focus:outline-none focus:border-primary/40"
                        rows={3}
                      />
                      {(() => {
                        const currentTask = (resolvedSelectedNode.triggerConfig as Record<string, unknown> | undefined)?.task as string || "";
                        const hasChanged = triggerTaskDraft !== currentTask;
                        if (!hasChanged && !triggerTaskSaved) return null;
                        return (
                          <button
                            disabled={triggerTaskSaving || !hasChanged}
                            onClick={async () => {
                              const sessionId = activeAgentState?.sessionId;
                              const triggerId = resolvedSelectedNode.id.replace("__trigger_", "");
                              if (!sessionId) return;
                              setTriggerTaskSaving(true);
                              try {
                                await sessionsApi.updateTrigger(sessionId, triggerId, { task: triggerTaskDraft });
                                patchTriggerNode(activeWorker, resolvedSelectedNode.id, { task: triggerTaskDraft });
                                setTriggerTaskSaved(true);
                                setTimeout(() => setTriggerTaskSaved(false), 2000);
                              } finally {
                                setTriggerTaskSaving(false);
                              }
                            }}
                            className="mt-1.5 w-full text-[11px] px-3 py-1.5 rounded-lg border border-primary/30 text-primary hover:bg-primary/10 transition-colors disabled:opacity-50"
                          >
                            {triggerTaskSaving ? "Saving..." : triggerTaskSaved ? "Saved" : "Save Task"}
                          </button>
                        );
                      })()}
                      {!triggerTaskDraft && (
                        <p className="text-[10px] text-amber-400/80 mt-1">A task is required before enabling this trigger.</p>
                      )}
                    </div>
                    <div>
                      <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-1.5">Fires into</p>
                      <p className="text-xs text-foreground/80 font-mono bg-muted/30 rounded-lg px-3 py-2 border border-border/20">
                        {resolvedSelectedNode.next?.[0]?.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ") || "—"}
                      </p>
                    </div>
                    {activeAgentState?.queenPhase !== "building" && (() => {
                      const triggerIsActive = resolvedSelectedNode.status === "running" || resolvedSelectedNode.status === "complete";
                      const triggerId = resolvedSelectedNode.id.replace("__trigger_", "");
                      const taskMissing = !triggerTaskDraft;
                      return (
                        <div className="pt-1">
                          <button
                            disabled={!triggerIsActive && taskMissing}
                            onClick={async () => {
                              const sessionId = activeAgentState?.sessionId;
                              if (!sessionId) return;
                              const action = triggerIsActive ? "Disable" : "Enable";
                              await executionApi.chat(sessionId, `${action} trigger ${triggerId}`);
                            }}
                            className={`w-full text-xs px-3 py-2 rounded-lg border transition-colors ${
                              triggerIsActive
                                ? "border-red-500/30 text-red-400 hover:bg-red-500/10"
                                : taskMissing
                                  ? "border-border/30 text-muted-foreground/40 cursor-not-allowed"
                                  : "border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10"
                            }`}
                          >
                            {triggerIsActive ? "Disable Trigger" : "Enable Trigger"}
                          </button>
                          {!triggerIsActive && taskMissing && (
                            <p className="text-[10px] text-muted-foreground/50 mt-1 text-center">Configure a task first</p>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              ) : (
                <NodeDetailPanel
                  node={resolvedSelectedNode}
                  nodeSpec={activeAgentState?.nodeSpecs.find(n => n.id === resolvedSelectedNode.id) ?? null}
                  allNodeSpecs={activeAgentState?.nodeSpecs}
                  subagentReports={activeAgentState?.subagentReports}
                  sessionId={activeAgentState?.sessionId || undefined}
                  graphId={activeAgentState?.graphId || undefined}
                  workerSessionId={null}
                  nodeLogs={activeAgentState?.nodeLogs[resolvedSelectedNode.id] || []}
                  actionPlan={activeAgentState?.nodeActionPlans[resolvedSelectedNode.id]}
                  contextUsage={activeAgentState?.contextUsage[resolvedSelectedNode.id]}
                  onClose={() => setSelectedNode(null)}
                />
              )}
            </div>
          )}
        </div>
      </div>

      <CredentialsModal
        agentType={activeWorker}
        agentLabel={activeWorkerLabel}
        agentPath={credentialAgentPath || activeAgentState?.agentPath || (!activeWorker.startsWith("new-agent") ? activeWorker : undefined)}
        open={credentialsOpen}
        onClose={() => {
          setCredentialsOpen(false);
          setCredentialAgentPath(null);
          // Keep credentials_required error set — clearing it here triggers
          // the auto-load effect which retries session creation immediately,
          // causing an infinite modal loop when credentials are still missing.
          // The error is only cleared in onCredentialChange (below) when the
          // user actually saves valid credentials.
        }}
        credentials={activeSession?.credentials || []}
        onCredentialChange={() => {
          // Clear credential error so the auto-load effect retries session creation
          if (agentStates[activeWorker]?.error === "credentials_required") {
            updateAgentState(activeWorker, { error: null });
          }
          refreshCredentialReadiness().catch(() => {});
          if (!activeSession) return;
          setSessionsByAgent(prev => ({
            ...prev,
            [activeWorker]: prev[activeWorker].map(s =>
              s.id === activeSession.id
                ? { ...s, credentials: s.credentials.map(c => ({ ...c, connected: true })) }
                : s
            ),
          }));
        }}
      />
    </div>
  );
}
